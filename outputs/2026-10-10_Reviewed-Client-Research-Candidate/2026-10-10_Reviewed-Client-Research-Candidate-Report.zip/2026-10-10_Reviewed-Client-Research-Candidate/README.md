# SOLAR-001 — Reviewed client research candidate, 10 October 2026

I retain the revised English manuscript and its 75-page PDF here. I applied the 27-item minimal editorial plan: P1 R-01–R-16; P2 R-17–R-26 (R-26 is covered by R-17); and the optional contract-question table R-27. I changed no existing financial or empirical estimate and executed no regression, simulation, decomposition or financial model. This remains a candidate, not original Version 1.0 acceptance.

## Read first

- `Integrated-Market-Research-Report-EN_Reviewed-Candidate.pdf`: client report.
- `Integrated-Market-Research-Report-EN_Reviewed-Candidate.md`: editable source.
- `Review-Revision-Change-Log.md` and `Review-Revision-Disposition.csv`: item-by-item dispositions and editorial departures supported by retained evidence.
- `Production-Verification.md`, `Editorial-Operations.json` and `support/Reviewed-*`: current production evidence.
- `review/`: supplied independent-context reviews, interaction, plan and disclosures. These are instances of one model, not human expert certification.
- `closure-evidence/`, `finance-supplement/`, `sources/`: retained source catalogs, statements and originals; no new retrieval claimed.
- `scenario-versions/`, `data/`, `figures/`: unchanged results and presentation inputs.
- `internal/Closure-Integrated-Input.md`: preserved input manuscript. Original governance, including Appendix E, remains in `internal/Baseline-Appendices-A-to-E.md`; inherited production records are explicitly named as inherited.

## Applicable use and stopping point

I use this edition for industry and market screening, procurement diligence, contract-product comparison and conditional capital-recovery analysis. The report does not establish actual asset value, a typical ERCOT solar IRR, after-tax or equity returns, bankability, a project-specific credit entitlement, long-run price probabilities or a causal capacity effect. Negative historical-scenario NPVs are not a conclusion that ERCOT solar is generally uneconomic. The hub hedge is a separate hypothetical version, dependent on its merchant tail; gross energy value is not net receipts.

Appendix C retains undisclosed project costs, executed contracts, taxes, financing and settlement fields. The original Criterion 6 remains unclosed; scenarios do not replace factual-project blocked/null outputs. I do not create new research tasks to remove these edition boundaries. The GitHub upload is an author/reviewer handoff, not a client release or sale. Redistribution rights for third-party originals in a paid product remain unestablished.

## Packages, each under 30 MB

Extract both adjacent ZIPs (`...-Report.zip` and `...-Supplement-Sources.zip`) into the same parent folder. They share this directory name. The report ZIP contains the report, retained small tables, charts, scripts, source catalogs and production evidence; the source companion contains `closure-evidence/sources/`. The local directory already contains both. The split meets the 30,000,000-byte per-file limit and is intended for author/reviewer handoff.

## Offline editorial reproduction

Requirements: Python 3; `reportlab`, `matplotlib`, `PyMuPDF` (`fitz`). Focused table checks additionally use `pandas`. No login, key, network, PySAM or model execution is needed. From this directory, using an empty output folder:

```sh
python3 -P scripts/rebuild_reviewed.py --output-dir /tmp/solar-reviewed-rebuilt
```

The entry applies asserted, recorded text edits to the retained input and renders the PDF using unchanged figures. It writes `rebuild-command-results.json` with actual commands and exit statuses. Compare the rebuilt Markdown and PDF hashes with this directory. Do not use the inherited `rebuild_closure.py` for the new edition: it reconstructs the prior manuscript.

For focused editorial evidence checks:

```sh
python3 -P scripts/verify_reviewed_edits.py
```

The check verifies unchanged numeric cells, new summary figures against retained tables and selected original locators, links, qualifiers and figure keys. It does not revalidate every inherited claim or reacquire originals. Full raw-to-model reproduction still needs earlier roughly gigabyte-scale project archives and has not been rerun.

## Integrity

`File-Manifest.csv` gives sizes, SHA-256 and ZIP part; `SHA256SUMS.txt` covers payload files, and `Manifest.sha256` authenticates the manifest. Each ZIP has its own adjacent `.sha256`. The external `...-Package-Verification.json` records actual CRC, safe-path, extracted-hash and independent editorial-rebuild results. Run `python3 -P scripts/package_reviewed.py` to package and perform those checks.

The upstream review branch input is commit `1755561`; the reviewed report input is retained from commit `569a45c3f61c478c9996030afc1ee97174139b77`. GitHub publication of this research/review handoff does not claim formal acceptance or authorization to sell third-party material.
