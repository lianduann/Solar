"""Offline editorial and PDF reproduction. Does not execute any model."""
from pathlib import Path
import argparse,subprocess,sys,json,tempfile,os,shutil
D=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
O=a.output_dir.resolve();O.mkdir(parents=True,exist_ok=True)
log=[];env=dict(os.environ);env['MPLCONFIGDIR']=tempfile.mkdtemp(prefix='solar-mpl-')
for args in [['apply_review_edits.py','--output-dir',str(O)],['build_pdf.py','--src',str(O/'Integrated-Market-Research-Report-EN_Reviewed-Candidate.md'),'--out',str(O/'Integrated-Market-Research-Report-EN_Reviewed-Candidate.pdf')]]:
 cmd=[sys.executable,'-P',str(D/'scripts'/args[0]),*args[1:]]
 r=subprocess.run(cmd,env=env,capture_output=True,text=True)
 print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
 log.append({'command':cmd,'exit_status':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:raise SystemExit(r.returncode)
(O/'rebuild-command-results.json').write_text(json.dumps(log,indent=2))
shutil.rmtree(env['MPLCONFIGDIR'])
