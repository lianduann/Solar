"""Render the English manuscript (or the appendix) to PDF, entirely offline, with reportlab and the DejaVu fonts bundled with matplotlib.
The Markdown source is read as is and never modified. Usage (from anywhere):
    python3 -P scripts/build_pdf.py                       -> Integrated-Market-Research-Report-EN.pdf (next to the manuscript)
    python3 -P scripts/build_pdf.py --kind appendix        -> Methods-Data-and-Model-Status-Appendix.pdf
Adapted from the offline renderer of the 2026-10-08 integrated draft: v0.5 cover and footer, proportional table widths with column alignment, figure+caption+source kept together,
local links only where the target exists in the package, soft breaks inside long code paths."""
import argparse, html, re, hashlib, io
from pathlib import Path
import matplotlib
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, CondPageBreak, Image, Table, TableStyle, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
D = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser(); ap.add_argument("--kind", choices=["main", "appendix"], default="main"); ap.add_argument("--src"); ap.add_argument("--out"); a = ap.parse_args()
SRC = D / (a.src or ("Integrated-Market-Research-Report-EN_Reviewed-Candidate.md" if a.kind == "main" else "Methods-Data-and-Model-Status-Appendix.md")); OUT = D / (a.out or SRC.with_suffix(".pdf").name)
FOOT = "SOLAR-001 | Candidate research edition | 10 October 2026" + ("" if a.kind == "main" else " | Methods, Data and Model Status Appendix")
fontroot = Path(matplotlib.get_data_path()) / "fonts/ttf"
for face, file in [("Report", "DejaVuSans.ttf"), ("Report-Bold", "DejaVuSans-Bold.ttf"), ("Report-Italic", "DejaVuSans-Oblique.ttf"), ("Report-BoldItalic", "DejaVuSans-BoldOblique.ttf"), ("Report-Mono", "DejaVuSansMono.ttf")]: pdfmetrics.registerFont(TTFont(face, str(fontroot / file)))
pdfmetrics.registerFontFamily("Report", normal="Report", bold="Report-Bold", italic="Report-Italic", boldItalic="Report-BoldItalic")
INK = colors.HexColor("#1F2933"); NAVY = colors.HexColor("#17324D"); TEAL = colors.HexColor("#167D8D"); MUTE = colors.HexColor("#5F6B76")
S = getSampleStyleSheet()
for s in S.byName.values(): s.fontName = "Report"
S.add(ParagraphStyle(name="BodyR", fontName="Report", fontSize=9.6, leading=14.2, spaceAfter=8, textColor=INK))
S["BodyR"].allowWidows = 0
S["BodyR"].allowOrphans = 0
S.add(ParagraphStyle(name="H1R", fontName="Report-Bold", fontSize=18, leading=23, spaceAfter=15, keepWithNext=True, textColor=NAVY))
S.add(ParagraphStyle(name="H2R", fontName="Report-Bold", fontSize=12, leading=16, spaceBefore=10, spaceAfter=7, keepWithNext=True, textColor=NAVY))
S.add(ParagraphStyle(name="CoverSubR", fontName="Report-Bold", fontSize=13, leading=18, textColor=NAVY))
S.add(ParagraphStyle(name="ContentsR", fontName="Report-Bold", fontSize=14, leading=18, spaceAfter=8, textColor=NAVY))
S.add(ParagraphStyle(name="CaptionR", parent=S["BodyR"], fontSize=7.9, leading=10.8, spaceAfter=11, textColor=MUTE))
S.add(ParagraphStyle(name="FigR", parent=S["BodyR"], fontName="Report-Bold", fontSize=8.6, leading=11.5, spaceAfter=3, textColor=NAVY, keepWithNext=True))
S.add(ParagraphStyle(name="GapR", parent=S["CaptionR"], borderColor=colors.HexColor("#C0CDD4"), borderWidth=.5, borderPadding=7, backColor=colors.HexColor("#F2F5F7"), spaceBefore=8, spaceAfter=14))
S.add(ParagraphStyle(name="CellR", fontName="Report", fontSize=7.3, leading=9.8, textColor=INK))
S.add(ParagraphStyle(name="CellRR", parent=S["CellR"], alignment=TA_RIGHT))
S.add(ParagraphStyle(name="CellH", parent=S["CellR"], fontName="Report-Bold"))
S.add(ParagraphStyle(name="CellHR", parent=S["CellH"], alignment=TA_RIGHT))
S.add(ParagraphStyle(name="TableTitleR", parent=S["BodyR"], fontName="Report-Bold", keepWithNext=True))
S.add(ParagraphStyle(name="CoverR", fontName="Report-Bold", fontSize=26, leading=34, textColor=NAVY, spaceAfter=20))

def softbreak(t):
    return t
def inline(t, existing=None):
    t = html.escape(t)
    t = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", t)
    def lk(m):
        txt, href = m[1], html.unescape(m[2])
        if href.startswith("https://"): return f'<link href="{href}" color="#167D8D">{txt}</link>'
        if not href.startswith("..") and (D / href).exists(): return f'<link href="{html.escape(href)}" color="#167D8D">{txt}</link>'
        return txt
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lk, t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t); t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", t)
    t = re.sub(r"`([^`]+)`", lambda m: f'<font name="Report" size="{9.4 if len(m[1]) <= 3 else 8.2}" color="#3B4A57">{softbreak(m[1])}</font>', t)
    return "".join(x if x.startswith("<") else softbreak(x) for x in re.split(r"(<[^>]+>)", t))
class ReportDoc(BaseDocTemplate):
    def afterFlowable(self, f):
        if isinstance(f, Paragraph) and f.style.name in ("H1R", "H2R"):
            title = f.getPlainText(); key = f"{f.style.name}-{self.page}-{int(hashlib.sha256(title.encode()).hexdigest()[:10], 16)}"; self.canv.bookmarkPage(key); lvl = 0 if f.style.name == "H1R" else 1
            self.canv.addOutlineEntry(title, key, level=lvl, closed=False)
            if lvl == 0: self.notify("TOCEntry", (0, title, self.page, key))
def footer(c, d):
    if d.page == 1: return
    c.saveState(); c.setStrokeColor(colors.HexColor("#C0CDD4")); c.line(52, 40, 560, 40); c.setFont("Report", 7); c.setFillColor(MUTE); c.drawString(52, 27, FOOT); c.drawRightString(560, 27, f"Page {d.page}"); c.restoreState()
lines = SRC.read_text(encoding="utf-8").splitlines()
head = [l for l in lines[:12] if l.strip()]; title = re.sub(r"^#\s*", "", head[0]); sub = re.sub(r"^##\s*", "", head[1]) if len(head) > 1 else ""; org = head[2].strip("*") if len(head) > 2 else ""; tag = head[3].strip("*") if len(head) > 3 else ""
doc = ReportDoc(str(OUT), pagesize=(612, 792), leftMargin=52, rightMargin=52, topMargin=50, bottomMargin=56, title=title, author="Lucid Direction Insights LLC", invariant=1)
doc.addPageTemplates(PageTemplate(id="Report", frames=Frame(52, 56, 508, 686, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0), onPage=footer))
esc = lambda s: html.escape(s).replace("\n", "<br/>")
story = [Spacer(1, 62), Paragraph(esc(title), S["CoverR"]), Paragraph(esc(sub), S["CoverSubR"]), Spacer(1, 26), Paragraph(esc(org.replace(" | ", "\n")), S["BodyR"]), Spacer(1, 18), Paragraph(esc(tag), S["BodyR"]), Spacer(1, 26),
         Paragraph("Research edition. Conditional scenarios for market screening and commercial diligence; not investment advice or a verified asset valuation.", S["GapR"]), PageBreak(), Paragraph("Contents", S["ContentsR"])]
toc = TableOfContents(); toc.levelStyles = [ParagraphStyle(name="TOC0R", fontName="Report", fontSize=9, leading=14, spaceBefore=5, leftIndent=0, firstLineIndent=0, rightIndent=16)]; story.extend([toc, PageBreak()])
i = 0
while i < len(lines) and not lines[i].startswith("**Edition scope.") and not lines[i].startswith("# 1.") and not lines[i].startswith("# A"): i += 1
if a.kind == "appendix" and i >= len(lines): i = 0
def widths(raw, aligns):
    n = len(raw[0]); lens = []; minw = []
    for c in range(n):
        cell = [r[c] if c < len(r) else "" for r in raw]; m = max(len(x) for x in cell); mean = sum(len(x) for x in cell) / len(cell); lens.append(max(8, min(m, 0.5 * m + 0.5 * mean * 1.4 + 6)))
        tok = max((len(w) for x in cell for w in re.sub(r"[`*\[\]]", "", x).split()), default=4); minw.append(max(38, min(tok * 4.15 + 12, 150)))
    tot = sum(lens); w = [508 * x / tot for x in lens]; w = [max(a_, b_) for a_, b_ in zip(w, minw)]; sc = 508 / sum(w)
    if sc < 1:   # keep minimum widths: shave the widest columns instead of scaling every column
        excess = sum(w) - 508; wide = sorted(range(n), key=lambda k: -w[k])
        for k in wide:
            take = min(excess, max(0, w[k] - minw[k])); w[k] -= take; excess -= take
            if excess <= 0: break
        return w
    return [x * sc for x in w]
while i < len(lines):
    line = lines[i].strip()
    if not line or line == "---": i += 1; continue
    if line.startswith("# "):
        story.extend([CondPageBreak(190), Paragraph(inline(line[2:]), S["H1R"])]); i += 1; continue
    if line.startswith("### "): story.append(Paragraph(inline(line[4:]), S["H2R"])); i += 1; continue
    if line.startswith("## "): story.append(Paragraph(inline(line[3:]), S["H2R"])); i += 1; continue
    if re.match(r"^\*\*Table [A-Za-z0-9.-]+", line):
        story.append(Paragraph(inline(line), S["TableTitleR"])); i += 1; continue
    if line.startswith("|"):
        raw = []; aligns = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            row = [x.strip() for x in lines[i].strip().strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", x.replace(" ", "")) for x in row): aligns = ["R" if x.strip().endswith(":") and not x.strip().startswith(":") else "L" for x in row]
            else: raw.append(row)
            i += 1
        n = len(raw[0]); aligns = aligns or ["L"] * n
        cells = [[Paragraph(inline(x), S[("CellHR" if aligns[c] == "R" else "CellH") if r == 0 else ("CellRR" if aligns[c] == "R" else "CellR")]) for c, x in enumerate(row)] for r, row in enumerate(raw)]
        table = Table(cells, colWidths=widths(raw, aligns), repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DFEAF0")), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                                   ("LINEBELOW", (0, 0), (-1, 0), .7, colors.HexColor("#8AA7B8")), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F7F8")]), ("LINEBELOW", (0, 1), (-1, -1), .25, colors.HexColor("#D5DFE4"))]))
        prior = story.pop() if story and isinstance(story[-1], Paragraph) and story[-1].style.name == "TableTitleR" else None
        if len(raw) <= 16:
            block = ([prior] if prior else []) + [table]
            j = i
            while j < len(lines) and not lines[j].strip(): j += 1
            if j < len(lines) and lines[j].strip().startswith("*") and not lines[j].strip().startswith("**"):
                block.append(Paragraph(inline(lines[j].strip()), S["CaptionR"])); i = j + 1
            story.append(KeepTogether(block))
        else:
            if prior: story.append(prior)
            story.append(table)
        story.append(Spacer(1, 8)); continue
    if line.startswith("!["):
        m = re.match(r"!\[([^]]*)\]\(([^)]+)\)", line); path = D / m[2]; w, h = ImageReader(str(path)).getSize(); scale = min(508 / w, 470 / h); im = Image(io.BytesIO(path.read_bytes()), width=w * scale, height=h * scale); i += 1
        blk = [Spacer(1, 4), Paragraph(inline(m[1]), S["FigR"]), im, Spacer(1, 4)]
        j = i
        while j < len(lines) and not lines[j].strip(): j += 1
        if j < len(lines) and lines[j].strip().startswith("*") and not lines[j].strip().startswith("**"): blk.append(Paragraph(inline(lines[j].strip()), S["CaptionR"])); i = j + 1
        story.append(KeepTogether(blk)); continue
    if re.match(r"^\d+\. ", line) or line.startswith("- "):
        story.append(Paragraph(inline(line), S["BodyR"])); i += 1; continue
    paragraph = [line]; i += 1
    while i < len(lines) and lines[i].strip() and not lines[i].startswith(("#", "|", "![", "- ")) and not re.match(r"^\d+\. ", lines[i]): paragraph.append(lines[i].strip()); i += 1
    t = " ".join(paragraph); style = S["GapR"] if t.startswith(">") else S["CaptionR"] if t.startswith("*") and not t.startswith("**") else S["BodyR"]
    if t.startswith(">"): t = t[1:].strip()
    paragraph = Paragraph(inline(t), style)
    story.append(KeepTogether([paragraph]) if style.name == "GapR" else paragraph)
j = 0
while j < len(story) - 1:
    f, nxt = story[j:j + 2]
    if isinstance(f, Paragraph) and f.style.name == "H2R" and isinstance(nxt, KeepTogether): nxt._content.insert(0, f); story.pop(j)
    j += 1
# Keep a chapter heading with a following subsection/figure group.
j = 0
while j < len(story) - 1:
    f, nxt = story[j:j + 2]
    if isinstance(f, Paragraph) and f.style.name == "H1R" and isinstance(nxt, KeepTogether):
        nxt._content.insert(0, f); story.pop(j)
    j += 1
doc.multiBuild(story)
import fitz
pdf = fitz.open(OUT)
meta = pdf.metadata
meta.update({'title': title, 'author': 'Lucid Direction Insights LLC', 'subject': 'Solar supply chain and ERCOT market research', 'creationDate': "D:20261010000000-04'00'", 'modDate': "D:20261010000000-04'00'"})
pdf.set_metadata(meta)
fixed = OUT.with_suffix('.metadata.pdf'); pdf.save(fixed, no_new_id=True); pdf.close(); fixed.replace(OUT)
print(OUT)
