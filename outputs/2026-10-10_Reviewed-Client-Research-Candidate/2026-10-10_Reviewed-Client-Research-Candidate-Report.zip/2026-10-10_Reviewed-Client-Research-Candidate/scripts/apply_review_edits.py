"""Apply the accepted editorial plan to a retained manuscript. No model execution."""
from pathlib import Path
import argparse,csv,json,re
D=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--output-dir',type=Path);a=a.parse_args();O=(a.output_dir or D).resolve();O.mkdir(parents=True,exist_ok=True)
s=(D/'internal/Closure-Integrated-Input.md').read_text();before=s
changes=[]
def rep(id,old,new,count=1):
 global s
 assert s.count(old)==count,(id,old[:90],s.count(old),count)
 s=s.replace(old,new);changes.append({'revision':id,'operation':'replace','occurrences':count,'before':old,'after':new})
def para(id,prefix,new):
 global s
 matches=[p for p in (s.splitlines() if re.match(r'^\d+\. ',prefix) else s.split('\n\n')) if p.startswith(prefix)]
 assert len(matches)==1,(id,prefix,len(matches))
 rep(id,matches[0],new)
def append(id,prefix,text):
 matches=[p for p in (s.splitlines() if re.match(r'^\d+\. ',prefix) else s.split('\n\n')) if p.startswith(prefix)]
 assert len(matches)==1,(id,prefix,len(matches))
 rep(id,matches[0],matches[0]+text)
# P1: summary scope, contract products and accounting boundaries.
rep('R-01','These results support contract and procurement screening, rather than an investment recommendation.**','These pre-tax, unlevered results concern one hypothetical system priced at screened settlement points. They support contract and procurement screening; they do not show that ERCOT solar projects are generally uneconomic or forecast module demand.**')
para('R-02','2. Payment terms matter.','2. Payment terms matter. The 30-year node-delivered, flat nominal route breaks even near $66/MWh with 15.24% of potential energy assumed unpaid (a stress setting, not a contract term), or $55.9/MWh if all potential output is paid. A separate 10–15-year West-hub hedge with a node merchant tail needs $60.6–$84.8/MWh, mainly depending on the unsourced tail. None is an observed offer. [S08; Section 10.3]')
rep('R-02','| Flat nominal break-even contract price | $66.0/MWh | Fixed-price route; 11.3 |','| Break-even, 30-yr node-level fixed-price route | $66.0/MWh | 15.24% unpaid; pre-tax, no credit; 11.3 |\n| HB_WEST hedge break-even strike, 10–15 yr | $60.6–84.8/MWh | Separate pre-tax, no-credit version; tail-dependent; 10.3 |')
rep('R-02','A hub contract therefore needs its own settlement calculation; switching benchmarks is not automatically an improvement.','A hub-settled contract leaves the seller with node-to-hub basis and needs its own settlement calculation (Section 10.3); switching benchmarks is not automatically an improvement.')
rep('R-03','earns $26.4/MWh on delivered electricity','is modelled to receive a gross $26.4/MWh on delivered electricity')
rep('R-03','| Realized sales price |','| Modelled gross energy value per delivered MWh (before fees, settlement losses and imbalance) |')
# Avoid repeating $26.4 in Chapter 1; the cross-reference supplies exactly the same denominator distinction.
rep('R-03','potential-generation-weighted price is $22.13/MWh.','potential-generation-weighted price is $22.13/MWh (all potential output; item 1 uses exported output after the negative-price stop rule).')
rep('R-04','leaving reference-node NPV at **−$50.59m**. Eligibility remains unproven;','leaving reference-node NPV at **−$50.59m**: pre-tax NPV plus an illustrative 30% credit received at end-2027, assuming eligibility, not an after-tax valuation. Eligibility remains unproven;')
# Definition at first use; trade facts in a separate short paragraph for executive readability.
rep('R-06','**U.S. module input**,','**U.S. module input** (DOE/NLR U.S.-assembled benchmark: about $0.29/Wdc in 2024 dollars after −$0.07/Wdc of modelled 45X subsidy, about $0.36 before it; not an import or export price),')
append('R-05','3. A hypothetical',' From 4 December 2026, covered imports face MIPs of $0.22/W (cells) and $0.38/W (modules), generally another 15% duty, and continuing AD/CVD. September 2026 Commerce finals for India, Indonesia and Laos await ITC injury findings. China ended listed PV export VAT rebates on 1 April 2026. These provisions are not delivered prices or supplier-specific tariff outcomes. [P01; 5.7; LONGi FY2025 annual report p.297]')
rep('R-05','This affects export economics without proving an equal increase in the U.S. delivered price. [P07, P08]','This affects export economics without proving an equal increase in the U.S. delivered price. [P07; CL-B-01, LONGi FY2025 annual report p.297, post-balance-sheet note citing MOF/STA announcement 2026 No.2]')
rep('R-06','The preferred sensitivity varies the **U.S. module input** directly.','The preferred sensitivity varies the **U.S. module input** defined in Section 1.1 directly: the subsidy-adjusted U.S.-assembled benchmark cost, not an import quotation.')
rep('R-06','the benchmark uses a U.S.-assembled module input including its stated subsidy treatment','the DOE/NLR U.S.-assembled benchmark is about $0.29/Wdc (2024 dollars) after the model’s −$0.07/Wdc 45X subsidy, about $0.36/Wdc before it; neither figure is an imported-module or export price')
rep('R-07','| A manufacturer or exporter | 1, 4, 5, 13.1 |','| A manufacturer or exporter | 1, 4, 5, 10.8, 13.1 |')
rep('R-07','Illustrative $35.38m OCC-basis benefit is conditional, not an entitlement','40%/45% material-assistance cost ratio for 2026/2027 construction starts: manufactured-product cost not attributable to a prohibited foreign entity; ownership/control rules also apply (10.8). The $35.38m illustration assumes eligibility, not a supplier/product finding')
rep('R-07','Ownership/control records and applicable tax eligibility documents |','Ownership/control records and applicable tax eligibility documents (see 10.8) |')
# Annual-account basis labels, not substituted financial observations.
rep('R-08','CNY | Segment margin; LLA cash |','CNY | Industry line (PV incl. storage/systems); LLA cash |',1) if False else None
for company,basis in [('Trina','Industry line (PV incl. storage/systems); LLA cash'),('JA Solar','Industry line (new energy); LLA cash'),('Tongwei','PV business line; LLA cash')]:
 line=next(l for l in s.splitlines() if l.startswith('| '+company+' |'))
 rep('R-08',line,line.replace('Segment margin; LLA cash',basis))
for line in [l for l in s.splitlines() if l.startswith('| LONGi |')]:
 rep('R-08',line,line.replace('Segment only','Product line only').replace('Segment margin','Product-line margin'))
rep('R-08','The A-share gross margins are segment measures: PV for Trina and Tongwei, new energy for JA.','The A-share gross margins mix industry/business and product lines; they are not a matched product ranking. FY2025 module/cell product-line margins are Trina −1.42% (PV products), JA −4.03% (PV modules), Tongwei −0.38% (cells, modules and related) and LONGi 0.19%; LONGi’s industry line is 0.81%. [Retained FY2025 annual reports, principal-business tables; CL-B-01, CL-FIN-09]')
rep('R-09','| Scenario | First-year delivered GWh |','| Scenario | First-year delivered (node) / paid (fixed), GWh |')
append('R-09','*Source: six-scenario cash-flow outputs',' Fixed-route LCOE uses paid energy as its denominator. Fixed base equals Node base because the 15.24% unpaid share was set equal to the node’s negative-price energy share; the Fixed downside versus Node downside LCOE gap arises only from the denominator.')
para('R-10','No 2026 generation series exists','No 2026 generation series exists for the hypothetical site, so no same-year 2026 capture price, project revenue or NPV is reported. As context only, ERCOT’s separate year-to-date West hub file (NP6-785-ER; different from the API series in 423 intervals) gives a fixed-2025-profile-weighted January–September 2026 value of $18.24/MWh, versus $21.36/MWh for January–September 2025 with that year’s profile. West hub prices are negative in 14.1% of 2026 intervals versus 7.7% (23.6% versus 13.7% of the profile’s energy). Compare the reference node’s full-year 2025 interval share of 6.2% in Section 8.2: hub/node and seasonal/full-year measures differ. This is a fixed-profile price diagnostic, not realised 2026 capture. It does not isolate the effect of the December 2025 co-optimisation launch because weather, load, fuel prices and competing capacity also changed. [CL-FIN-08; scenario-versions/data/HB_WEST-2026-JanSep-Post-RTCB-Context.csv]')
append('R-11','Each historical price shape',' Most 2025 intervals predate ERCOT’s December 2025 real-time co-optimisation launch; Section 11.8 gives a separately qualified 2026 diagnostic, not a forecast. Contract alternatives are in Section 10.3.')
rep('R-12','2025 reference capture ratio about 48%, before export response','2025 reference capture ratio about 48%, before export response (near the 3rd percentile of the cross-section; HB_WEST about 65%)')
append('R-13','*Source: multi-year analysis, weather-price comparison',' Left: median NPV across 485 settlement points; centre: TAYGETE2_ALL; right: share of points with positive NPV, not a probability. The colour bar applies to the NPV panels.')
rep('R-14','| Selling electricity to large loads | 1, 6, 8.1–8.2, 13.4 |','| Selling electricity to large loads | 1, 6, 8.1–8.2, 13.4 |\n| Buying electricity or hedges | 1, 6.2, 6.6, 8.1, 10.3, 11.3, 13.4, B.2, Appendix C |')
append('R-14','A contract-reading framework',' Section 10.3 compares the separately versioned hub hedge, Appendix B.2 sets out contract risk allocation, and Appendix C lists the undisclosed terms needed for transaction diligence.')
liq=' For U.S.-listed filers the cash column excludes fixed-term deposits and short-term investments: Daqo also reports fixed-term deposits of $1,035.6m, and JinkoSolar restricted short-term investments of CNY3.30bn.'
append('R-15','**Liquidity and obligations',liq)
append('R-15','*Net working capital',liq)
rep('R-16','Ingots, wafers, cells and modules also bear','If CBP finds an importer’s documentation materially inaccurate, the importer and its affiliates are permanently prohibited from importing polysilicon and derivatives (clause 3).\n\nIngots, wafers, cells and modules also bear')
rep('R-16','Importer-of-record identity and delivery terms |','Importer-of-record identity, delivery terms and accuracy of MIP certification (clause 3 penalty) |')
# P2: clarity refinements without recalculation.
rep('R-17','(3) Historical-year repetition is a stress setting.','(3) Historical-year repetition is a stress setting. (4) Output is simulated and not calibrated to operating plants (Section 9.5).')
append('R-18','The main comparison contains 485',' Counts refer to settlement points: some share identical receipt series (about 400 distinct three-year series among 485), and some are wind or storage resources. These shares do not count independent solar sites. [E-C, three-year node-receipt table]')
rep('R-18','Same-year positive nodes, 2023 / 2024 / 2025','Same-year positive settlement points, 2023 / 2024 / 2025')
rep('R-18','as follows: South 13.','as follows: South 13 (10 distinct receipt series).')
append('R-19','The current owner’s', '') if False else None
append('R-19',"The current owner's 2025 filing",' The filing does not date the default or auction, so the event cannot be attributed to post-2023 operating prices at this node.')
rep('R-20','66.7 | Single rate not certified |','66.7 | No root found (search not certified complete) |')
rep('R-20','the Fixed downside case has no certified unique rate.','the Fixed downside case has no root found, with search completeness uncertified. No root at or above 4.27% was found; NPV is negative at all three tested rates.')
rep('R-20','fixed downside has no numerical root with completeness certified.','fixed downside has no root found, with search completeness uncertified. No root at or above 4.27% was found; NPV is negative at all three tested rates.')
rep('R-21','| Excluded | Correct for unlevered overnight cost |','| Excluded | Excluded by convention; capital timing within the construction year not modelled |')
append('R-21','**Cost scope and vintage.**',' The $24.66 FOM quote refers to 2024 source pricing; its dollar basis has not been separately reconciled here with the ATB workbook. The scenario’s $24.49 uses the 2026 Moderate projection converted from 2023 to real 2025 dollars. The quotes are not a matched cost-year and dollar-year comparison.')
append('R-21','*Source: P.L. 119-21 sections',' For construction starting after 4 July 2026 only the placed-in-service-by-2027 branch can apply.')
append('R-22','*Source: frozen hourly benchmark',' Colours distinguish years. Left panel: circle/square/triangle markers identify yearly mean prices; thin dotted lines with crosses are medians. Right panel: negative-hour incidence by America/Chicago civil-clock hour, not a count of negative 15-minute intervals.')
append('R-22','*Source: original annual cash flows',' Left panel: Node base. Right panel: Fixed base.')
# Remove duplicated structure, preserving the fuller first hedge explanation and the attribute disclosure.
rep('R-22',' The only public structure for Taygete I is a long-term hedge with J. Aron & Company for part of output, plus an unnamed S&P A– rated purchaser.','')
rep('R-22',' The release also names the energy hedge counterparty as J. Aron & Company (Goldman Sachs) for a portion of output, and the other purchaser as an unnamed S&P A– rated entity.','')
rep('R-24',"The developer's release for Taygete I (250 MWac)","The developer’s 9 December 2020 press release (author-supplied screenshot, not an executed agreement) for Taygete I (250 MWac)")
rep('R-22',' In ERCOT, 16 TAC §25.195(f) assigns step-up transformers and protective devices to the generator. It assigns transmission system upgrades to the transmission service provider, and for SGIAs executed after 31 December 2025 it bills the generator for interconnection-facility costs above a CPI-indexed allowance.',' The ERCOT allocation is described above; those allowances cannot be subtracted from the national GCC without a component match.')
rep('R-23','The top 1% of 2023 price intervals contribute 54.7% of median modeled receipts','The median node-level share of receipts from the top 1% of 2023 price intervals is 54.7%')
rep('R-23',"the top 1% of 2023 price intervals generate 54.7% of the median node's modeled receipts","the median node-level share of modeled receipts from the top 1% of 2023 price intervals is 54.7%")
rep('R-23','higher benchmark prices','higher HB_BUSAVG hub prices') if 'higher benchmark prices' in s else None
rep('R-23','lower benchmark prices after accounting','lower HB_BUSAVG hub prices after accounting')
rep('R-23','approximately $66/MWh prediction error','approximately $66/MWh root-mean-square prediction error')
rep('R-23','## 11.6 Crossed weather and price years reveal the source of model sensitivity','## 11.6 Crossed weather and price years locate the model’s sensitivity')
rep('R-23','## 11.7 The change comes mainly from the price setting','## 11.7 Model accounting assigns most of the change to the price setting')
rep('R-23','| Controlled comparison | Change in NPV, $m |','| Comparison (baselines differ) | Change in NPV, $m |')
append('R-23','*Source: multi-year analysis, tail-stress',' Tail stresses use full annual calendars, unlike the common-calendar matrix in Figure 11-3.')
append('R-23','*Source: multi-year analysis, within-year resampling',' Tail and resampling inputs use full annual calendars; the common-calendar matrix is a separate comparison.')
rep('R-23','the median node needs approximately **44.9%**','the median of node-level required weights is approximately **44.9%**')
rep('R-23','in the corrected panel |','in the 485-point common-calendar panel |')
# Precision in trade, reporting and source-date labels.
rep('R-24','Several Chinese producers carry large current borrowing obligations alongside their cash.','Several Chinese producers carry large short-term borrowings and current maturities of non-current liabilities (which may include leases) alongside their cash.')
rep('R-24','| Short-term borrowings and current portion |','| Short-term borrowings and current maturities (may include leases) |')
append('R-24','Ingots, wafers, cells and modules also bear',' These country arrangements concern the additional ad valorem duty, not the MIP. The Secretary may adjust the MIP under clause 1(b). On the face of the text, covered China-origin goods fall under both the MIP programme and the 15% duty; this is a reading of the proclamation, not a customs ruling.')
rep('R-24','Indonesia and Laos feature prominently in the 2025–2026 import mix (Section 5.8), so any resulting orders would further separate customs value from delivered project cost.','India, Indonesia and Laos supplied about 61.5% of January–August 2025 module import value versus about 12.7% in 2026 (modules only; Section 5.8). Commerce also made affirmative critical-circumstances findings in part. Any resulting orders would further separate customs value from delivered project cost.')
rep('R-24','retrieved on 10 October 2026, shows','retrieved on 10 October 2026 (RECAP record last refreshed 16 September 2026), shows')
rep('R-24','**P02.** Notice 2025-42 (beginning of construction, wind and solar) (2025-08-15):','**P02.** Notice 2025-42 (beginning of construction, wind and solar) (2025-08-15; vacated in full 6 June 2026, F08 and Section 10.8; history only):')
# Client-facing language; internal archival labels remain verbatim in Appendix E.
rep('R-25','Closure-integrated candidate edition | 9 October 2026','Candidate research edition | 10 October 2026')
body,internal=(s.split('# Appendix E.',1) if '# Appendix E.' in s else (s,''))
body=body.replace('frozen','retained').replace('panel calculations','accompanying calculations')
s=body+('# Appendix E.'+internal if internal else '')
changes.append({'revision':'R-25','operation':'client-body terminology only','before':'frozen / panel calculations','after':'retained / accompanying calculations; Appendix E unchanged'})
rep('R-25',"ERCOT's March process table records 238.6 GW in the 2030 request column against approximately 5.8 GW observed energized on a different, historical noncoincident basis.","ERCOT’s March process table records a 238.6 GW total across all statuses in the 2030 request column, of which about 5.8 GW is observed energized; the latter is a historical noncoincident measure.")
rep('R-25','238.6 GW requested versus about 5.8 GW observed energized; different measures','238.6 GW total across all statuses, of which about 5.8 GW is observed energized; different time bases')
append('R-25','*Source: the SEC filings',' First Solar’s margin includes about $1.6bn of Section 45X credits recognised in FY2025 cost of sales; it is not directly comparable with manufacturers without equivalent support.')
rep('R-25','Self-supply power capacity: about 83% gas, 11% solar','11 WLPUN projects: about 83% gas and 11% solar by power capacity, not energy; not a census')
append('R-25','*Sources: scenario results [S08]',' LCOE is real; the break-even price is flat nominal, so the two are not directly comparable.')
rep('R-25','| Module share of PV-only cost benchmark | 26.1% | National component model; 5.5 |','| Module share of PV-only cost benchmark | 26.1% | About 23% of total scenario CAPEX; cross-benchmark illustration; 5.5–5.6 |')
rep('R-02','The fixed-price route is a simplified node-level paid-volume arrangement','The simplified node-level fixed-price route is a paid-volume arrangement')
# Harmonise product label and cost-scope references in the later decision sections.
rep('R-02','The two revenue routes are a nodal merchant setting and a simplified fixed-price contract.','The two revenue routes are a nodal merchant setting and a simplified node-level fixed-price route.') if 'The two revenue routes are a nodal merchant setting and a simplified fixed-price contract.' in s else None
rep('R-02','Simplified node PPA','Simplified node-level fixed-price route')
rep('R-02','the fixed route needs about $66/MWh flat nominal','the simplified node-level fixed-price route needs about $66/MWh flat nominal (see Section 10.3 for the hub-hedge range)')
rep('R-02','About $66/MWh flat nominal, or $577/kWac on the nodal route','About $66/MWh flat nominal on the simplified node-level fixed-price route, or $577/kWac on the nodal route (hub-hedge range: Section 10.3)')
rep('R-06','The $0.38/W versus $0.29/Wdc comparison remains conditional','The $0.38/W versus $0.29/Wdc comparison remains conditional') if False else None
rep('R-06','Covered import rules may limit transmission; the $0.38/W versus $0.29/Wdc comparison remains conditional on compatible product and denominator definitions.','Covered import rules may limit transmission; the comparison with the subsidy-adjusted U.S.-assembled benchmark defined in Section 1.1 remains conditional on compatible product, date and denominator definitions.')
para('R-22','**A hub hedge requires two revenue legs.**','**Hedge scope.** REC proceeds and fees are separate from the two energy-settlement legs above. Fixed-shape hedge quantities, shutdown provisions and losses can break the matching-volume simplification. A hub hedge transfers price and shape exposures; substituting hub prices for node receipts does not model the hedge.')
# R-27: optional customer aid, using defined fields only; no indicative contract terms.
append('R-27','A contract-reading framework','\n\n**Contract questions before comparing headline prices.**\n\n| Question | Field to reconcile |\n|---|---|\n| What is bought and what is paid? | Energy versus environmental attributes; metered generation versus contracted quantity; payment suspensions |\n| Where does it settle? | Physical node and financial hub; node-to-hub basis allocation |\n| What happens after the term? | Contract tenor, remaining asset life and merchant-tail price assumption |\n| Who carries adverse events? | Negative-price rules, shortfall obligations, imbalance, fees and collateral |\n| Is the offer executable? | Counterparty credit, guarantees, termination, change-in-law and actual executed terms |\n\n*Source: Section 10.3, Appendix B.2 and Appendix C. Questions restate analytical fields, not indicative market terms.*')
# Keep the executive-summary expansion close to the requested 150 words by compressing existing prose, preserving qualifiers.
para('Summary length','The 2025 system produces','The 2025 system produces 292.4 GWh of potential AC electricity and delivers about 247.8 GWh after stopping negative-price exports. Equipment savings affect only part of cost; contracts determine which output is paid and when.')
para('Summary length','TAYGETE2_ALL is a reference price location','TAYGETE2_ALL is a price reference, not a verified settlement relationship for the simulated site (8.1). In the separate 2025 cross-section, its absolute weighted price is near the 37th percentile but its ratio to its own average is near the third: different measures. The three-year panel’s 2025 median NPV is -$81.3 million; neither the reference nor the panel describes the entire market. [R-B, E-A]')
para('Summary length','Each historical price shape','Each price shape is repeated in real terms for 30 operating years. Positive 2023 results assume persistence, not an expected return. Concentrated receipts make contract structure and exposure to scarce high-price hours central diligence questions. Most 2025 intervals precede December’s real-time co-optimisation launch; Section 11.8 gives a qualified 2026 diagnostic, not a forecast, and Section 10.3 compares contracts.')
para('Summary length','Manufacturers can use Chapters','Manufacturers can use Chapters 4–5 for procurement screening and developers Chapters 8–11 for capital-recovery tests. Sellers should qualify the buyer’s delivery profile, connection and ability to pay for reliable supply. Actual procurement, taxes and financing remain project-specific.')
para('Summary length','The revised credit illustration','Excluding national grid-connection cost from the assumed basis gives a **$35.38m** credit PV and **−$50.59m** reference NPV: pre-tax NPV plus an illustrative 30% credit received at end-2027, conditional on eligibility, not after-tax value. The six original pre-tax scenarios are unchanged. Nine named ERCOT plants disclose no definition-matched IRR or cash flows; cost and operating comparables are diligence checks, not return benchmarks. [F01–F05]')
rep('Summary length','Selected manufacturers report losses even as deployment expands. Neither observation determines the economics of a particular supplier contract or solar asset.','Selected manufacturers report losses despite deployment growth. Neither observation determines contract or asset economics.')
(O/'Integrated-Market-Research-Report-EN_Reviewed-Candidate.md').write_text(s)
(O/'Editorial-Operations.json').write_text(json.dumps(changes,indent=2,ensure_ascii=False))
print(json.dumps({'operations':len(changes),'output':str(O),'chapter1_word_change':len(s.split('# 2. Analytical')[0].split())-len(before.split('# 2. Analytical')[0].split())}))
