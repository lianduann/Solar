"""Focused editorial checks on retained results. No regressions or financial models."""
from pathlib import Path
import hashlib,json,re,csv,collections
import pandas as pd
D=Path(__file__).resolve().parents[1];S=D/'support';S.mkdir(exist_ok=True)
s=(D/'Integrated-Market-Research-Report-EN_Reviewed-Candidate.md').read_text();b=(D/'internal/Closure-Integrated-Input.md').read_text();checks=[]
def ck(name,passed,evidence,actual=None):
 checks.append(dict(check=name,passed=bool(passed),evidence=evidence,actual=actual))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Review arrival integrity: each manifest line is bounded by the review directory.
for fn in ['SHA256SUMS.txt','File-Manifest.csv']:
 if (D/'review'/fn).exists():pass
# Input estimates retain all numerical cells in the original primary tables.
def table(t,id):
 part=t.split('**Table '+id+'.',1)[1].split('\n\n',2)[1]
 rows=[l for l in part.splitlines() if l.startswith('|')];assert len(rows)>2,(id,len(rows));return rows
for id in ['4-2','10-1','10-2','10-4','10-5','11-2']:
 old=table(b,id);new=table(s,id)
 numbers=lambda rows:[[re.findall(r'[-−+]?\d+(?:[,.]\d+)*%?',c) for c in l.split('|')[2:]] for l in rows[2:]]
 ck('Unchanged numeric cells Table '+id,numbers(old)==numbers(new),'internal/Closure-Integrated-Input.md and current manuscript')
ck('Appendix C undisclosed-fields table unchanged',table(b,'C-1')==table(s,'C-1'),'Appendix C')
v=pd.read_csv(D/'scenario-versions/data/VPPA-Breakeven-Strikes.csv');v=v[(v.price_year==2025)&(v.discount_rate==.0427)]
ck('Hedge range 60.6–84.8, 8 settings',len(v)==8 and round(v.breakeven_strike_nominal_flat.min(),1)==60.6 and round(v.breakeven_strike_nominal_flat.max(),1)==84.8,'scenario-versions/data/VPPA-Breakeven-Strikes.csv',v.breakeven_strike_nominal_flat.tolist())
x=pd.read_csv(D/'data/supplement/A/A_pvscm_item_level_pv_only.csv');m=x[x.category=='Module'];net=m.mmp_usd_per_kwdc.sum()/1000;sub=m.loc[m.item=='Subsidy','mmp_usd_per_kwdc'].sum()/1000
ck('Module cost 0.29, subsidy -0.07, before 0.36',round(net,2)==.29 and round(sub,2)==-.07 and round(net-sub,2)==.36,'data/supplement/A/A_pvscm_item_level_pv_only.csv',dict(net=net,subsidy=sub,before=net-sub))
x=pd.read_csv(D/'data/empirical/C_three_year_mixture_scenario_by_node.csv');x=x[x.tier=='strict'];cols=['rev_2023','rev_2024','rev_2025'];pos=x[x.npv_2024>0]
ck('485 points / 400 receipt series; 13 positives / 10 series',len(x)==485 and len(x[cols].drop_duplicates())==400 and len(pos)==13 and len(pos[cols].drop_duplicates())==10,'data/empirical/C_three_year_mixture_scenario_by_node.csv')
x=pd.read_csv(D/'scenario-versions/data/HB_WEST-2026-JanSep-Post-RTCB-Context.csv');x=x[x.period=='Jan-Sep'].set_index('year')
ck('2026 diagnostic 18.24 / 21.36 and energy shares 23.6 / 13.7',round(x.loc[2026,'profile_weighted_usd_mwh'],2)==18.24 and round(x.loc[2025,'profile_weighted_usd_mwh'],2)==21.36 and round(100*x.loc[2026,'profile_energy_share_negative'],1)==23.6 and round(100*x.loc[2025,'profile_energy_share_negative'],1)==13.7,'scenario-versions/data/HB_WEST-2026-JanSep-Post-RTCB-Context.csv')
x=pd.read_csv(D/'data/r2/A/A_census_hs854143_by_country.csv');a=x[(x.period=='Jan-Aug')&x.CTY_NAME.isin(['INDIA','INDONESIA','LAOS'])].groupby('year').share_of_total.sum()*100
ck('Module import shares 61.5 / 12.7 rounded',round(a[2025],1)==61.5 and round(a[2026],1)==12.7,'data/r2/A/A_census_hs854143_by_country.csv',a.to_dict())
for company,value in [('Trina','-1.42'),('JASolar','-4.03'),('Tongwei','-0.38'),('LONGi','0.81')]:
 path=D/f'closure-evidence/sources/cninfo/{company}_2025_AR.txt';t=path.read_text();locations=[i+1 for i,l in enumerate(t.splitlines()) if value in l]
 ck('Product-basis margin '+company, bool(locations),str(path.relative_to(D)),dict(value=value,lines=locations))
import fitz
pdf=D/'closure-evidence/sources/cninfo/LONGi_2025_AR.pdf';t=fitz.open(pdf)[296].get_text()
ck('Export VAT rebate locator p297',('2026' in t and '4' in t and '取消' in t and '退税' in t),str(pdf.relative_to(D))+' physical p297')
t=(D/'closure-evidence/sources/trade/FR-2026-16400_plain.txt').read_text()
ck('Proclamation clause3 permanent prohibition retained',bool(re.search(r'permanently\s+(?:be\s+)?prohibited',t.lower())),'closure-evidence/sources/trade/FR-2026-16400_plain.txt clause3')
x=pd.read_csv(D/'data/empirical/plot_inputs/F6_hourly_HB_BUSAVG_and_system_solar.csv');hour=pd.to_datetime(x.utc,utc=True).dt.tz_convert('America/Chicago').dt.hour
ck('Figure8-4 civil-clock labels',bool((hour==x.local_hour).all()),'data/empirical/plot_inputs/F6_hourly_HB_BUSAVG_and_system_solar.csv')
ck('Figure8-4 dotted medians cue', 'thin dotted lines with crosses are medians' in s,'scripts/render_all_figures.py F6 and manuscript caption')
# No link requests: only existence checks on supplied local paths.
links=[]
for label,target in re.findall(r'\[([^\]]*)\]\(([^\s)]+)\)',s):
 if target.startswith(('http:','https:','#')):continue
 if label.startswith('Figure') or not target.startswith(('http:','https:')):
  links.append(dict(target=target,exists=(D/target.split('#')[0]).exists()))
ck('Manuscript local links',all(x['exists'] for x in links),'Markdown local targets',links)
for field in ['pre-tax','not an after-tax','not a forecast','not an observed','not calibrated','candidate']:
 ck('Retained scope qualifier '+field,field in s.lower(), 'Current manuscript')
body=s.split('# Appendix A.',1)[0]
terms=['frozen','panel calculations','closure-integrated']
search={x:len(re.findall(re.escape(x),body,re.I)) for x in terms}
ck('Internal terminology absent from client body',not any(search.values()),'Client body only',search)
ck('Covered revision IDs',set(re.findall(r'R-\d+',json.dumps(json.loads((D/'Editorial-Operations.json').read_text()))))>=set(f'R-{i:02}' for i in range(1,26)),'Editorial-Operations.json')
# R26 is cross-reference only; R27 optional implemented.
res=dict(scope='Focused editorial checks; no original-source reacquisition, regression, simulation, decomposition or baseline financial rerun.',checks=checks,passed=sum(c['passed'] for c in checks),failed=[c for c in checks if not c['passed']])
(S/'Reviewed-Editorial-Checks.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps({'passed':res['passed'],'failures':res['failed']},ensure_ascii=False));assert not res['failed']
