# SOLAR-001：真实项目可比研究与财务模型深化——Claude 执行任务

**编制日：2026-10-09；时区 America/New_York。状态：待执行的研究委托，不是已完成研究或实际工时。**

## 1. 任务、背景和边界

请在本机实际收集、保存、核对和整理公开财务证据，目的是将英文报告中的简化情景财务分析，推进为可与现实项目比较的现金流研究。不是寻找一个“行业 IRR”来证明项目赚钱或不赚钱，也不是重跑既有回归。

项目绝对路径：
`/Users/duanlian/Desktop/OPT-Self-Employment/03-Work-Evidence/Projects/2026-08-SOLAR-001-AI-Power-Solar-Economics/`

工作区：`/Users/duanlian/Desktop/OPT-Self-Employment/`

先遵守工作区 AGENTS.md，读 README.md、PROJECT_STATUS.md、项目 Project-Brief.md、Methods-and-Data.md。需要个人规划背景时，以 `/Users/duanlian/.codex/personal-planning-archive/` 为 canonical。不得访问、列出、搜索 `90-Private-Documents/`。所有联网按 web-access skill 执行；不登录、不注册、不付款、不联系、不发送邮件、不发布、不安装依赖，除非另获授权。一个来源受阻时继续其他工作。

本轮修订版（以此为整合目标，旧版仅供历史追踪）：
`Deliverables/2026-10-09_Panel-Revision-Client-Edition/`
- `Integrated-Market-Research-Report-EN_Panel-Revised.md` / `.pdf`
- `data/scenario_metrics.csv`
- `data/scenario_annual_cash_flows.csv`
- `data/scenario_input_register.csv`
- `data/breakevens.json`
- `data/sensitivity_one_way.csv`
- `data/price_pairing_checks.json`
- `data/empirical/` 和 `data/r2/`
- `scripts/derive_panel_tables.py`、`data/panel/Panel-Calculations.json`、`Panel-Review-Disposition-and-Change-Log.md`

联合评审：`/Users/duanlian/Downloads/2026-10-09_Panel-Review_EN-Report_Expert-Version.md` 和 `/Users/duanlian/Downloads/2026-10-09_Panel-Review_EN-Report-Client-Readable.md`。评审中标记为外部知识的内容只是待核实线索，不能当作已验证事实。本轮正文已按联合评审修订，缺口编号见下；**不要修改任何既有报告、冻结数据、模型 register 或质量状态**。完成后交给 Codex 整合。

当前模型：Pecos County 假设性 100 MWac / 132 MWdc 独立光伏系统；2026 年末一次性投资、2027–2056 年运营；以 2025 美元计实值；税前、无杠杆、无税收抵免和折旧税盾。节点路线重复历史价格形态并在负价时停发；固定路线以 $40/MWh 的 30 年名义平价、15.24% 不付费电量为基准。4.27% 是从 ATB 债务/股权输入推导的分析折现率，不是已验证项目 WACC。2025 节点参考 NPV 约 −$86m、固定基准约 −$73.7m。已有 6%/8% 比较；实证节点共同样本 485。2023 的正值依赖价格尾部，三年不能生成盈利概率或 P50/P90。

这些是现有情景结果，不是 Taygete II 或任何已运营项目的实际收益。TAYGETE2_ALL 的场址—资源—结算链尚未完整建立。事实模型门槛仍 blocked/null；可比证据不能冒充本案例输入。

## 2. 成功条件和研究顺序

先完成 P0，再推进 P1。尽可能做到 6–10 个有实名、有一手资料的候选可比案例，深挖其中 3 个；若公开披露不足，交付真实可用样本，不为凑数量使用低质数据。优先 ERCOT / 西德州、独立光伏、2023–2027 COD、跟踪系统、规模接近 50–300 MWac；放宽地域、规模或 COD 时记录差异。储能混合项目、分布式项目和企业组合单列，不能直接进入独立光伏 IRR 范围。

**P0-A：本案例最影响财务口径的证据。** 税收时点/适用约束、ATB FOM 范围、实际合同结构、节点与枢纽基差、实际发电对照。

**P0-B：可比案例证据。** 实际成本、合同、融资、税务和披露回报。先找到资料完整的项目，再决定样本；不要先选定“回报较好”的项目。

**P1：形成可输入模型的参数建议和后续计算规格。** 区分直接证据、公开参考、派生计算、分析假设。没有实测现金流不能称 realized IRR；没有债务偿付表不能反推精确股权 IRR。

## 3. 可比项目怎么找，怎么避免伪比较

优先原始项目文件：公司投资者关系公告/投资者演示、SEC 10-K/20-F/8-K 及合同附件、项目融资公告、银行/开发商原始披露、县土地及税收减免协议、Texas Comptroller 公开项目协议、EIA-860/923、ERCOT 资源/节点映射、官方 PPA 或采购公告。政府研究、Berkeley Lab / DOE / ATB、原始市场指数作为参数参考，不冒充逐项目数据。

可用线索包括西德州 Taygete/Taygete II 及附近已运营电站；也可选择其他资料更完整的 ERCOT 项目。每个名字都先核验实体、阶段、容量和 COD。公司融资总额、资产出售 enterprise value、tax-equity commitment、开发商 target return，都不是建设 CAPEX 或已实现项目 IRR。

公开原文未披露 IRR 时：写 `not disclosed`。若有完整现金流足以独立重建，可计算 **reconstructed scenario IRR**，逐项标明假设；否则只比较可观察的 $/W、PPA 条款、成本、杠杆和债务价格。不能用股价收益率、基金 IRR、企业 ROIC、会计利润率或收购 yield 代替项目 IRR。

所有回报须标注：project/equity/tax-equity；pre-tax/post-tax；nominal/real；levered/unlevered；gross/net fees；target/underwritten/reconstructed/realized；valued at FID/COD/acquisition；税盾和终值是否包含；期限、币种、美元基年。口径缺失的回报不得进入可比区间。

## 4. 逐项目数据字典（允许未披露，不允许猜填）

| 模块 | 需要的字段 | 为什么影响结果 |
|---|---|---|
| 身份与容量 | 项目/阶段/法律实体、开发商、县/坐标、EIA plant/generator ID、ERCOT resource/node、MWac/MWdc、技术、FID/NTP/COD/估值日 | 防止同名、阶段或容量口径错误 |
| 造价与时序 | EPC、组件/逆变器/BOS、开发、土地、接入设施、owner cost、contingency、IDC/费用、DSRA/流动资金、各期支出、建设通胀 | 区分 overnight cost、all-in funded cost、交易价格 |
| 发电 | 月度/年度净发电、铭牌、容量因子、同年天气、P50/P90 原文、损失/可利用率/退化、经济停发/限电 | 检验 33.4% AC 情景，区分预测和运营实绩 |
| 收入合同 | 买方、信用支持、实物/虚拟/套保、COD起止、价格币种基年/escalator、交付点、settlement index、as-generated/block/shape、REC归属、负价条款、基差/形状/弃电风险 | 不能把 hub strike 直接当 node 固定收入 |
| 商户尾段 | 合同覆盖比例和期限、tail价格/曲线来源与日期、node-hub basis、QSE/imbalance/route-to-market、hedge fees、价格下限/上限 | 10–15 年合同之后仍需独立尾段假设 |
| 运维与其他现金成本 | O&M/asset management、租金、保险、财产税/PILOT、输电/接入维护、QSE、REC服务、安保/水洗、逆变器更换、拆除与残值、escalator | 核对 FOM 已含项；防止重复加 land/tax/insurance/replacement |
| 税收 | 45Y或48E选择、begin-construction与placed-in-service证据、PWA、加成、eligible basis、PFE/material assistance、transfer price及timing、MACRS/bonus、税率、basis reduction、recapture、tax-equity成本 | 税收好处有条件且不是简单 30% × 全CAPEX |
| 债务 | 建设贷/长期贷、amount/debt fraction、base rate+spread/fixed coupon、tenor、amortization/sculpting、DSCR/LLCR、cash sweep、reserves、fees、refinance/balloon | 实际股权现金流与 WACC 需要这些项 |
| 回报与退出 | sponsor投入/分配、tax equity分配/flip、项目与股权IRR/MOIC/NPV口径、hurdle、终值/出售成本、假设日期 | 区分回报要求与可实现收益 |

每个字段同时保留：原文值/单位、归一化值/单位、时间/基年、来源URL、保留文件相对路径、页码/表格/原文段落、获取时间、SHA-256、evidence_type、状态、转换公式、可比性限制。只写有证据的字段。`unknown` 不等于 0。

## 5. 本案例专门补证任务

### 5.1 商业结构与 HB_WEST 对照

核验 TAYGETE2_ALL 对应资源、电站/阶段、负荷区/结算区、EIA ID、地理位置，列证据链；名字相似不是映射证明。未闭合不改变事实模型状态。

先读取本轮 `data/panel/Node-Hub-Comparisons.csv`、`data/empirical/` 和谱系；三个价格点的现有比较已经完成，不重复取数或重跑。仅在新增真实合同/结算版本要求时从保留 NP6-905-CD 档案补证；使用现有同年光伏权重与共同日历。输出 time-weighted price、generation-weighted price、capture ratio、generation-weighted node−hub basis、可用区间数/DST/单位。不得用小时基准替换 15 分钟结算序列；不得插值共同缺失区间。找不到权重时交付取数目标，不自行重跑模拟。

给出可执行合同恒等式：虚拟 PPA 在匹配成交量且未计费时，收入 = G×P_node + H×(K−P_hub) + REC − fees，其中 H 与 G 可能不同；H=G 时可化为 G×(K+P_node−P_hub)。明确 shape、volume、negative-price、basis 风险。找真实期限及报价证据，不预设 10–15 年为所有项目标准。

### 5.2 发电实绩对照

取得 EIA-860（MWac、状态/COD）和 EIA-923（月度净发电）中可比电站的 2023–2025 完整月数据，优先本县或邻近。新投运/扩建/限电/储能混合/多机组聚合单列。容量因子分母用同年在运容量×小时，闰年和部分年单列。未经同年气象和设备边界归一化，只作 sanity check，不把不同电站的月发电量直接校准为本假设系统实测值。

### 5.3 FOM 与接入成本范围

查现有 ATB/PVSCM 官方定义及明细，逐项确认土地、保险、财产税、部件更换是否包括；保留与现金流成本行的 crosswalk，列重复计费风险。取得 ERCOT/PUCT connect-and-manage 与接入成本分配原文，区分自身接入设施、共享输电升级、拥塞/经济停发和合同补偿，不能照搬其他 ISO 升级费用规则。

### 5.4 税收与时点（法律原文优先，不提供个案税务意见）

核验截至取证日的公法、IRS Notice 2025-42、Notice 2026-15 及后续正式修订：45Y/48E、风光开工/投运节点、PWA、加成、FEOC/PFE/material assistance、safe harbor、适用日期/例外。核对专家提出的截止日而非直接抄写；区分“2027 年末投运分支”和“较早开工分支”，不要误写两者必须同时满足。2026 年末付款不是 begin construction 证明，2027 年发电年份也不是实际 PIS 证明。

输出 decision tree 和本情景需额外证明的事实；同时收集 ITC/PTC 转让、basis adjustment、折旧、tax-equity waterfall 的输入，不选择项目资格，不把税收情景写成已获收益。

### 5.5 折现率、市场 PPA 和回报

找公开的 ERCOT/美国公用事业光伏 PPA 原始报价指数，保留 technology/region/tenor/vintage、报价分位数、nominal $/MWh、escalation、hub/node、REC、negative-price条款。LevelTen 等公开摘要可作为市场报价参考，若收费报告或账户受限则记录；不得付费。报价与 30 年固定价 break-even 不直接相比，需解释期限与尾段。

找 ATB 财务假设来源、原始项目融资公告及披露回报；分别给 contracted/merchant 的融资参考，不能声称从几个项目识别出市场分布。名义转实际使用 (1+r_nom)/(1+inflation)−1；税前/税后调整缺税务信息则不可强行归一化。股权IRR不能用于给无杠杆项目现金流直接贴现。

### 5.6 收入尾部与市场结构背景

核验 ERCOT 2023 官方 EEA2/需求纪录、储能增长和 RTC+B 实际上线日与机制。2025 年末上线意味着 2025 档案可能跨机制，**不能一概说 2023–2025 全部在上线前**。提供日期与样本切分建议，不做新的回归或因果解释。

## 6. 下一步模型规格（先交证据，再建议；不要替换旧模型）

提出一个可实现的年度现金流结构：建设分期→净发电→合同+商户+REC收入→完整不重叠OPEX→EBITDA→折旧/税务→资本开支/流动资金→无杠杆税后CF；另一条加 debt draw/fees/interest/principal/reserves→equity CF。ITC/PTC择一/独立方案，tax equity/credit transfer 不得重复计益；不同时把债务利息从无杠杆CF扣除再用WACC折现。

建议可算的分层版本：
1. 保留现有税前无杠杆基准；补 0%/15.24%/30.48% payment stress 的作用。
2. 公开合同约束下的 10/15 年 PPA + 商户尾段，node/hub basis 与结算量分别明确。
3. 明确资格假设的 ITC 或 PTC 税后无杠杆情景；含折旧、basis及转让折价。
4. 只有融资输入充分时添加 levered equity case、DSCR/LLCR、现金分配与 IRR/MOIC。

每层标明哪个字段是 observed/reference/assumed/unknown，无法计算的结果保持 null。可提供计算规格或隔离的演示脚本；**不要运行旧回归、改旧估计、创建伪精确融资结果**。MIRR若建议使用，必须说明finance/reinvestment rates与currency basis，不比IRR天然更客观。多重IRR保留全根，只在有定义的经济根规则下补可读主根。

## 7. 输出、验证与移交

请新建（保留历史冻结包）：
- `Analysis/2026-10-09_Finance-Deepening/Claude-Research/`
- `Data/raw/2026-10-09_Finance-Deepening/`
- `Deliverables/2026-10-09_Finance-Deepening-Supplement/`
实际执行日晚于编制日时，把执行日期另记清楚；不要倒填日志。

必须输出：
1. `Findings-and-Replacement-Text-EN.md`：专业英文可直接整合文本，逐条来源；对“项目是否划算”给适用范围而非全行业结论。
2. `Comparable-Projects.csv` 与 `Return-Metric-Comparability.csv`：原始回报和可比性分组，缺失IRR不填估算值。
3. `Project-Finance-Input-Evidence.csv`：逐字段证据与精确缺口；`Cost-Coverage-Crosswalk.csv`；`Contract-and-Tax-Decision-Tree.md`。
4. 能实际取得则交 `Node-Hub-Solar-Capture-2023-2025.csv`、`EIA-Operating-Generation-Comparables.csv`；同时交清洗脚本、共同日历和单位处理记录。
5. `Model-Upgrade-Specification.md`：现金流公式、输入依赖、避免重复计费及后续情景，明确不能算的结果。
6. `Source-Catalog.csv`：保留原件、URL、原文位置、获取时间、哈希、使用限制；`Research-Log.md` 仅记实际操作和结果，不记猜测工时。
7. `Gap-Disposition.csv`（addressed/partial/blocked；不得把其状态映射为原验收 Met）、`Access-Blockers.md`（网站/具体文件或字段/尝试/下一步；需手动取数写精确步骤）。
8. `README.md`、清洗复现入口、manifest、SHA-256 与 ZIP。原始来源过大或限制再分发时不硬塞包内，README说明依赖；不要因ZIP成功声称来源通过验证。

在干净输出目录运行本次清洗/派生，不重新拟合研究；核对容量单位、时间戳、现金流单位和原文位置；至少独立核算一个关键可比项目的可观察指标。若无完整现金流则明确“不能验证IRR”。所有会改变主报告结论的数字列出计算和证据；先把有证据的成果做完，再列需要授权/作者决定的具体事项。

## 8. 自主调整空间与停止条件

可以按资料可得性更换可比项目、缩小样本、选择更完整的原始来源、改进表结构或提出更适合的金融模型。可以指出专家评审错误，包括时间、税收逻辑、口径和因果过度解释。不得为了让IRR看起来合理而选择有利案例、填补未知合同/税务/债务条款或降低原验收门槛。

每个重要受阻来源在一次合理替代路径之后记入blockers，继续其他成果；不重复搜一般说明页。作者真正需要决定的是研究情景取舍或授权事项，常规文件处理和公开资料收集请自主完成。最后中文简报：实质新增、可直接整合文本、可比IRR是否足够可比、仍缺什么、下一模型能算到哪一层、必须授权的事项。不要更新实际工时/周日志。


## 追加：本轮报告占位符的精确交接（以上背景与此处不一致时，以此处及当前冻结输出为准）

这份任务不是再次审稿。请实际取得可用证据、整理小表和给出可复算财务情景规格。优先公开、免费的一手资料；遇到缺乏 IRR 披露时，继续成本、合同、融资、税收和实绩，不为凑 IRR 样本停工。未经明确授权不登录、不注册、不付费、不安装、不联系。不得重跑既有回归、自助法、天气仿真；可在独立新目录写财务算术/现金流脚本，不覆盖旧模型，不把尚未取得的资料猜填进模型。

### A. 本轮已解决事项，请勿重复补做

- 原 MIIT PDF 为保留的原始证据，无需再索要 HTML；原文仅披露多晶硅和组件两项价格变化，不能添硅片/电池价格跌幅。
- 天合、晶澳、通威购建长期资产现金支出均核对到合并现金流量表；晶澳 FY2025 归母亏损为 46.08 亿元，FY2024 为 46.56 亿元，原 FY2025 列未取错。
- 模块成本传导现在只作用于 PV overnight cost（126.04m），连接成本（17.63m）不变；每降低美国组件输入 10%，税前 NPV 增加 3.765m。不能再对总 CAPEX 乘整个组件成本百分比。
- 名义税收现金敏感性：2026 年名义基础×30%，固定该名义金额于 2027 年末收取，折算现值 40.329m；节点 NPV −45.636m。假定全 CAPEX 合格本身未经证实，不能拿示例当实际抵免。
- 固定路线去除 15.24% 不付费后，名义保本价为 55.914/MWh，而非原严重支付压力下的 65.969/MWh。
- HB_WEST 的 2025 同出力加权价为 21.463/MWh，参考节点为 22.134；不能预设转到 West hub 就改善收益。HB_BUSAVG 是 ERCOT Bus Average 345-kV Hub，非四枢纽简单平均。
- RTC+B 正式上线日为 2025-12-05：2025 跨越上线日，并非全年在新规则前。尚无本研究的规则或储能因果效应。
- 2023–2024 历史电价未 CPI 统一，现有计算将历史数值重用为固定实值情景；保留原值，后续 CPI 统一需另起版本。
- 稀缺日期的 −82.54m 是删除该日收入；另有用非稀缺日收入中位数替换的版本。不是替换电价曲线。

### B. 正文占位符—证据—模型衔接

| 编号 | 正文位置 | 实际需要取得什么 | 可交付的小表/后续计算 |
|---|---|---|---|
| FIN-01 | 10.9、附录 C | 有实名、可比现金流口径的项目/交易；实际披露 IRR 的定义与估值时点；债股成本/投资门槛原文 | Comparable-Projects.csv + Return-Metric-Comparability.csv；无完整现金流就不编 IRR |
| FIN-02 | 第9章 | 860/923 同年、同装机边界的实际净发电、COD、技术/跟踪/双面、限电与可利用率解释 | EIA-Operating-Generation-Comparables.csv；闰年/部分年单列；未匹配不校准 |
| FIN-03 | 10.3、附录 B | 公开 PPA/VPPA、hub/node、as-generated/block、tenor、strike/escalator、负价/弃电/基差/REC/信用支持 | Contract-Terms.csv；节点/枢纽两条结算腿；10/15年+尾段现金流，尾段缺失时保留 null |
| FIN-04 | 10.8 | BOC/PIS、PWA、48E/45Y选择、eligible basis、PFE设备与纳税主体、transfer/tax-equity、depreciation/recapture | Tax-Eligibility-Matrix.csv、Basis-Crosswalk.csv；ITC/PTC after-tax 情景规格，不作个案税务判断 |
| FIN-05 | 5.6、10.7 | U.S. delivered/EPC 报价，完整建设与 FOM 范围，ERCOT 接入合同与费用分配 | Cost-Coverage-Crosswalk.csv；含/不含/未知、重复项，OCC/GCC/IDC/储备分离 |
| FIN-06 | 8.1 | 实体/阶段—EIA—ERCOT resource/node 历史映射，选择参照理由 | Entity-Node-Mapping.csv，逐链接原文依据；名字相同不能闭环 |
| FIN-07 | 10.9、B.2 | CPI 同基年与历史电价、未来通胀、成本基年对齐 | Currency-Timing-Crosswalk.csv；新 CPI 统一情景旁列旧输出，不改估计 |
| FIN-08 | 11.8 | RTC+B 后正式价格及版本，电池/停运/约束/进口、市场报告 | Regime-Evidence.csv；后续 merchant 价格假设的依据，不直接因果推断 |
| FIN-09 | 第4章 | 现金受限、营运资金、债务到期、保障与质保、激励、厂址与股权 | Supplier-Liquidity.csv；制造45X与项目48E/45Y分开；无依据不打违约概率 |
| FIN-10 | 附录 C | 借款金额、利率/基准+spread、期限/sculpting、DSCR、reserve/fees、cash sweep、税股flip及分配 | Debt-and-Waterfall-Inputs.csv；债务偿付/税后权益现金流规格；无条款不编精确equityIRR |
| FIN-11 | 附录 C | 最终价格修订链、DST/损失、QSE/imbalance费用、REC收入、合同净额 | Settlement-and-Net-Receipts.csv；毛收入到净现金流桥 |

### C. 财务模型深化的交付顺序

1. **现实可比性先行**：6–10 个候选、3 个深挖为研究目标，不是硬凑数量；每个案例先画实体/容量/时间/合同/融资/税收关系。并排比较 construction cost、sale EV、financing commitment、project cash flows，禁止互相代替。
2. **财务桥**：保留 pre-tax unlevered baseline，另列 after-tax unlevered、levered equity、tax-equity sponsor distributions。每层有独立现金流定义；项目 IRR 和股权 IRR不可混列。
3. **PPA桥**：物理节点能源 + financial hedge + REC − fees − imbalance，输出付款量与发电量差异、node-hub basis、negative-price触发/恢复条件、contract/merchant tail分段。缺失参数保留unknown；假设敏感性显著标注。
4. **税务桥**：合格基础与总融资需求分离，尤其100MWac不能自动使用≤5MWac的合格接入成本条款；税盾基准、转让折价、时点、折旧基础调整、recapture逐项建模。
5. **债务桥**：CFADS→利息本金→储备/cash sweep→权益分配；核对 DSCR最低/均值、债务尾期、balloon/refinancing，不能只乘杠杆比例放大IRR。
6. **敏感性**：价格/shape/basis、合约tenor、合格抵免基础与延误、all-in CAPEX/FOM、availability/curtailment、interest/DSCR；先单项后合理组合，明确相关性，禁止用未经估计的概率计算“成功率”。
7. **IRR控制**：现金流多次换号时保留所有数值根/单值null；增加NPV曲线、MOIC与回收期辅助，不挑最顺眼的根。若回报参数来自真实项目，逐项解释为何可用于本例。

### D. 建议官方证据入口（线索，需在执行日核实）

- SEC EDGAR 企业年报/8-K/PPA附件、开发商与贷款行原始融资公告：实名项目条款。
- EIA-860/923：https://www.eia.gov/electricity/data/eia860/ 与 https://www.eia.gov/electricity/data/eia923/ 。
- ERCOT NP6-905-CD、NP4-160-SG，官方规则/接入资料、独立市场监测年报；先用项目内已保留文件。
- Texas Comptroller 历史 Chapter313 / 现行适用协议原件及县级公开协议，核验法律主体、项目阶段、税基/期限/真实义务。
- IRS Notice2025-42：https://www.irs.gov/pub/irs-drop/n-25-42.pdf；Notice2026-15：https://www.irs.gov/pub/irs-drop/n-26-15.pdf；检查后续修改，别把本轮文本当永久现行法律。
- ATB2025 UtilityPV：https://atb.nlr.gov/electricity/2025/utility-scale_pv ；BerkeleyLab原始Utility-Scale Solar报告；NLR/DOE原始成本工作簿。
- P01联邦公报及annex：https://www.federalregister.gov/documents/2026/08/11/2026-16400/adjusting-imports-of-polysilicon-and-its-derivatives-into-the-united-states 。规则适用需HTS/origin/entry date/exception/stacking，不把.38/W当通用sitequote。

### E. 本机处理日志与当前访问限制

本轮报告修订只复用冻结小表、现有现金流和算术导出；未重跑回归。联合评审中的参考句并非全部正确，按上面的已核对结果处理。官方网页本轮可通过公开web工具读取；11个命令行urllib下载尝试均DNS失败，详见本版 `support/Source-Acquisition.json`。保留的 `support/*Web-Extracts.json` 是工具返回的网页摘录，不是下载原始PDF，不要声称有完整原文件。原年度/模型资料仍在项目 `Data/raw/`。来源受阻时记录错误、时间、目标和可行下一步，继续其他案例。

交付位置建议：项目 `Deliverables/2026-10-09_Finance-Deepening-Supplement/`（若实际跨日，用真实执行日另命名）；原文件放项目 `Data/raw/<实际日期>_Finance-Deepening/`；处理脚本放项目 `Analysis/<实际日期>_Finance-Deepening/`。

### F. 最终必须给出的文件

- `Findings-and-Replacement-Text-EN.md`：英文可直接插入正文的段落，按FIN编号；每句带可追溯证据，明确哪些仍只能作为scenario。
- 上述可比、回报定义、合同、成本、税务、债务和实绩表；`Sources.csv`、原始文件哈希和字段级来源位置。
- `Finance-Input-Recommendations.csv`：原文、建议值/范围、模型字段、口径调整、是否允许输入、支持范围；真实/参考/假设分列。
- `Research-Disposition.md`：FIN-01至11 done/partial/notdone、精确缺口、下一证据目标；没有证据不得删占位符。
- 可复现入口、环境/命令/退出状态、清理输出目录验证结果；无回归/天气重跑；必要的财务算术独立交叉核对。
- 中文实际工作总结，列来源受阻和作者必须决定事项。不得填工时/补历史日志，不宣称原项目Version1.0。

允许自主调整案例选择、研究先后、低效来源替代和文件组织；每项说明依据。可以优先挖掘资料最完整而非最接近的项目，但必须记录外推限制。无法公开取得的数据就是缺失；不要为了做出一个正IRR而调整成本、税收、merchant tail或融资假设。
