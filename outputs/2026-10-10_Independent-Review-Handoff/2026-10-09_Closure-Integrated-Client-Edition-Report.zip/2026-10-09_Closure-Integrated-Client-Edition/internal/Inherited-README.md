# SOLAR-001 — Finance-integrated client research edition

9 October 2026. I integrated the completed finance supplement into the professional English report. This is a research candidate, not Version 1.0 or a verified asset valuation.

## Current deliverables

- `Integrated-Market-Research-Report-EN_Finance-Integrated.pdf`: current client-readable report.
- `Integrated-Market-Research-Report-EN_Finance-Integrated.md`: editable manuscript.
- `Finance-Integration-Change-Log.md`: integration decisions, corrections and outstanding evidence.
- `Production-Verification.md`: actual rebuild, numerical, visual and package checks.

`Integrated-Market-Research-Report-EN_Panel-Revised.md` is an intermediate inherited manuscript, not the current edition. `internal/Prior-Panel-Report.pdf` preserves the earlier PDF. Earlier records in `internal/`, the panel change log and `finance-supplement/` retain their original dates and verification scope. They do not certify this edition.

## Offline clean reproduction

With Python, numpy, pandas, matplotlib, ReportLab, Pillow and PyMuPDF already installed, run from the extracted package directory:

```sh
python3 scripts/check_package.py
python3 scripts/rebuild_presentation.py --out /tmp/solar001-finance-rebuild
```

The output directory must be empty or nonexistent. The runner copies the frozen compact inputs, regenerates the panel arithmetic and figures, checks the inherited panel, then integrates the new finance tables, two charts and manuscript and renders the current PDF. Every command and exit status is saved in the output's `support/Clean-Rebuild-Receipt.json`. No login, network or installation is needed. Regressions, weather simulations and decomposition estimation are not rerun.

Edit `scripts/integrate_finance.py` for reproducible finance text changes. To render a manually edited source without regenerating its content:

```sh
python3 scripts/build_pdf.py --src Integrated-Market-Research-Report-EN_Finance-Integrated.md --out Finance-Edited.pdf
```

## Evidence and financial scope

`data/finance/` contains new arithmetic and cohort screens; the original six scenario outputs remain unchanged. `finance-supplement/` is a frozen copy of Claude's previous delivery, including its own qualifications; where its narrative and tables differ, the current report and integration change log identify the resolution. `sources/finance/` contains selected official originals. `support/Finance-Figure-Lineage.json` and `Finance-Chart-Snapshots.json` connect the two added charts to their data.

This entry point reproduces the report from frozen research outputs. It does not extract every original workbook or validate missing project inputs. Full EIA workbooks and older raw archives remain in the project's `Data/` folder; see `support/Finance-Source-Scope.json`. Supplement scripts may depend on that external project archive and are outside the portable presentation entry point.

Actual project inputs, settlement rights/finality, full cost, tax eligibility, debt and equity terms remain incomplete. The factual model interface remains blocked with null outputs; numerical scenarios are explicitly separate. The new OCC-only credit and reserve-removal settings are illustrations, not changes to frozen baseline estimates. Current appeal/stay/guidance status is unresolved.

The ZIP is an author handoff, not authorization to publish, sell or redistribute third-party research. I have not paid, logged in, contacted anyone, published, accessed private files or updated hours/work logs. The historical project versions remain preserved.

`SHA256SUMS.txt` hashes package files except itself; `File-Manifest.csv` lists payload paths/sizes/hashes. PDF metadata/bookmark identities can differ between processes; substantive comparisons use source/data hashes, chart files and rendered PDF pages.
