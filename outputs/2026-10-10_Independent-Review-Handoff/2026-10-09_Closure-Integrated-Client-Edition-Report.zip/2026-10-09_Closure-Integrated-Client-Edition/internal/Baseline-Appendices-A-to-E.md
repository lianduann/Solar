# Appendix A. Sources, Data, and Evidence Locations

Bracketed identifiers identify source families, not additional independent studies. Research results [S08, S10, E-A, E-B, E-C] are calculations on the listed official inputs; their computation files have no official publication URL. Dates below are publication dates or statistical periods as recorded in the source catalog. The accompanying Client-Source-Index table preserves the full URL, original file location and catalog identifier; source catalogs contain acquisition details and hashes.

**S01.** MIIT-2024-FUJIAN-REPUBLICATION (2024): [official source](https://gxt.fujian.gov.cn/zwgk/gysj/xysj/xxcy/202504/t20250418_6902400.htm)

**S02.** LONGI-2024-ANNUAL-REPORT (FY2024): [official source](https://static.longi.com/LON_Gi_annual_report_2024_0026f3477f.pdf)

**S03.** IRENA-2026-CAPACITY-STATS (2016-2025): [official source](https://www.irena.org/Publications/2026/Mar/Renewable-capacity-statistics-2026)

**S04.** LBNL-2025-UPDATE-DOE (2030 modeled; publication June2026): [official source](https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update)

**S05.** ERCOT-LOAD (2025): [official source](https://www.ercot.com/gridinfo/load/load_hist); ERCOT-SOLAR (2025): [official source](https://www.ercot.com/gridinfo/generation)

**S06.** NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD)

**S07.** NSRDB V4 5-minute block extract, gid 1142134, 2025 (2025): [official source](https://developer.nrel.gov/docs/solar/nsrdb/)

**S08.** Scenario input register (finance parameters, 2026-10-07; local method, no official publication URL); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**S09.** NLR-2025-ATB (2026 projection): [official source](https://atb.nlr.gov/electricity/2025/data)

**S10.** Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**R-A.** U.S. Utility-Scale Solar, 2025 Data Update (slides PDF) (2025-10): [official source](https://emp.lbl.gov/sites/default/files/2025-10/Utility%20Scale%20Solar%202025%20Edition%20Slides.pdf); Solar Photovoltaic System Cost Benchmarks (web page) (2026-09-02 (page modified)): [official source](https://www.energy.gov/eere/solar/solar-photovoltaic-system-cost-benchmarks); Q1-2024 Solar Cost Benchmarks (dataset page) (2025-12-01 (submitted)): [official source](https://data.nlr.gov/submissions/307); 2025Q1 PV System Cost Benchmark Model (zip: PVSCM 2025.xlsm, UPV/CPV/RPV 2025Q1.txt, description PDF, ReadMe) (2025-11-13 (Program.Date in parameter file)): [official source](https://data.nlr.gov/system/files/304/1767739491-2025Q1%20PV%20System%20Cost%20Benchmark%20Model.zip)

**R-B.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); CIM SP List and EB Mapping (snapshot 2026-09-10) (snapshot 2026-09-10): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP4-160-SG)

**R-C.** Large Load Interconnection Status Update (TAC report), 2026-03-13 (2026-03-12 (posted; deck dated 2026-03-13)): [official source](https://www.ercot.com/files/docs/2026/03/12/March-TAC-Report.pdf); Board Item 14: Batch Zero Update, 2026-09-14/15 (2026-09-11 (posted)): [official source](https://www.ercot.com/files/docs/2026/09/11/14-Batch-Zero-Update.pdf); Board Item 9.1: Batch Study Update, 2026-04 (2026-04-13 (posted)): [official source](https://www.ercot.com/files/docs/2026/04/13/9.1-Batch-Study-Update.pdf)

**R-D.** Electric Power Monthly Table 6.1 (June to July 2026) (2026-09 (release for July 2026 data)): [official source](https://www.eia.gov/electricity/monthly/xls/table_6_01.xlsx); EIA-860M, August 2026 generator file (2026-09 (file for August 2026)): [official source](https://www.eia.gov/electricity/data/eia860m/xls/august_generator2026.xlsx); Form 20-F for FY2025 (2026-04-29): [official source](https://www.sec.gov/Archives/edgar/data/1481513/000110465926050737/jks-20251231x20f.htm); Form 20-F for FY2025 (2026-04-10): [official source](https://www.sec.gov/Archives/edgar/data/1375877/000110465926041976/csiq-20251231x20f.htm); Form 20-F for FY2025 (2026-04-20): [official source](https://www.sec.gov/Archives/edgar/data/1477641/000110465926045134/dq-20251231x20f.htm); Form 10-K for FY2025 (2026-02-24): [official source](https://www.sec.gov/Archives/edgar/data/1274494/000127449426000021/fslr-20251231.htm)

**R-T (formerly R2-A).** Census International Trade API: HS6/HS10 solar imports by country, monthly 2024-01.2026-08 (2024-01 to 2026-08): [official source](https://api.census.gov/data/timeseries/intltrade/imports/hs); Census API query log (no key stored) (2024-01 to 2026-08): [official source](https://api.census.gov/data/timeseries/intltrade/imports/hs)

**R-F (formerly R2-D).** Trina Solar, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-30/1225263857.PDF); JA Solar, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-29/1225249462.PDF); Tongwei, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-30/1225259224.PDF)

**E-S.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); CIM SP List and EB Mapping (snapshot 2026-09-10) (snapshot 2026-09-10): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP4-160-SG)

**E-A.** NSRDB V4 5-minute block extract, gid 1142134, 2023 (2023): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); NSRDB V4 5-minute block extract, gid 1142134, 2024 (2024): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); NSRDB V4 5-minute block extract, gid 1142134, 2025 (2025): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); Scenario input register (finance parameters, 2026-10-07; local method, no official publication URL); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**E-B.** Fuel Mix archive 2007-2024 (IntGenbyFuel2023, IntGenbyFuel2024 used) (2023-2024): [official source](https://www.ercot.com/gridinfo/generation); Fuel Mix IntGenbyFuel2025 (2025): [official source](https://www.ercot.com/files/docs/2025/02/07/IntGenbyFuel2025.xlsx); Native Load 2023 (2023): [official source](https://www.ercot.com/files/docs/2023/02/09/Native_Load_2023.zip); Native Load 2024 (2024): [official source](https://www.ercot.com/files/docs/2024/02/06/Native_Load_2024.zip); Native Load 2025 (2025): [official source](https://www.ercot.com/files/docs/2025/02/11/Native_Load_2025.zip); Henry Hub natural gas spot price, daily (1997-2026): [official source](https://www.eia.gov/dnav/ng/hist_xls/RNGWHHDd.xls); GHCN-Daily TMAX/TMIN, DFW IAH SAT AUS (2023-2025): [official source](https://www.ncei.noaa.gov/access/services/data/v1?dataset=daily-summaries)

**E-C.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**P01.** Adjusting Imports of Polysilicon and Its Derivatives Into the United States (91 FR 51975) (2026-08-11): [official source](https://www.federalregister.gov/documents/2026/08/11/2026-16400/adjusting-imports-of-polysilicon-and-its-derivatives-into-the-united-states)

**P02.** Notice 2025-42 (beginning of construction, wind and solar) (2025-08-15): [official source](https://www.irs.gov/pub/irs-drop/n-25-42.pdf)

**P03.** Notice 2026-15 (prohibited foreign entity / material assistance cost ratio interim guidance) (2026-02-12): [official source](https://www.irs.gov/pub/irs-drop/n-26-15.pdf)

**P04.** U.S. Utility-Scale Solar, 2025 Data Update (slides PDF) (2025-10): [official source](https://emp.lbl.gov/sites/default/files/2025-10/Utility%20Scale%20Solar%202025%20Edition%20Slides.pdf)

**Table A-1. Local analysis files associated with report claims.**

| IDs | Data files |
| --- | --- |
| S01 | data/miit_2024_observations.csv; data/miit_pdf_verification.json |
| S02–S05 | data/longi_product_margins.csv; data/irena_pv.csv; data/lbnl_2030_scenarios.csv; data/hourly_profile.csv |
| S06–S09 | data/scenario_metrics.csv; data/scenario_annual_cash_flows.csv; data/scenario_input_register.csv; data/breakevens.json |
| R-A–R-D | data/supplement/A–D/ (component, load, node and financial tables) |
| R-T; R-F | data/r2/A/; data/r2/D/ |
| E-S–E-C | data/empirical/ (sample, regression, decomposition and tail tables) |
| New client examples | data/Client-Illustrative-Calculations.json; data/2023-Benchmark-Price-Context.csv |


# Appendix B. Methods and Technical Notes

Technical details accompany the cost and market comparisons: current versus historical node classifications, time-zone mapping, shared missing intervals, leap-day approximation, weather fill flags, cost denominator differences, and finance definitions. The full original methods text is preserved in the accompanying technical notes; these qualifications remain part of the interpretation of the results.

## B.1 Layer 2: the ERCOT environment

**System data.** Native load and Solar/FINAL fuel-mix files describe the ERCOT system. The 2025 intraday exhibit uses 363 non-DST dates (8,712 matched hours); the seasonal exhibit retains all 365 dates (8,760 load hours, 35,040 solar intervals). Load (MW) and solar (MWh per hour) are shown on separate axes because their units differ. System solar is not a project output.

**Large-load and self-supply records.** The March 2026 process table (238.6 GW in the 2030 column; 5.8 GW observed energized on a noncoincident basis) and the September 2026 Batch Zero materials (including 11 WLPUN projects whose reported resource power capacities are 12.824 GW gas, 1.654 GW solar, 0.637 GW wind and 0.330 GW battery) are process snapshots with different dates and population definitions. They are not added together and are not demand forecasts. A 125.4 GW chart label and a 127.9 GW narrative figure in the same source deck are retained as an unresolved source inconsistency.

**Settlement point prices (NP6-905-CD).** The product reports 15-minute real-time settlement point prices. Prices are mapped to UTC from the delivery date, hour, interval and DST flag; the local-year grid has 35,040 intervals (35,136 in 2024). Hubs, load zones and DC ties are market benchmarks and never stand in for a node's missing price. Resource-node identity requires published type RN and membership of the 2026-09-10 official list, which is a current snapshot, not a historical record.

**Which node sample is which.**

| Sample | Definition | Used for | Not to be mixed with |
|---|---|---|---|
| 641 nodes (first round) | Type RN, on the official list, complete in **2025 only**; 2025 price substitution with the 2025 output curve | Figure 8-3 (capture-price distribution), Section 8.5 percentile statement | The three-year panel; a percentile from this population is not a result for the 485 nodes |
| 485 nodes (three-year common panel) | Type RN, on the official list, complete on the market-wide grid in **all three** years | Sections 8.5–8.8, 10.8, 11.6–11.9; Figures 8-3 to 8-6 and 11-3 to 11-6 | The first-round 641 sample |
| 757 points (R2 count; **incorrect as a resource-node count**) | Complete in all three years but not filtered on type: 486 RN-type points (485 on the list), 155 PCCRN, 67 LCCRN and 49 PUN points | Not used | Any statement about resource nodes |

The reconciliation is itemized in `data/empirical/tables/R2-757-Itemized-Screening.csv` and `Sample-Flow-By-Year.csv`.

**Common missing intervals.** Every published settlement point lacks the same few intervals: three in 2023 (13 April 15:45 and 16:00, 31 December 23:45), one in 2024 and two in 2025 (`Market-Wide-Missing-Intervals.csv`). On the raw grid no node is complete; after dropping those intervals for all series alike, 485 resource nodes are complete in all three years. Nothing is interpolated or set to zero. The two daytime 2023 gaps carry about 47.6 MWh of simulated site energy.

**Full-year versus common-calendar results.** The reference node's full-year NPV values (+97.76, −91.84 and −85.97 million USD for the 2023, 2024 and 2025 same-year pairings) come from the unmodified finance model on each year's own price grid (retained independent recomputation, `support/inherited/empirical-verification/independent_check.json`). The common-calendar matrix drops 29 February from every cell and uses the intersection of valid intervals across the three price years; its same-year cells for the reference node are +97.76, −92.15 and −85.97 million USD (`data/empirical/A_3x3_cells_by_node.csv`). The differences (0.31 million USD for 2024, 0.009 million USD for 2025) arise from the leap day and the removal of other years' gap intervals. The two are labeled separately in the report and neither replaces the other.

**Leap-day approximation.** PVWatts accepts only 8,760-hour multiples, so 29 February 2024 is simulated through a neighbouring-day slot. The 28 February slot gives 872.1 MWh for the day and the 1 March slot gives 878.2 MWh; the annual difference is 6.6 MWh (about 0.002%). This is a sensitivity between two approximations. It is not a bound on the exact leap-day output, and the common-calendar matrix excludes the day entirely.

## B.2 Layer 3: hypothetical project scenarios

**System.** 100 MWac / 132 MWdc (DC/AC 1.32), single-axis tracking with backtracking, ground-coverage ratio 0.30, inverter efficiency 96%, bifaciality 0.70, aggregate losses 14.0757%, annual degradation 0.7% from operating year 2. Weather comes from the retained NSRDB GOES CONUS v4 5-minute extracts at grid cell 1142134 in Pecos County for 2023, 2024 and 2025, simulated with PVWatts v8 through PySAM 7.1.1. The location is neither a county average nor a verified asset site.

**Finance model.** Pre-tax and unlevered; capital expenditure at the end of 2026 (about $1,436.75/kWac, ATB OCC plus GCC converted from 2023 to 2025 dollars with CPI-U), 30 operating years from 2027, real 2025 dollars, NPV at the 2026 valuation point and a 4.27% real discount rate (6% and 8% also reported). Replacement ($35/kWac, year 16) and net decommissioning ($30/kWac, year 30) are included. Taxes, credits, debt, market fees and site-specific land, insurance and network costs are not.

**Two revenue routes.** The nodal route repeats the first-year price shape in real terms for 30 years and sets exports to zero whenever the price is below zero. The fixed-price route uses a flat nominal $40/MWh and an unpaid-energy reduction of 15.24% of potential energy, anchored to the negative-price energy share; it is neither an observed curtailment rate nor a contract term.

**Linear NPV identity.** With the retained degradation and discounting, NPV = 15.47 × first-year receipts − $187.3 million, and break-even first-year receipts are about $12.1 million. This identity is what links the three-year receipts in Section 10.9 to NPV; it is not a valuation multiple.

**IRR.** A single IRR is reported only where the cash flows have a certified unique real root. In the six 2025-based scenarios the node_upside case has a unique root (−0.42%); node_base, node_downside, fixed_base and fixed_upside have multiple admissible roots, and fixed_downside has no certified single root. Single-IRR fields are null where required. No IRR is computed for the 485-node empirical sample.

**Scenario groups, sensitivities and break-evens.** Downside and upside cases move several inputs together and are not probability bounds. One-way sensitivities (49 identifiers) and two-way grids are analytical ranges. Break-even thresholds (for example about $66/MWh flat nominal at base CAPEX, or CAPEX of about $577/kWac in the nodal route at 4.27%) identify what evidence would change a conclusion; they are not market quotations.


## B.3 Alternative weather/price accounting

The two-factor Shapley decomposition allocates the interaction between weather-profile and price-profile changes equally to those two factors. It produces the following component medians:

**Table B-1. Weather and price contributions: Shapley allocation.**

| Transition | Total NPV change, $m | Weather contribution, $m | Price contribution, $m |
|---|---:|---:|---:|
| 2023 to 2024 | -190.6 | -5.4 | -184.7 |
| 2023 to 2025 | -183.0 | -8.5 | -174.4 |
| 2024 to 2025 | +6.0 | -3.4 | +9.1 |

*Source: multi-year analysis, Shapley component tables. Exact addition holds for each node. Separately calculated component medians need not add to the median total; they are not a decomposition of a single representative median node.*

The price-profile contribution is much larger than the weather-profile contribution for the transition out of 2023. This conclusion is about the model and sample. It leaves unverified why prices changed or how future market conditions will develop.


The original mixed exhibit below retains pure effects plus interaction in its left panel. Its left bars are not the Shapley allocations in Table B-1. It is preserved as a technical diagnostic and must not be compared as if the numbers were identical.

![Figure B-1. Original pure-effect and price-volume diagnostics](figures/empirical/F3_npv_change_decomposition.png)

# Appendix C. Research Limits

The remaining research gaps concern comparable industry output/capacity/inventory, delivered project quotes, product-specific trade applicability, customer procurement commitments, historical node identity and price finality, longer-run weather/price distributions, full project costs, taxes, financing and storage. Each limits box identifies the relevant commercial boundary. Gap identifiers GAP-01 through GAP-16 and the original detailed restrictions are preserved in the supporting research-limit record.



**Research-limit index (legacy identifiers).** GAP-13a denotes sensitivity coverage; GAP-13b denotes the resampling/mixture limitation. The archival original is preserved with its original labels. No evidence gap is closed by editorial renaming.

**GAP-01.** The summary now incorporates the empirical and second-round results. Expected returns, forecast probabilities, a verified project shortlist, and asset-specific validation remain unestablished.

**GAP-02.** Country-level net changes and the U.S. segment snapshot are incorporated below. Comparable segment histories and market forecasts remain open.

**GAP-03.** The incompatible manufacturing/capacity comparison is explained below. A reconciled shipment, trade, and inventory balance remains unavailable.

**GAP-04.** Seven-company coverage now includes Trina, JA Solar and Tongwei FY2025 filings. LONGi FY2025 full-report coverage and comparable segments remain incomplete.

**GAP-05.** Company-specific utilization boundaries and prices are discussed below. A comparable industry capacity and product-price panel remains open.

**GAP-06.** PVSCM components, conditional transmission and Census import context are integrated. Customs value per item is not a delivered price per watt; the AC-denominator inconsistency remains unresolved.

**GAP-07.** Official proclamation and IRS context are incorporated below with effective dates and scope limits. HTS annex mapping, IEEPA interactions, unresolved ITC outcomes, and procurement applicability remain unverified.

**GAP-08.** March and September ERCOT process evidence incorporated below. Source inconsistency, a comparable later status series, customer-level commitments, and hourly procurement requirements remain open.

**GAP-09.** Pipeline and network evidence incorporated below. Interval-level causal attribution, actual interconnection costs, and reliable commissioning probabilities remain open.

**GAP-10.** Three-year nodal comparisons and classification correction are incorporated. Historical identity coverage, longer-run representativeness, price-finality and asset-specific settlement remain incomplete. Hubs and load zones remain benchmarks only.

**GAP-11.** Three same-site weather years are available and used. Long-run weather uncertainty, validated P50/P90 and project-specific performance remain unestablished; no additional weather simulation was run during this editorial integration.

**GAP-12.** Public benchmark coverage, policy context and the finance-to-revenue link are integrated. Complete project cost, commercial mapping, tax eligibility and financing remain unavailable.

**GAP-13a.** Multi-node price substitution integrated below. Weather-year, contract, and cost-coverage robustness remain open; this is not actual asset valuation.

**GAP-13b.** Same-year comparisons, decomposition and tail stresses are integrated. Price forecasts, regime probabilities, causal estimates and actual investment returns remain outside the evidence. Existing regressions and pipelines were not rerun for this edition.

**GAP-14.** Deferred: independent storage design, dispatch, degradation, and incremental cash flows. Solar-only analysis remains usable.

**GAP-15.** The decision matrix is extended by historical tail dependence and conditional price associations. Actual customer orders, procurement terms, reliable price forecasts and opportunity returns remain unverified.

**GAP-16.** The report incorporates three historical market years and explicit stress settings. Long-run regime probabilities, quantified forecasts and validated update thresholds remain unestablished.

# Appendix D. Glossary


| Term | Meaning in this report |
| --- | --- |
| ERCOT | Electric Reliability Council of Texas; grid and wholesale-market operator for most of Texas. |
| MIIT / IRENA | Ministry of Industry and Information Technology (China) / International Renewable Energy Agency. |
| DOE / NLR | U.S. Department of Energy / National Laboratory of the Rockies; older source documents use NREL, National Renewable Energy Laboratory. |
| ATB / PVSCM | Annual Technology Baseline / Photovoltaic System Cost Model; national reference models, not project quotes. |
| OCC / GCC / FOM | Overnight capital cost / grid-connection cost / fixed operations and maintenance. |
| NSRDB / PVWatts / PySAM | National Solar Radiation Database / photovoltaic output model / Python interface to the System Advisor Model. |
| Settlement point / resource node | Pricing location; RN denotes the official resource-node type used to filter this report’s sample. |
| Hub / load zone | Aggregated market-price reference locations; not substitutes for the asset’s settlement node. |
| HB_BUSAVG | System benchmark identifier used in the hourly analysis; its formal name is not disclosed in this edition. |
| NP6-905-CD | ERCOT’s 15-minute real-time settlement-point price report, not day-ahead prices. |
| Basis | Node price minus the specified benchmark price. |
| Time-/generation-weighted price | Average across equal-duration intervals / price averaged with simulated output as weights. |
| Capture ratio | Generation-weighted price divided by time-weighted price; denominator and export rule must be stated. |
| LCOE / NPV / IRR | Levelized cost of energy / net present value / internal rate of return; definitions in Table 2-1. |
| TAC | Technical Advisory Committee (ERCOT). |
| Batch Zero | One-time transitional reliability study for eligible large-load interconnections under PGRR145; September deck, p.5 [R-C]. |
| WLPUN / BYOG | Withdrawal Limited Private Use Network / Bring Your Own Generation; September deck p.8 and April study deck p.1 [R-C]. |
| Noncoincident peak | Individual peak observations may occur at different times; their aggregate is not a simultaneous system load. |
| HS / HTS / IEEPA | Harmonized System / U.S. Harmonized Tariff Schedule / International Emergency Economic Powers Act. |
| ITC / PTC | Investment tax credit / production tax credit; the cash-credit illustration is not an eligibility calculation. |
| P50 / P90 | Output exceeded with 50% / 90% probability over a defined horizon; three weather years do not establish these probabilities. |
| Shapley / LMDI | Allocation of interacting changes by averaging orders / log-mean Divisia index accounting decomposition. |
| HAC / block bootstrap | Heteroskedasticity and autocorrelation consistent uncertainty estimates / resampling consecutive time blocks. |
| RMSE | Root mean squared error; a prediction-error measure. |
| DC/AC / bifaciality / GCR | Module-to-inverter nameplate ratio / rear-to-front conversion efficiency ratio / ground-coverage ratio. |


# Appendix E. Project Governance Notes — internal

This customer-readable research edition is an editorial successor to v0.5; it is not the original project Version 1.0. The original ten acceptance criteria remain unchanged. Criterion 6 retains the project-specific resource, nodal-finality/commercial-mapping, cost, tax and financing gaps. The original 67-field register has 59 blocked, 5 not_yet_verified and 3 reference_assumption fields. Its 13 prohibited outputs remain null. Scenario results are kept separate from those interfaces.

The complete earlier governance and technical passages, gap records and update instructions are preserved without deletion in support/Original-Governance-and-Technical-Notes.md and support/Original-Limits-and-Gaps.md. Prior research verification keeps its original date and scope. This revision does not authorize publishing, sale, external sending, account access or changes to actual hours or work logs.


## E.1 Updates should preserve comparable observations

The next regional-demand update should compare the same process definitions and identify migrations between statuses, rather than add a later headline total to an earlier snapshot. The next nodal update should retain missing-interval handling, separately examine extreme prices, and distinguish a new weather-price year from a repetition of the 2025 output profile. Company updates should preserve fiscal periods, accounting concepts, currencies, and segment boundaries.

The delivered-cost bridge is the most direct next research target for assessing the manufacturing-to-project connection. A public U.S. trade unit value could provide context but would remain an aggregate quantity/value measure, affected by product and origin mix; it would not automatically become a bankable delivered-project quotation. A quotation-based bridge would additionally require specification, origin, logistics, duty, payment, warranty, and delivery-date terms.

No forecast probabilities or commercial conversion rates are supplied without a documented estimation basis. The present evidence supports directional mechanisms and conditional thresholds; it does not support extrapolating queue totals, a single historical price year, or one company's results into a quantified market forecast.

