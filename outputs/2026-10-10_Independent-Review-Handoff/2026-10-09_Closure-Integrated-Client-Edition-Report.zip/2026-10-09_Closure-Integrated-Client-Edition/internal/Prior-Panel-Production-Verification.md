# Production verification — 9 October 2026

I rebuilt the report from frozen outputs and checked the new presentation and arithmetic. This verification does not rerun the research or certify missing raw evidence.

## Executed build and checks

I ran `python3 scripts/rebuild_presentation.py --out /private/tmp/SOLAR001-panel-clean-20261009-final`. All seven stages exited 0. The receipt is `support/Clean-Rebuild-Receipt.json`. After the final chapter-heading layout repair, I rendered the PDF again with exit 0; `support/PDF-Layout-Repair-Receipt.json` records that command. The independent extracted-package rebuild is recorded separately below.

- New displayed numbers, independent annual-cash-flow NPV calculations, original data hashes and manuscript structure: 107 checks, 0 failed.
- Inherited exhibit rendering against the frozen small tables: 51 checks, 0 failed.
- Original compact data: 141 files, 0 hash differences. No existing estimate was overwritten.
- New figure lineage: 5 arithmetic/context exhibits in `support/Panel-Figure-Lineage.json`; 27 exhibits in the inherited rendering pipeline. The client manuscript displays 27 figures in total, including the technical appendix.

## PDF visual review

I rendered and visually reviewed all 60 pages using the contact sheets in `support/pdf-visual-inspection/`. I fixed split research boxes, a separated table source, a broken currency header and a stranded Chapter 11 title. I then reviewed the repaired pages. The last layout edit changed only pages 2, 39, 40 and 41 by pixel comparison; those pages were re-rendered and visually checked. The PDF remains 60 pages, with no text outside the checked margins. I checked tables, figure captions/sources, numbering, contents and page labels. Some pages retain whitespace to keep exhibits, tables and source notes together.

## Editorial search results

Main body means Chapters 1–14, excluding appendices. Counts are case-insensitive literal occurrences, so ordinary words and legal terminology can match.

| Search phrase | Baseline body | Revised body |
|---|---:|---:|
| retained | 0 | 1 |
| empirical candidate | 0 | 0 |
| first-round | 0 | 0 |
| second-round | 0 | 0 |
| R2 | 0 | 0 |
| supplement | 0 | 0 |
| editorial integration | 0 | 0 |
| blocked | 0 | 0 |
| prohibited | 0 | 1 |
| Version 1.0 | 0 | 0 |
| fact-model | 0 | 0 |
| evidence gates | 0 | 0 |

For `does not establish|do not establish|cannot`: main body 1 → 5; entire manuscript 2 → 5. I did not remove necessary qualifications merely to reduce a count. The single `retained` occurrence describes the supplied MIIT source; the `prohibited` occurrence is the legal foreign-entity term, not internal model governance.

## Remaining limitations

I did not revalidate every inherited transcription, rerun any regression or generate actual project returns. The named finance placeholders remain open. I did not check every remote URL for continued availability; local report dependencies and PDF link annotations were checked for packaging. The complete raw research archive and redistribution permissions are outside this handoff verification. All original Version 1.0 gates remain governed by their existing evidence requirements.

## Independent extracted-package reproduction

I tested the local ZIP for CRC errors and unsafe member paths, extracted it to `/private/tmp/SOLAR001-panel-transfer-20261009/`, verified all 307 then-packaged hashes, and ran the README presentation entry point from that extracted copy into `/private/tmp/SOLAR001-panel-transfer-rebuild-20261009/`. All seven stages exited 0. The 107 numeric/structure and 51 exhibit checks passed again without statistical re-estimation. I compared the rebuilt manuscript, derived panel tables and generated PNGs against this edition: 44 files matched by SHA-256, and all 60 PDF page renderings matched. I retained the transfer command, exit status and comparison results in `support/Transfer-Rebuild-Receipt.json` and `support/Transfer-Output-Comparison.json`.

I subsequently added the transfer receipts and this verification note to the handoff and regenerated the final manifest/ZIP. The adjacent `.zip.verification.json` records the final archive's CRC, safe paths and extracted hash checks. This final integrity pass does not repeat research estimation.
