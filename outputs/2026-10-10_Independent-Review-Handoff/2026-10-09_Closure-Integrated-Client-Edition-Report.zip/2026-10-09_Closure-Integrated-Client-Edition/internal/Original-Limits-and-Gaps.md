The commercial case for utility-scale solar is often discussed through three developments: lower equipment prices, rising electricity demand, and the potential for attractive project economics. The available evidence supports examination of each development, but does not establish that they translate into project value through a single, automatic mechanism.

China's 2024 manufacturing data illustrate the first distinction. MIIT reported price declines of 39.5% for polysilicon and 29.7% for modules. LONGi's disclosures for the same year recorded gross margins of 6.27% for modules and cells and -14.31% for wafers and ingots. These observations establish manufacturing price pressure and differing outcomes across business segments. They do not establish U.S. delivered-equipment prices or an equivalent reduction in total project capital expenditure. [S01, S02]

The second-round Census analysis adds evidence on the scale and reported country composition of U.S. imports. It does not supply a specification-matched delivered price per watt: the relevant quantity series is measured in units, and customs values exclude duties and other project-delivery costs. Regional large-load process records likewise do not establish contracted solar demand. [R2-A, R-C]

> **[GAP-01 | Residual evidence limit]** The summary now incorporates the empirical and second-round results. Expected returns, forecast probabilities, a verified project shortlist, and original Version 1.0 acceptance remain unestablished.

An observation in one layer cannot substitute for missing evidence in another. National cost benchmarks do not establish a site's construction budget. System-wide solar output does not establish a project's generation. A resource-node identifier does not establish the commercial settlement point of a hypothetical system.

These distinctions are particularly important when comparing manufacturing statistics with project data. A module price quoted per Wdc cannot be applied directly to a capital-cost benchmark per kWac without accounting for the DC/AC ratio and the included cost categories.

> **[GAP-02 | Residual evidence limit]** Country-level net changes and the U.S. segment snapshot are incorporated below. Comparable segment histories and market forecasts remain open.

> **[GAP-03 | Residual evidence limit]** The incompatible manufacturing/capacity comparison is explained below. A reconciled shipment, trade, and inventory balance remains unavailable.

The available capacity series establishes a large and expanding deployment base. It does not establish whether an individual supplier can win orders in a particular region, at what margin, or with what delivery obligations.

Concentration matters for market development because global scale can overstate the demand directly accessible to an exporter. Country demand must be evaluated alongside trade treatment, local procurement preferences, distribution channels, and the mix of utility-scale and distributed systems. A supplier's accessible revenue pool cannot be calculated by applying a single global market share to total capacity growth.

China's reported 2024 module manufacturing output of 588 GW exceeds the 457.7 GW change in global PV capacity by approximately 130.3 GW. The arithmetic is reproducible, but its economic interpretation is limited. Output, shipments, construction, commissioning, and stock reporting occur at different times; capacity conventions and geography also differ. The residual cannot be labeled inventory, unsold product, or overcapacity. A defensible inventory bridge would require compatible shipment, trade, opening-stock, closing-stock, and loss data. [R-D: D_manufacturing_vs_capacity_2024_non_closure.csv]

MIIT's retained material reports Chinese polysilicon output exceeding 1.82 million metric tonnes in 2024, alongside wafer output of 753 GW, cell output of 654 GW, and module output of 588 GW. These are successive manufacturing stages. Their GW figures cannot be summed into an industry total or subtracted to infer inventory at individual stages. [S01]

For producers, competitiveness during a period of price declines requires assessment of costs, liquidity, product differentiation, and market access. A single gross-margin figure cannot resolve that assessment. Differences in geography and product mix can affect profitability without establishing a corresponding difference in manufacturing efficiency.

> **[GAP-04 | Residual evidence limit]** Seven-company coverage now includes Trina, JA Solar and Tongwei FY2025 filings. LONGi FY2025 full-report coverage and comparable segments remain incomplete.

> **[GAP-05 | Residual evidence limit]** Company-specific utilization boundaries and prices are discussed below. A comparable industry capacity and product-price panel remains open.

The expanded panel uses retained filings for JinkoSolar, Canadian Solar, Daqo, and First Solar, with FY2024 and FY2025 reported separately. The companies participate in different technologies and stages of the value chain. Consolidated gross margins are therefore useful for describing outcomes within each company over time, but cannot establish an unadjusted competitive ranking. [R-D: D_company_xbrl_wide.csv; original filing locations in Supplement-Source-Catalog.csv]

Cash generation adds another dimension. JinkoSolar's operating cash flow falls from approximately CNY16.85 billion to CNY1.08 billion between FY2024 and FY2025. Canadian Solar reports operating outflows in both years, while First Solar reports positive operating cash flow. Daqo's FY2025 operating cash flow is positive despite a negative gross margin. Working-capital movements, business mix, and other cash-flow items can produce such differences; reported cash flow cannot be attributed to equipment prices alone.

LONGi's FY2024 disclosures provide reported utilization and production measures for its own operations. Those company-defined measures can support a within-company discussion when the production boundary and effective-capacity denominator are retained. They cannot establish industry-average utilization. Daqo's annual production divided by a point-in-time nameplate figure is a different indicator: capacity may have changed during the year, so that ratio is not a validated annual utilization measure. [R-D: D_longi_2024_utilization_implied_capacity.csv; D_daqo_production_to_nameplate_indicator.csv]

Changes in efficiency, module power, or system design may also affect racking, land, installation, or electrical requirements. Those effects require a component-level analysis. A single price multiplier cannot represent a simultaneous change in product and project scope.

The retained extract does not separately itemize module procurement within the scenario CAPEX. Consequently, the model's total-CAPEX sensitivity cannot be described as the independent NPV effect of a module-price decline. [S08, S09]

> **[GAP-06 | Residual evidence limit]** PVSCM components, conditional transmission and Census import context are integrated. Customs value per item is not a delivered price per watt; the AC-denominator inconsistency remains unresolved.

> **[GAP-07 | Residual evidence limit]** Official proclamation and IRS context are incorporated below with effective dates and scope limits. HTS annex mapping, IEEPA interactions, unresolved ITC outcomes, and procurement applicability remain unverified.

Applying MIIT's reported 29.7% module-price decline to that U.S. model input would reduce total modeled capital cost by approximately 8.9%. This is a hypothetical comparative-static exercise. It assumes that the U.S. component input changes by the same percentage as MIIT's reported measure, holds specifications and every other model input constant, and does not estimate actual observed U.S. price transmission. The retained evidence does not establish that the assumed module-price change occurred in U.S. deliveries.

The reported country composition changes substantially. Vietnam and Thailand represent large shares in 2024, while Indonesia and Laos become more prominent in 2025; the 2026 January–August mix includes larger shares attributed to the Philippines, Ethiopia, and Kenya. These are the categories reported in the customs data. The series does not establish the physical production route of every item, identify circumvention, or prove why sourcing shifted.

For developers, these distinctions affect obligations and risk allocation. As-generated purchases, fixed delivery blocks, and continuous supply place different quantity responsibilities on the seller or buyer. Demand growth alone therefore cannot determine a common contract price or risk profile.

> **[GAP-08 | Residual evidence limit]** March and September ERCOT process evidence incorporated below. Source inconsistency, a comparable later status series, customer-level commitments, and hourly procurement requirements remain open.

*Source: ERCOT September Batch Zero deck; GW. Battery capacity is a power rating, not primary energy generation. The sample does not establish all data centers' procurement mix.*

Nodal prices provide historical references for specific settlement locations. Hubs and load zones provide broader market context. These locations are not interchangeable, and using a node in a hypothetical case does not establish that system's actual settlement relationship.

The NP6-905-CD product examined here reports 15-minute settlement-point prices. Day-ahead and real-time prices, or prices at different settlement locations, cannot be merged into a common series without identifying the change in basis. Actual receipts may also depend on contracts, dispatch, fees, and quantity obligations. The modeled nodal revenue is gross energy value under the specified reference-price rule. [S06]

A high-resource location need not be the preferred commercial location. Resource quality, construction cost, connection timing, and energy value may favor different sites. The existing single-node example cannot resolve that trade-off or provide a regional ranking.

> **[GAP-09 | Residual evidence limit]** Pipeline and network evidence incorporated below. Interval-level causal attribution, actual interconnection costs, and reliable commissioning probabilities remain open.

The supplement adds EIA generator records and ERCOT pipeline snapshots with fuel, county, expected commissioning year, and process-status fields. These permit separation of operating capacity from planned projects and changes between successive snapshots. A signed interconnection agreement is stronger evidence of process advancement than an announcement, but it does not establish commissioning, final project costs, or delivered electricity. [R-B: B_planned_capacity_by_fuel_codyear.csv; B_planned_capacity_project_changes.csv; R-D: EIA860M tables]

The result demonstrates the importance of temporal alignment. Annual generation multiplied by the average market price would omit the covariance between output and price. The calculation does not establish that every ERCOT solar project realizes the same capture ratio, nor does it identify additional solar generation as the sole cause of the observed relationship.

The relationship varies substantially by year. The reported annual solar coefficients are approximately -$8.4/MWh per GW in 2023, -$3.1 in 2024, and -$1.9 in 2025. Excluding scarcity hours or limiting tail influence reduces the pooled magnitude, while the median regression is smaller again. A common sign does not establish a stable structural relationship.

The negative-price models use hourly mean prices and therefore answer a different question from counting individual negative 15-minute intervals. Results vary with threshold, dependent market reference, and functional form. Several Logit specifications fail or do not converge. The empirical candidate does not establish a robust, specification-independent solar relationship with negative-price incidence. Absence of a robust result is not evidence that solar has no role. [E-B]

> **[GAP-10 | Residual evidence limit]** Three-year nodal comparisons and classification correction are incorporated. Historical identity coverage, longer-run representativeness, price-finality and asset-specific settlement remain incomplete. Hubs and load zones remain benchmarks only.

These results quantify the influence of selected design and loss assumptions. They are not plant-performance guarantees. Terrain, actual layout, seasonal soiling, equipment failures, and construction quality have not been constrained by site-specific evidence. AC capacity factors and DC energy yields use different denominators and cannot be substituted for one another.

> **[GAP-11 | Residual evidence limit]** Three same-site weather years are available and used. Long-run weather uncertainty, validated P50/P90 and project-specific performance remain unestablished; no additional weather simulation was run during this editorial integration.

In both base cases, revenue exceeds modeled FOM in every operating year. That comparison does not establish coverage of all cash operating costs. Cumulative undiscounted real cash flow also remains negative in both base cases. The modeled revenue therefore fails to recover the defined capital outlay and subsequent costs over the operating period.

The result is specific to the tested revenue and cost definitions. Actual procurement, contracts, incentives, and financing may produce different outcomes. A conditional capital-recovery shortfall cannot be generalized into a conclusion that solar development is unattractive across the market.

Base LCOE is approximately $48.85/MWh using delivered energy. Using potential energy before the export reduction lowers the value to approximately $41.41/MWh. The difference reflects the denominator. LCOE is not a contemporaneous market price, and a real levelized cost cannot be compared directly with an unconverted flat nominal quotation.

> **[GAP-12 | Residual evidence limit]** Public benchmark coverage, policy context and the finance-to-revenue link are integrated. Complete project cost, commercial mapping, tax eligibility and financing remain unavailable.

The expanded cost crosswalk distinguishes modeled national overnight cost from observed commissioned-project cost. Berkeley Lab's retained utility-scale publication reports a 2024 commissioned-project cost reference of approximately $1.22/Wdc or $1.61/Wac. Its coverage and sample differ from PVSCM, and the publications use different deflation conventions. A shared real-dollar label does not make the figures fully harmonized. The difference cannot be attributed solely to scope without a component-level reconciliation. [R-A: A_cost_basis_crosswalk.csv; Berkeley Lab retained publication, physical pages 5 and 30]

These comparisons demonstrate that both construction outlays and commercial realization materially affect the tested cases. They do not establish a universal ranking of return drivers. Wider perturbations generally generate larger effects, and some inputs are correlated. Total-CAPEX sensitivity is not an isolated module-price sensitivity.

The existing spatial financial sensitivity primarily scales the base output curve by annual-energy ratios. It does not independently simulate capture prices for every location. Consequently, its financial range cannot be presented as a fully spatially resolved revenue comparison. [S10]

A modeled break-even price does not establish the existence of a buyer willing to pay it. Similarly, a break-even capital budget is not evidence that the system can be built for that amount. The thresholds identify the evidence that would change a commercial assessment.

> **[GAP-13 | Residual evidence limit]** Multi-node price substitution integrated below. Weather-year, contract, and cost-coverage robustness remain open; this is not actual asset valuation.

The price-profile contribution is much larger than the weather-profile contribution for the transition out of 2023. This conclusion is about the retained model and sample. It does not establish why prices changed or how future market conditions will develop.

Between 2024 and 2025, the overall price-level component improves while the matching component worsens. The observations are consistent with solar revenue becoming less aligned with the periods of higher prices. The decomposition itself cannot attribute that shift to solar capacity growth, demand changes, or another mechanism.

The candidate's best-hours stress statistic gives a median of about 23 hours. It measures the narrow revenue buffer in this constructed case, rather than identifying 23 hours that a developer can know in advance or guarantee will recur. The commercial question is whether access to rare high-price periods is durable and contractually retained; the present evidence cannot answer it.

> **[GAP-13 | Residual evidence limit]** Same-year comparisons, decomposition and tail stresses are integrated. Price forecasts, regime probabilities, causal estimates and actual investment returns remain outside the evidence. Existing regressions and pipelines were not rerun for this edition.

Alternative explanations include changes in technology, non-module scope, trade treatment, and delivery terms. A stronger conclusion requires the component mapping in GAP-06 and comparisons using consistent, justified perturbations. National total-cost variation cannot substitute for an isolated component-price effect.

The company panel and customs series broaden the evidence, while the empirical revenue analysis shows that price shape can materially alter value capture. None of these additions establishes observed pass-through from factory prices to complete project costs. Comparable production, inventory, prices and delivered costs under GAP-03 through GAP-06 could change the assessment. Individual-company disclosures cannot be presented as industry-average profitability.

> **[GAP-14 | Residual evidence limit]** Deferred: independent storage design, dispatch, degradation, and incremental cash flows. Solar-only analysis remains usable.

> **[GAP-15 | Residual evidence limit]** The decision matrix is extended by historical tail dependence and conditional price associations. Actual customer orders, procurement terms, reliable price forecasts and opportunity returns remain unverified.

> **[GAP-16 | Residual evidence limit]** The report incorporates three historical market years and explicit stress settings. Long-run regime probabilities, quantified forecasts and validated update thresholds remain unestablished.

Three distinctions govern use of the empirical results. First, a historically positive modeled outcome does not establish an expected return. Second, broad negative outcomes under two historical price years do not prove that every solar project is uneconomic. Third, persistent node price differences do not identify their cause. Each stronger claim would require additional evidence beyond the present scenario and association framework.

The most useful investment question is whether a proposed commercial structure can support the required receipts at a complete and substantiated cost. The present study supplies conditional thresholds and identifies exposure to a concentrated price pattern. It does not establish future prices, actual contracting rights, tax eligibility, financing terms, or the probability of collecting the modeled receipts.

The original ten acceptance conditions remain unchanged. A documented candidate can be usable without being original Version 1.0. In particular, empirical associations and national references cannot close Criterion 6's project-specific evidence chain. The original fact-model interfaces remain blocked with prohibited outputs null; scenario figures are never written into those interfaces.

The [supporting methods appendix](Methods-Data-and-Model-Status-Appendix.md), [file inventory](File-Manifest.csv) and [dated acceptance mapping](Acceptance-Matrix-2026-10-08.md) explain how to use the compact deliverable with the original workspace. Full raw data remain in the project archive. Source retention and prior successful reconstruction do not establish project-specific commercial facts or permission to redistribute every original source.
