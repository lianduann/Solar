# SOLAR-001 — Panel-revised client research edition

9 October 2026. I revised the English report using both panel reviews. The report is a 60-page research edition with 27 displayed figures and 19 numbered tables. It supports market/procurement screening and transparent scenario discussion; it is not a verified asset appraisal or Version 1.0.

## Read these files

- `Integrated-Market-Research-Report-EN_Panel-Revised.pdf`: client-facing report.
- `Integrated-Market-Research-Report-EN_Panel-Revised.md`: editable English source.
- `Finance-Deepening-Research-Brief-for-Claude.md`: executable follow-on research task, with FIN-01–FIN-11 fields, source leads, constraints and deliverables.
- `Panel-Review-Disposition-and-Change-Log.md`: completed, partial and unexecuted recommendations; unresolved author/evidence inputs.
- `Production-Verification.md`: actual commands, visual review and validation scope.

`data/` contains the frozen compact research outputs; `data/panel/` contains arithmetic-only derived comparisons. `figures/` contains rendered images and vector masters. `scripts/` contains the offline presentation pipeline. `support/` contains the baseline, review documents, figure lineage, numeric checks, official web extracts and visual-review evidence. `internal/` preserves historical governance and technical notes, including the prior Appendix E. These working/support files are for author handoff, not the customer narrative.

## Rebuild from an empty output directory

From this directory, in an environment with Python 3.12, numpy, pandas, matplotlib, reportlab, Pillow and PyMuPDF:

```sh
python3 scripts/rebuild_presentation.py --out /tmp/solar001-panel-rebuild
```

The output must be empty or nonexistent. The runner derives arithmetic comparisons, assembles the manuscript, renders exhibits, performs 51 figure-fidelity checks and 107 numeric/structure checks, and renders the PDF. It writes commands, output and exit statuses to `support/Clean-Rebuild-Receipt.json` inside the output. It does not install dependencies or require network access.

For editorial changes, update `scripts/revise_manuscript.py` to retain them in the complete rebuild. The complete runner regenerates the Markdown from the frozen baseline. To render a manually edited Markdown file directly, without regenerating its text:

```sh
python3 scripts/build_pdf.py --src Integrated-Market-Research-Report-EN_Panel-Revised.md --out Integrated-Market-Research-Report-EN_Edited.pdf
```

To verify a delivered package before running it:

```sh
python3 scripts/check_package.py
```

This is presentation and financial-arithmetic reproduction from frozen outputs. I did not rerun regressions, generation simulations, resampling or the underlying decomposition estimation. The complete raw research archive remains in the project and is not included here; successful rendering does not verify missing original sources or project inputs. PDF binary metadata/bookmark identities can vary across processes; compare manuscript, data, figure pixels and PDF page renderings for substantive equality.

## Integrity and scope

`SHA256SUMS.txt` hashes package files other than itself. `File-Manifest.csv` lists payload paths, sizes and SHA-256; its own entry is excluded to avoid recursion. The adjacent ZIP and `.sha256` transfer the author handoff. The separately dated historical report remains untouched.

Official tool extracts in `support/*Web-Extracts.json` are extracts, not newly downloaded original PDFs. Eleven command-line download attempts failed DNS resolution; see `Source-Acquisition.json`. New policy text is limited to checked provisions; HTS applicability and stacking remain unresolved. I have not verified redistribution rights for a paid product, published, contacted anyone, logged in, accessed private documents or updated work hours.
