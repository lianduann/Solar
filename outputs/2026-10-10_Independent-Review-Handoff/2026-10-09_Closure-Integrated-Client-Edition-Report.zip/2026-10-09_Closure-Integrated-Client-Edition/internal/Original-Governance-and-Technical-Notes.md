## 2.4 Separation of the fact-based model and the scenario model

The original fact-based project model retains its evidence gates: 59 fields are blocked, five are not yet verified, and three are reference assumptions. Its 13 prohibited numerical outputs remain null. The separate scenario model evaluates conditional results using identified assumptions. Publication of those results does not release outputs from the fact-based model or complete the original ten acceptance criteria. [S10]

This separation permits economic analysis while preserving the difference between a research case and a verified asset. The scenario's usefulness lies in the transparency of the relationship between assumptions and outcomes.



## 14.5 Updates should preserve comparable observations

The next regional-demand update should compare the same process definitions and identify migrations between statuses, rather than add a later headline total to an earlier snapshot. The next nodal update should retain missing-interval handling, separately examine extreme prices, and distinguish a new weather-price year from a repetition of the 2025 output profile. Company updates should preserve fiscal periods, accounting concepts, currencies, and segment boundaries.

The delivered-cost bridge is the most direct next research target for assessing the manufacturing-to-project connection. A public U.S. trade unit value could provide context but would remain an aggregate quantity/value measure, affected by product and origin mix; it would not automatically become a bankable delivered-project quotation. A quotation-based bridge would additionally require specification, origin, logistics, duty, payment, warranty, and delivery-date terms.

No forecast probabilities or commercial conversion rates are supplied without a documented estimation basis. The present evidence supports directional mechanisms and conditional thresholds; it does not support extrapolating queue totals, a single historical price year, or one company's results into a quantified market forecast.



# Appendix B. Methods and Evidence Status

This edition integrates retained research without new estimation or a new independent audit. The original six 2025 financial scenarios retain the corrected IRR treatment. The empirical candidate adds three-year simulated-output/price comparisons, accounting decompositions, conditional regressions, node-basis descriptions and stress settings. The source packages retain their original code, input records and verification receipts; those receipts apply to their stated scopes and are not recast as tests executed for this edition.

The report distinguishes five evidence types: observed source quantities; identities on a stated grid; scenarios conditional on assumptions; statistical associations conditional on controls; and prediction checks. No causal estimate is claimed. A new combined sample does not inherit the size or percentile of an older sample, and a common-calendar statistic does not replace a full-year value without disclosure.

The delivery README and supporting methods appendix describe the retained reproduction routes and compact-package dependencies. No regression, finance simulation or full raw-processing pipeline is rerun merely to assemble this publication candidate. PDF rendering and package construction are document-production steps, not new research validation.

# Appendix C. Residual Scope and Original Acceptance

All sixteen research-gap identifiers remain traceable, but many now describe narrower residual questions rather than an unfilled chapter. Three-year weather and nodal analysis address part of GAP-10/11/13. The expanded filings and customs data address part of GAP-04/06. Storage remains deferred. Longer-run weather and price distributions, delivered project prices, unresolved trade applicability and actual commercial inputs remain incomplete.

The original ten acceptance conditions remain unchanged. A documented candidate can be usable without being original Version 1.0. In particular, empirical associations and national references cannot close Criterion 6's project-specific evidence chain. The original fact-model interfaces remain blocked with prohibited outputs null; scenario figures are never written into those interfaces.

Any separately named research-release Version 1.0 would require an explicit scope decision and acceptance criteria of its own. No such change is adopted in this manuscript. This edition is an integrated research release candidate prepared for review, with the remaining acceptance conditions disclosed rather than waived.


# Appendix D. Supplemental Sources and Technical Companion

R-A, R-B, R-C and R-D refer to the October 8 first-round cost/trade, ERCOT, demand, and manufacturing/global modules. Their source catalog is [retained here](support/inherited/R1-Source-Catalog.csv). R2-A and R2-D refer to Census and A-share extensions in the [R2 catalog](support/inherited/Source-Catalog-R2.csv). Customs data should be interpreted with the classification and quantity units recorded in that package.

E-S, E-A, E-B and E-C denote the empirical candidate's sample/data, accounting, conditional-association and tail/robustness modules. Their reading entry points are the [English technical report](support/inherited/Empirical-Technical-Report.md) and [methods and identification limits](support/inherited/Methods-and-Identification-Limits.md). The [empirical source catalog](data/empirical/tables/Source-Catalog-Empirical.csv) and figure lineage preserve the upstream mapping.

The empirical figures are reproduced as retained research exhibits. Editorial interpretations in this report qualify several statements: positive scenario cases are not exclusive to 2023; Shapley and LMDI are distinct decompositions; component medians are not additive; the leap-slot sensitivity is not a bound on exact output; basis persistence is not causal attribution; and negative-price associations are not treated as robust across thresholds and functional forms. These wording choices do not change the underlying estimates.

The [supporting methods appendix](Methods-Data-and-Model-Status-Appendix.md), [file inventory](File-Manifest.csv) and [dated acceptance mapping](Acceptance-Matrix-2026-10-08.md) explain how to use the compact deliverable with the original workspace. Full raw data remain in the project archive. Source retention and prior successful reconstruction do not establish project-specific commercial facts or permission to redistribute every original source.


# Methods, Data and Model Status Appendix

## Technical companion to the Integrated Research Release Candidate v0.5

**Lucid Direction Insights LLC | SOLAR-001 | Integrated Research Release Candidate v0.5 | October 8, 2026**

*Interpretation guide for the manufacturing and global supply layer, the ERCOT environment and the hypothetical project scenarios*

# 1. Purpose, status and package boundary

This appendix explains how the three evidence layers of the integrated report are defined, which statements are factual gates, scenario outputs, accounting identities or statistical associations, and which figures and tables apply to which sample. It introduces no new estimate, no new source review and no new simulation. Every number quoted here appears in the main report or in a retained table of this package; the retained table is named at the point of use.

The package is **presentation-reproducible only**. It contains the manuscript, the unified exhibits, the compact tables that those exhibits and the report's tables read, source catalogs with hashes, and the retained verification receipts of earlier work. The full research dependency tree (raw ERCOT, NSRDB, IRENA, SEC, EIA, Census and filing archives; the first-round, scenario and empirical build code) remains in the project workspace outside this package. Section 9 lists the external entry points. Those entry points were not run during assembly of this package.

The report is a release candidate. It is not the original Version 1.0, not a verified asset valuation and not investment advice. The original ten acceptance conditions are unchanged (see `Acceptance-Matrix-2026-10-08.md`).

# 2. Evidence classes used throughout

| Class | What it is | Where it appears | Not to be read as |
|---|---|---|---|
| Observed source quantity | A number printed by a source (MIIT price change, IRENA capacity, filing line item, ERCOT price) | Chapters 3–7 | A delivered project cost or a forecast |
| Accounting identity | An equality on a stated grid (capture price = mean price + covariance term; NPV = a × first-year receipts − K) | Chapters 8, 10, 11 | A causal statement |
| Model scenario | A result conditional on declared assumptions (hypothetical 100 MWac plant, 30-year repetition of first-year price conditions) | Chapters 8–11 | An actual-asset result or a price forecast |
| Conditional association | A regression coefficient or descriptive pattern conditional on listed controls | Sections 8.6–8.8 | A causal effect |
| Prediction check | Held-out comparison of a fitted association | Section 8.7 | Evidence that the model can supply a forecast |
| Factual model gate | A blocked or not-yet-verified field in the original fact-based model interface | Section 2.4 and Appendix C | Anything that a scenario result can release |

# 3. Layer 1: manufacturing and global supply

**Sources and definitions.** The retained MIIT PDF supplies 2024 output by manufacturing stage and annual price changes (−39.5% polysilicon, −29.7% modules); the MIIT PDF is accepted as supplied and no further search for the MIIT-origin page is made. The output figures are stage-specific manufacturing output in different units and may not be summed or subtracted. LONGi's 2024 report (page 30) gives product-level gross margins (6.27% modules and cells; −14.31% wafers and ingots) for one company only. IRENA's capacity statistics are maximum net generating capacity stocks; China's entries carry the source flag u and are included in the world total. Differences between adjacent years are net stock changes, not shipments or gross installations.

**Company panel.** The four-company panel (JinkoSolar, Canadian Solar, Daqo, First Solar; FY2024 and FY2025) uses consolidated reported gross margin from retained SEC filings. The FY2025 A-share additions (Trina, JA Solar, Tongwei) use retained annual reports under their own currencies and consolidation boundaries. LONGi's full FY2025 annual report is not in the retained set. Neither panel is a ranking of operating efficiency.

**Cost transmission.** The PV-only component model is a reimplementation of the DOE/NLR PVSCM 2025Q1 inputs in 2024 dollars per Wdc. Modules are 26.1% of the modeled market-price total, and the retained additive structure gives a marginal factor of 1.144 per unit of module input. The 8.9% total-cost change associated with a 29.7% module-price decline is a comparative static with all other inputs fixed. The supplemental table's AC conversion metadata is internally inconsistent (stated ratio 1.34 against a 100 MWdc / 76 MWac description, implying about 1.316), so AC-converted values are excluded. Census customs values (HS 854143: about $14.4 billion in 2024 and $6.4 billion in 2025) are import values; the HS10 quantity unit is items, not watts, and customs value excludes duties and project delivery costs. A delivered price per watt is not derived.

**Non-closure.** China's reported 2024 module output (588 GW) exceeds the 457.7 GW change in global capacity by about 130.3 GW. The difference mixes output, shipments, commissioning and stock reporting and is not labeled inventory or overcapacity.

# 4. Layer 2: the ERCOT environment

**System data.** Native load and Solar/FINAL fuel-mix files describe the ERCOT system. The 2025 intraday exhibit uses 363 non-DST dates (8,712 matched hours); the seasonal exhibit retains all 365 dates (8,760 load hours, 35,040 solar intervals). Load (MW) and solar (MWh per hour) are shown on separate axes because their units differ. System solar is not a project output.

**Large-load and self-supply records.** The March 2026 process table (238.6 GW in the 2030 column; 5.8 GW observed energized on a noncoincident basis) and the September 2026 Batch Zero materials (including 11 WLPUN projects whose reported resource power capacities are 12.824 GW gas, 1.654 GW solar, 0.637 GW wind and 0.330 GW battery) are process snapshots with different dates and population definitions. They are not added together and are not demand forecasts. A 125.4 GW chart label and a 127.9 GW narrative figure in the same source deck are retained as an unresolved source inconsistency.

**Settlement point prices (NP6-905-CD).** The product reports 15-minute real-time settlement point prices. Prices are mapped to UTC from the delivery date, hour, interval and DST flag; the local-year grid has 35,040 intervals (35,136 in 2024). Hubs, load zones and DC ties are market benchmarks and never stand in for a node's missing price. Resource-node identity requires published type RN and membership of the 2026-09-10 official list, which is a current snapshot, not a historical record.

**Which node sample is which.**

| Sample | Definition | Used for | Not to be mixed with |
|---|---|---|---|
| 641 nodes (first round) | Type RN, on the official list, complete in **2025 only**; 2025 price substitution with the 2025 output curve | Figure 8-4 (capture-price distribution), Section 8.5 percentile statement | The three-year panel; a percentile from this population is not a result for the 485 nodes |
| 485 nodes (three-year common panel) | Type RN, on the official list, complete on the market-wide grid in **all three** years | Sections 8.5–8.8, 10.8, 11.6–11.9; Figures 8-4 and 8-6 to 8-8 and 11-3 to 11-6 | The first-round 641 sample |
| 757 points (R2 count; **incorrect as a resource-node count**) | Complete in all three years but not filtered on type: 486 RN-type points (485 on the list), 155 PCCRN, 67 LCCRN and 49 PUN points | Not used | Any statement about resource nodes |

The reconciliation is itemized in `data/empirical/tables/R2-757-Itemized-Screening.csv` and `Sample-Flow-By-Year.csv`.

**Common missing intervals.** Every published settlement point lacks the same few intervals: three in 2023 (13 April 15:45 and 16:00, 31 December 23:45), one in 2024 and two in 2025 (`Market-Wide-Missing-Intervals.csv`). On the raw grid no node is complete; after dropping those intervals for all series alike, 485 resource nodes are complete in all three years. Nothing is interpolated or set to zero. The two daytime 2023 gaps carry about 47.6 MWh of simulated site energy.

**Full-year versus common-calendar results.** The reference node's full-year NPV values (+97.76, −91.84 and −85.97 million USD for the 2023, 2024 and 2025 same-year pairings) come from the unmodified finance model on each year's own price grid (retained independent recomputation, `support/inherited/empirical-verification/independent_check.json`). The common-calendar matrix drops 29 February from every cell and uses the intersection of valid intervals across the three price years; its same-year cells for the reference node are +97.76, −92.15 and −85.97 million USD (`data/empirical/A_3x3_cells_by_node.csv`). The differences (0.31 million USD for 2024, 0.009 million USD for 2025) arise from the leap day and the removal of other years' gap intervals. The two are labeled separately in the report and neither replaces the other.

**Leap-day approximation.** PVWatts accepts only 8,760-hour multiples, so 29 February 2024 is simulated through a neighbouring-day slot. The 28 February slot gives 872.1 MWh for the day and the 1 March slot gives 878.2 MWh; the annual difference is 6.6 MWh (about 0.002%). This is a sensitivity between two approximations. It is not a bound on the exact leap-day output, and the common-calendar matrix excludes the day entirely.

# 5. Layer 3: hypothetical project scenarios

**System.** 100 MWac / 132 MWdc (DC/AC 1.32), single-axis tracking with backtracking, ground-coverage ratio 0.30, inverter efficiency 96%, bifaciality 0.70, aggregate losses 14.0757%, annual degradation 0.7% from operating year 2. Weather comes from the retained NSRDB GOES CONUS v4 5-minute extracts at grid cell 1142134 in Pecos County for 2023, 2024 and 2025, simulated with PVWatts v8 through PySAM 7.1.1. The location is neither a county average nor a verified asset site.

**Finance model.** Pre-tax and unlevered; capital expenditure at the end of 2026 (about $1,436.75/kWac, ATB OCC plus GCC converted from 2023 to 2025 dollars with CPI-U), 30 operating years from 2027, real 2025 dollars, NPV at the 2026 valuation point and a 4.27% real discount rate (6% and 8% also reported). Replacement ($35/kWac, year 16) and net decommissioning ($30/kWac, year 30) are included. Taxes, credits, debt, market fees and site-specific land, insurance and network costs are not.

**Two revenue routes.** The nodal route repeats the first-year price shape in real terms for 30 years and sets exports to zero whenever the price is below zero. The fixed-price route uses a flat nominal $40/MWh and an unpaid-energy reduction of 15.24% of potential energy, anchored to the negative-price energy share; it is neither an observed curtailment rate nor a contract term.

**Linear NPV identity.** With the retained degradation and discounting, NPV = 15.47 × first-year receipts − $187.3 million, and break-even first-year receipts are about $12.1 million. This identity is what links the three-year receipts in Section 10.8 to NPV; it is not a valuation multiple.

**IRR.** A single IRR is reported only where the cash flows have a certified unique real root. In the six 2025-based scenarios the node_upside case has a unique root (−0.42%); node_base, node_downside, fixed_base and fixed_upside have multiple admissible roots, and fixed_downside has no certified single root. Single-IRR fields are null where required. No IRR is computed for the 485-node empirical sample.

**Scenario groups, sensitivities and break-evens.** Downside and upside cases move several inputs together and are not probability bounds. One-way sensitivities (49 identifiers) and two-way grids are analytical ranges. Break-even thresholds (for example about $66/MWh flat nominal at base CAPEX, or CAPEX of about $577/kWac in the nodal route at 4.27%) identify what evidence would change a conclusion; they are not market quotations.

# 6. Factual model gates and scenario outputs

The original fact-based project model retains its evidence gates: 59 fields are blocked, five are not yet verified, three are national ATB reference assumptions, and its 13 prohibited numerical outputs remain null. Both original interfaces (unlevered and levered cash flow) are blocked; the levered interface additionally depends on debt, fees, reserves and a dated schedule that no retained evidence supplies. The scenario model is a separate, labeled construction.

| Item | Fact-based model | Scenario model |
|---|---|---|
| Status of numerical outputs | 13 prohibited outputs null | Labeled scenario results with a scenario identifier |
| Inputs | Source/date/unit/currency/assumption status required; 59 blocked, five not yet verified, three reference assumptions | Declared assumptions and ATB national references |
| Debt and tax | Levered interface blocked | Excluded (pre-tax, unlevered) |
| Released by scenario results? | Never | Not applicable |

Scenario figures are never written into the fact-based interface. Publication of scenario results does not close Criterion 6 of the original acceptance conditions.

# 7. Empirical interpretation boundaries

**Accounting decompositions are separate.** The two-factor Shapley decomposition splits the interaction between weather-year and price-year changes equally between the two factors. The log-mean Divisia (LMDI) decomposition expresses potential receipts through volume, overall price level and the output-price matching ratio, with the export-rule adjustment reported separately. They answer different questions. The LMDI components are not subcomponents of the Shapley price contribution. Sums are exact for each node; **component medians across nodes do not add** to the median total.

**Conditional regressions and held-out prediction.** The hourly regressions (26,298 hours in the pooled specifications) relate the HB_BUSAVG price to system solar, wind, load, Henry Hub gas, four-city daily temperature and calendar effects. The pooled linear solar coefficients are about −$2.7 to −$3.8/MWh per additional GW; the annual coefficients are about −$8.4, −$3.1 and −$1.9 per GW for 2023, 2024 and 2025; and the median regression gives −$1.2. These are conditional associations. Unit outages, available capacity, imports, interval congestion and Texas gas prices are not in the model. The held-out 2025 comparison (fit on 2023–2024) has an RMSE of about $66/MWh, against about $45 for an hour-of-week mean and $39 for a constant. The fitted relationship therefore supplies no forecast. **No causal claim is made.**

**Negative prices.** The negative-price models use hourly mean prices; results differ with threshold, dependent price and functional form, and three of the four logit specifications fail or do not converge. The study does not establish a robust, specification-independent solar relationship with negative-price incidence, and the absence of one is not evidence of no relationship.

**Node basis.** Basis persistence across years (rank correlation 0.77–0.88; node identity explains about 83% of node-year mean-basis variation) is descriptive. It does not identify congestion or any other cause.

**No probability from three years.** Three weather years and three price years do not support a P50, a P90, a price forecast, a regime probability or a probability that a project is profitable. Within-year block resampling conditions on the historical year; the equal-weight three-year mixture is an analytical setting. Neither is a long-run distribution.

# 8. Unified exhibits: how they were redrawn

All 27 exhibits of the report (19 inherited charts and 8 empirical exhibits) were redrawn from packaged tables under one visual theme, with their original file names and relative paths preserved. The rendering code (`scripts/chart_theme.py`, `scripts/render_all_figures.py`) reads only frozen tables in `data/`; it estimates nothing. Each exhibit's rendering lineage (original exhibit, input table and columns, display-only operations, units and population, hashes) is in `support/Figure-Rendering-Lineage.csv`, and the original charts are preserved in `support/original-figures/`. Two empirical exhibits (the left panel of Figure 11-5 and Figure 8-6) draw on interval-level quantities that the retained empirical tables do not carry; their plot inputs were extracted from the empirical candidate's frozen clean-rebuild intermediates by sorting, cumulative summation and a four-interval hourly mean, with no model fitted (`data/empirical/plot_inputs/`, `scripts/extract_empirical_plot_inputs.py`). The theme and palette are described in `support/Visual-Style-Guide.md`.

# 9. Reproduction routes and dependencies (not executed in this package)

| Layer | Entry point in the project workspace | Needs |
|---|---|---|
| First-round supplement (R-A to R-D) | `Analysis/2026-10-08_Deep-Report-Supplement/run_all.py` | Retained raw archives under `Data/raw/`; Python 3.12 with pandas, numpy, openpyxl, pdfplumber, h5py |
| Scenario and sensitivity model (2026-10-07) | `Deliverables/2026-10-07_Scenario-and-Sensitivity-Candidate/README.md` and `Analysis/2026-10-07_Scenario-and-Sensitivity/` | NSRDB 2025 extract, 2025 NP6-905-CD archives, NREL-PySAM 7.1.1 |
| R2 (Census, A-share, Hub/LZ multi-year) | `Deliverables/2026-10-08_Deep-Report-Research-Supplement-R2/README.md` | Retained filings and Census files |
| Empirical candidate | `Analysis/2026-10-08_Empirical-Mechanisms/run_all.py` | NP6-905-CD 2023–2025 archives, NSRDB 2023–2025, ERCOT load and fuel mix, EIA and NOAA files, statsmodels 0.14.6 |

Their verification receipts are retained under `support/inherited/` with their original dates and scopes: the first-round clean rebuilds and claim checks, the integrated draft's rebuild checks and PDF review, and the empirical candidate's clean rebuild comparison and independent node-year recomputation. These receipts are inherited. They certify the stated scopes of the earlier packages and are not tests executed for this release candidate. The new production checks of this package (rendering fidelity, PDF layout, links, copied-file integrity, ZIP integrity and independent extraction) are recorded in `Production-Verification.md`.

# 10. Limits on source reuse

Retained official sources establish what was retrieved at the acquisition dates stated in the source catalogs. Whether third-party material may be redistributed with a paid product has not been reviewed. Policy and rule content (Proclamation 11052, IRS notices) reflects the retained publications and requires verification at the final publication cutoff. No project-specific design, loss, interconnection, curtailment, EPC, contract, tax or financing data were used, and none of the results is an actual-asset result.

## Editorial production note for v0.5

The chart-redrawing and 51 fidelity checks described above were performed for v0.4 and are inherited here; they were not repeated. This revision retains those exhibits, clarifies the decomposition caption, and maps the original empirical exhibit identifiers to this report’s sequential figure numbers. See Editorial-Disposition-v0.5.md for the scope of the new editorial work.
