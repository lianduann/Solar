# Panel review disposition and change log

Date: 9 October 2026. I combined both supplied panel reviews, used the client review for readability, and checked proposed changes against existing outputs and selected official texts. I preserved the prior edition and all original estimates. “Done” below means the stated editorial or arithmetic task is complete; it is not acceptance of the original Version 1.0 criteria.

## Twelve priority recommendations

| ID | Status | What I changed / direct evidence | What remains |
|---|---|---|---|
| 1 — Scarcity and market regime | done | I revised 11.8 with the existing 99.9th-percentile cap, scarcity-date test, 34 flagged dates, and the official 6 September 2023 EEA2 and 5 December 2025 RTC+B dates. I corrected the review's assertion that all three calendar years precede the reform. | No causal battery effect or recurrence probability is inferred; FIN-08. |
| 2 — Credit timing and eligibility | partial | I added the construction/service-date branches in Table 10-3, corrected nominal-receipt PV to $40.33m and separated supply-chain, ownership and basis requirements. | No actual construction date, eligible basis, monetization terms or eligibility conclusion; FIN-04. |
| 3 — Component transmission | done | I replaced the China-price extrapolation with direct U.S. module-input sensitivities. I applied the percentage to PV overnight cost only and left connection cost fixed; Table 5-1 and Module-Cost-Sensitivities.csv. | No observed procurement pass-through; FIN-05. |
| 4 — NPV dollar comparison | done | I added Table 11-3 with explicit starting points and scopes, including shape-preserving output sensitivity. I labeled the price/weather comparison as a joint change and did not rank probabilities. | Interactions need separate later scenarios. |
| 5 — Fixed contract and unpaid energy | partial | I described the simplified node-paid-volume route, the severe 15.24% assumption and its doubled stress, added the $55.91/MWh no-unpaid threshold, and explained both legs of a hub financial hedge; 10.3 and Appendix B. | Actual contract, tenor, tail, negative-price provisions, fees and counterparty terms; FIN-03/11. |
| 6 — Reference node | partial | I added Table 8-1 with the same output profile at the reference, West and Bus Average hubs. I corrected HB_BUSAVG's definition and disclosed the missing selection rationale and settlement mapping once. | Choice rationale and an actual plant-to-node chain; FIN-06. |
| 7 — Node population | done | I distinguished 485 rule-screened common-calendar nodes from 641 single-year nodes. I added the 156-point coverage-cohort comparison and load-zone distribution of 2024 positive cases. I did not call excluded nodes new plants. | Historical classification/COD is not established; positive shares are not probabilities. |
| 8 — China supply context | partial | I dated the 2024 bulletin, separated price layers, added dated China policy context and a four-link sourcing diagram. | Current comparable utilization, inventory, overseas operating capacity and ownership panel are still missing; Appendix C. |
| 9 — Company finances and H3 | partial | I verified three consolidated cash-flow headers, retained the correct JA FY2025 loss column, added three net-margin ratios and Tongwei's PV-segment revenue. I strengthened H3 only as an existence claim for the observed businesses. | Harmonized company scope, US-listed net-income fields, liquidity, impairment and incentive reconciliations; FIN-09. |
| 10 — Quantitative presentation | done | I moved the coefficient forest and inference detail to Appendix B, excluded the nonlinear coefficient from the pooled linear range, explained reverse causality and weak prediction, and replaced non-additive component medians with means in Table 11-2 and Figure 11-4. | No causal identification or new regression. |
| 11 — Actual generation benchmark | partial | I inserted FIN-02 and the explicit uncalibrated 33.4% qualification, plus an arithmetic 10% output sensitivity. | Same-year, capacity-matched actual plant performance is not collected; no P50/P90. |
| 12 — Client editing | done | I retained governance in internal files, revised bibliography/company names, corrected residual text and sequential labels, removed duplicate embedded source notes, kept table notes and research boxes together and repaired a stranded chapter heading. | The ancillary requests below remain explicitly qualified. |

## Ancillary recommendations and deliberate limits

| Review references / issue | Status | Disposition |
|---|---|---|
| A-9 / WLPUN / SB6 / duplicate requests | partial | I retained separately defined request and operating quantities. I did not assert unmeasured duplicate applications or a current SB6 implementation status. Appendix C retains later comparable load and rule evidence as open. |
| A-10 storage | done | I changed storage to “Not yet tested”. I did not create a perfect-foresight storage case. |
| A-11 future price direction | partial | I kept flat real prices as a scenario assumption. I did not adopt the review's unverified causal battery statement. |
| A-13 / A-17 price and demand denominators | done | I distinguished potential-output weighting from delivered-output pricing and the 2030 request column from historical noncoincident operating quantities. |
| A-14 / D-Q2,Q3 calendars | partial | I corrected the cross-reference and DST-day wording and used civil-clock labels for the new residual-load figure. I preserved the fixed UTC−6 generation/price mapping rather than relabeling it as civil time. Full common-clock reconstruction would exceed this editorial task. |
| A-16 / A-18 / A-19 dispatch, price cap, fees | partial | I retained the simulated shutdown assumption and did not present it as verified plant dispatch. I retained fees and final-settlement reconciliation in FIN-11. I did not invent a settlement-price-cap explanation or a fee amount. |
| A reply to D — Waha | not done | I retained local gas as a missing mechanism; I did not add an unsourced local-price magnitude or buy data. |
| B-5 manufacturer contracts | done | I added six procurement questions and separated equipment supply from integrated asset/development responsibilities in 13.1. |
| B-4 / B-Q3 / B-S6 Section232 | partial | I checked the official text, effective date and provisions for documentation/pre-existing contracts. HTS annex matching, interaction with other duties and the hypothetical entry date remain unestablished. |
| B-4(ii–vii) / B-Q5 customs and origins | partial | I retained value-per-item without converting unknown units to observed watts, and treated declared country shares as descriptions. I did not infer that a future price floor binds historical entries or attribute changes causally to duties. |
| B-S1 / B-S2 PTC and credit basis | partial | I retained credit choice and basis as FIN-04. I did not insert the review's unverified PTC rate or value range; I highlighted the ≤5MWac interconnection provision's limited relevance. |
| B-S3 US access / B-S5 policy monitoring | partial | I retained market-access qualification and a trade/tax monitoring row. I did not assert a blanket closed market or claim complete current tariff coverage. |
| B-Q1 / B-Q2 / B editing6 glossary | partial | I used the prohibited-foreign-entity term in its tax context and defined it. A complete trade-law glossary and current USITC outcomes remain to be researched. |
| B-Q8 policy cutoff | done | I dated the checked policy context to 9 October 2026 and retained source dates. This is not a certification of every trade rule. |
| C-S1 DC/AC balance / C-S4 MIIT price stages | partial | I retained the incompatible-flow warning, did not create inventory, and checked the supplied MIIT PDF. It supplies only two price-change observations; I did not invent wafer/cell declines. I did not add the optional hypothetical global DC/AC ratio. |
| C-S6 / C-S7 supplier liquidity | partial | I retained company scope and assigned impairment, depreciation, cash, debt and warranty research to FIN-09. I did not assert that write-downs explain most losses without a bridge. |
| C-Q1,Q2,Q3,Q7 / C-Q10,Q11 | partial | I removed obsolete A-share-report language, did not invent utilization, reconciled the eight-name panel and clarified Tongwei's segment. Some navigation and introductory suggestions were incorporated in a different form. |
| D-S5 / D-S6 / D-S7 | done | I derived each node's required discounted-receipt weight (median 44.9%, reference 47.7%), disclosed unharmonized historical nominal price levels, and limited the affine cash-flow identity to the appropriate route. This is not an integer year count. |
| D-Q4 / D-Q8 inference | done | I documented the 168-hour HAC lag, alternatives and failed bootstrap/limited-variation qualifications and avoided treating same-data specifications as independent evidence. |
| D-Q5 S4 plot | partial | I moved the forest to the technical appendix and explicitly explained the nonlinear coefficient. I did not estimate an average marginal effect or rerun any regression; the marker is unchanged. |
| D-Q7 / D-E4 / D-E5 | done | I distinguished reference-node plots from cross-node summaries, consolidated the best-hours discussion and clarified 30-year repetition in table labels. |
| D-Q9 old technical report | not done | I preserved frozen historical reports. This new edition supplies the corrected noncausal interpretation; I did not overwrite the old technical PDF. |
| D-E3,D-E8,D-E9 additional wording | partial | I simplified main-sample and inference discussion. Some optional unit/energy-share parentheticals were not added; the calendar gaps remain disclosed. |

## Numeric proposals not adopted as written

I did not reuse the panel's approximately $43m negative NPV for free modules: it applies a component percentage to a broader cost boundary. The corrected controlled example is about −$48.32m. I did not describe 2025 as wholly pre-RTC+B, treat a 45% receipt weight as an integer count of profitable years, treat separate medians as additive, or mix the earlier real-receipt credit illustration with the new nominal-receipt convention. I preserved the earlier credit illustration in internal historical notes.

## Information that still requires an author or evidence source

1. A documented reason for the historical reference-node choice, if one exists, and any authorized actual project/node mapping.
2. Publicly sourced project/transaction cash-flow definitions, contracts, complete budgets, tax facts, debt terms and actual performance. The Claude brief specifies the fields; no private material is required to begin.
3. Current supply-chain utilization/overseas ownership and unresolved HTS-specific policy evidence if those sections are to be deepened.

I have not updated hours, detailed logs, the weekly log or private evidence. The project remains a research candidate, with factual project-input restrictions unchanged. I have not published or sent the report externally.
