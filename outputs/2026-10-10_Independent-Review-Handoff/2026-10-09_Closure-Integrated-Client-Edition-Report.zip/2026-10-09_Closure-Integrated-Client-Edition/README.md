# SOLAR-001 — Closure-integrated client edition (candidate)

I retain the new English manuscript and its 73-page PDF in this directory. I integrated the fixed 16-item cloud supplement without changing the six baseline scenarios or executing any estimation. This is not original Version 1.0.

## Read first

- `Integrated-Market-Research-Report-EN_Closure-Integrated.pdf`: client-facing report, including bibliography, methods, disclosure boundaries and glossary.
- `Integrated-Market-Research-Report-EN_Closure-Integrated.md`: editable source.
- `Closure-Integration-Change-Log.md` / `.csv`: all 16 dispositions and remaining information.
- `Production-Verification.md` and `support/`: current integration evidence.
- `closure-evidence/`: unmodified cloud findings, claims, source catalog, access log and five small tables.
- `scenario-versions/`: separately labeled existing CPI, credit and VPPA versions.
- `internal/`: inherited editions and governance, including the preserved original Appendix E in `Baseline-Appendices-A-to-E.md`.

I use the report for market screening, procurement questions, contract comparisons and conditional capital-recovery analysis. I do not treat it as a verified asset valuation, a comparable-IRR range or an investment recommendation. Chapter 12 retains the five controlled hypotheses; Appendix C states unavailable fields. The original project-input gate remains unclosed; scenario results do not replace blocked factual-project outputs.

## Packaging (each ZIP below 30 MB)

The `...-Report.zip` contains the report, editable inputs, frozen data/figures, reproduction scripts, source catalogs and visual-inspection evidence. The `...-Supplement-Sources.zip` contains `closure-evidence/sources/` (new original filings/pages, retained extracts and the owner-supplied developer screenshot). Extract both into the same parent directory; both have the same top-level folder. The local directory already contains both sets. Sources are retained for author handoff; rights for redistribution in a paid product have not been established.

## Offline report reproduction

Requirements: Python 3, reportlab, matplotlib and PyMuPDF (fitz; PDF metadata and inspection). No login, network, secret, model package or paid dependency is required by this entry point. From this directory:

```sh
python3 -P scripts/rebuild_closure.py --output-dir /tmp/solar-closure-rebuilt
```

Use a new/empty output directory. The command reconstructs the Markdown from `internal/Finance-Integrated-Input.md` and the frozen closure findings, then renders the PDF using retained figures. It records commands and exit statuses. It does not execute the inherited upstream modeling scripts. The regenerated manuscript and PDF can be compared by SHA-256; the current tested runtime produced identical outputs.

With the supplementary source ZIP extracted, check the newly integrated numbers against retained tables and selected original-text statements:

```sh
python3 -P scripts/check_integrated_numbers.py
```

I do not equate these checks with independent verification of every original claim. Full raw-to-model research reproduction additionally needs the earlier project raw archives; those roughly gigabyte-scale dependencies are not included here and were not rerun.

## Integrity

`File-Manifest.csv` lists file size, SHA-256 and package part. `SHA256SUMS.txt` covers every payload file except the manifest/checksum files themselves. `Manifest.sha256` separately authenticates `File-Manifest.csv`. Each ZIP has its own adjacent `.sha256` file. The external `...-Package-Verification.json` records CRC, safe paths, extracted hashes and independent handoff reproduction.

The cloud download is pinned to Git commit `fe7afe536086685cd223a7b328206588f009a0b3`. Its actual ZIP SHA-256 is `6c7f30ff0f800e131b79b9471c5d91c8028930a8c03171eb9861a4c1631267fe`; the older value quoted in the message is superseded by the downloaded checksum file.
