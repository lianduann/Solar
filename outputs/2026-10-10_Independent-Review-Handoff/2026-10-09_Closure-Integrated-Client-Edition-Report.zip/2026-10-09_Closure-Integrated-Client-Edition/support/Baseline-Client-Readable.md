# From China's Solar Supply Chain to U.S. Power Markets

## Industry Restructuring, Value Capture in ERCOT, and Utility-Scale Solar Economics

**Lucid Direction Insights LLC | SOLAR-001 | Research edition | October 2026**

*Market opportunities and commercial constraints in the context of data-center electricity demand*

**Edition scope.** Research edition, October 2026. This report is for market screening and commercial diligence, not investment advice or a verified asset valuation. Manufacturing evidence covers 2024 and selected FY2025 disclosures; weather and nodal prices cover 2023–2025; regional load evidence uses March and September 2026 snapshots; national demand scenarios extend to 2030.

**Intended readership.** Solar manufacturers and exporters, utility-scale developers, electricity buyers, and research teams.

**Reading navigation.**

| If you are… | Read first |
|---|---|
| A manufacturer or exporter | 1, 4, 5, 13.1 |
| A developer or investor | 1, 8, 10, 11.3, 13.2 |
| Selling electricity to large loads | 1, 6, 8.1–8.2, 13.4 |
| A research or consulting team | 2, 8.6–8.8, 11.6–11.9, Appendix B |

# 1. Executive Summary: Lower Equipment Prices Require a Commercial Route to Project Value

## 1.1 Key findings

**At the reference node, the hypothetical solar system fails to recover capital under 2024–2025 price conditions. Lower module prices improve that result, but do not close the gap in the stated cost-transmission example.**

1. In the 2025 reference case, delivered electricity costs about $48.9/MWh while modeled sales earn $26.4/MWh. NPV is -$86.0 million. Even cumulative undiscounted cash flow remains negative in both base revenue routes. [S08]
2. Capital recovery requires about $66/MWh under a flat nominal contract, or capital cost near $577/kWac under the historical nodal-price route, compared with the base $1,437/kWac. These are different revenue mechanisms, evaluated at 4.27% real discounting. [S08]
3. Applying the benchmark-derived 8.9% capital-cost reduction improves reference NPV by $12.8 million, closing about 14.9% of the shortfall. This is a hypothetical cross-benchmark calculation, not observed U.S. delivery-price transmission. [R-A]
4. The 2023 price year produces positive NPV at all 485 sampled nodes; the 2024 and 2025 same-year cases leave only 13 and 2 positive. In 2023, the top 1% of price intervals account for 54.7% of the median node's receipts; deleting those receipts makes 482 nodes negative. [E-A, E-C]
5. Timing materially changes the value of output. The 2025 reference-node average price is $46.37/MWh, versus $22.13/MWh weighted by potential solar production. Negative prices occupy 6.2% of intervals but coincide with 15.2% of potential generation. [S06, S07]
6. Large-load requests are a prospect pool, not contracted solar sales. ERCOT's March process table shows 238.6 GW in the 2030 column against about 5.8 GW observed energized; the latter is a historical noncoincident-peak measure. In a separate 11-project self-supply sample, gas represents about 83% of generation-related power capacity and solar about 11%. [R-C]

## 1.2 Key numbers

**Table 1-1. Economics of the 2025 reference scenario and comparison settings.**

| Measure | Value | Basis / section |
|---|---|---|
| Capital cost | $1,437/kWac; $143.7m | National reference assumptions; 10.2 |
| Delivered-energy LCOE | $48.9/MWh | Real 2025 dollars; 4.27%; 10.6 |
| Realized sales price | $26.4/MWh | Reference node, stop exports below zero; 8.2 |
| Reference NPV | -$86.0m / -$95.3m / -$103.3m | 4.27% / 6% / 8% real; 10.4 |
| Flat nominal break-even contract price | $66.0/MWh | Fixed-price route; 11.3 |
| Nodal break-even capital cost | $577/kWac | About 40% of base cost; 11.3 |
| Receipts needed for zero NPV | $12.1m in year 1 | Constant-real price-profile case; 10.8 |
| Module share of PV-only cost benchmark | 26.1% | National component model; 5.5 |
| Hypothetical CAPEX / NPV improvement | 8.9% / $12.8m | Cross-benchmark example; 5.5 |
| Same-year positive nodes, 2023 / 2024 / 2025 | 485 / 13 / 2 out of 485 | Common calendar, identical financial assumptions; 10.8 |

*Sources: scenario results [S08], component model [R-A], multi-year analysis [E-A]. Model assumptions are summarized in Box 1. Cost, output and revenue figures refer to a hypothetical system.*

## 1.3 How to interpret and use the findings

The 2025 system produces 292.4 GWh of potential AC electricity; stopping exports during negative-price intervals leaves about 247.8 GWh delivered. The gap between an average market price and the price paid for solar output is therefore commercially material. A factory-price reduction affects only part of investment cost, while a contract determines which output is paid and when.

TAYGETE2_ALL is a reference price location, not an established settlement relationship for the simulated site. Its selection rationale is **not disclosed in this edition**. Its absolute production-weighted price is near the 37th percentile in the separate 2025 cross-section, while its ratio to its own average price is near the third percentile. Those percentiles measure different properties. The three-year panel's 2025 median NPV is -$81.3 million, also negative; the historical reference case is not a complete account of the market. [R-B, E-A]

Each historical price shape is repeated for 30 operating years in real terms in the same-year comparison. A positive 2023 result consequently asks what happens if that market pattern persists; it is not an expected return. The strong price-year effect and concentration of receipts make contract structure and exposure to scarce high-price hours central diligence questions.

Manufacturers can use Chapters 4–5 to frame a complete procurement proposition. Developers can use Chapters 8–11 to assess the receipts and cost combination needed for capital recovery. Power sellers targeting large loads should qualify the buyer's required delivery profile, connection progress and ability to pay for reliable supply. The report supports these screening decisions while actual procurement, taxes and financing remain project-specific.

> **Limits of this chapter.** (1) The headline case uses one historical reference node; its selection rationale and actual project settlement relationship are not disclosed in this edition. (2) Returns exclude taxes, credit eligibility and debt. (3) Historical-year repetition is a stress setting.

# 2. Analytical Framework: Connecting Equipment Supply to Paid Electricity

Principal abbreviations are defined here and in Appendix D: the Electric Reliability Council of Texas (ERCOT), China’s Ministry of Industry and Information Technology (MIIT), the International Renewable Energy Agency (IRENA), the Annual Technology Baseline (ATB) and the Photovoltaic System Cost Model (PVSCM). The U.S. Department of Energy (DOE) and National Laboratory of the Rockies (NLR; NREL in older publications) supply the national cost references.

## 2.1 Three analytical layers, with distinct evidence requirements

The analysis comprises three layers. The first examines Chinese and global solar supply, including manufacturing activity, equipment prices, and producer economics. The second examines the ERCOT market, including load, generation, and the geographic and temporal structure of electricity prices. The third evaluates an independently simulated solar system under specified economic scenarios.

The connections between these layers determine the strength of the commercial conclusions. Manufacturing prices enter project costs through procurement specifications and delivered-cost terms. System demand enters revenue through a particular location, delivery profile, and commercial arrangement. Weather becomes generation through system design and performance assumptions. Generation becomes cash flow through paid volumes, realized prices, operating costs, capital expenditure, and timing.

An observation in one layer is insufficient to substitute for missing evidence in another. A site's budget requires project cost evidence; its generation requires site and system inputs; its commercial settlement point requires a documented settlement relationship.

## 2.2 Definitions that affect interpretation

**Table 2-1. Definitions used in the report.**

| Measure | Interpretation used in this report | Comparison requiring additional evidence |
|---|---|---|
| Manufacturing output | Production at a specified manufacturing stage during a stated period | Nameplate capacity, effective capacity, utilization, or installed generating capacity |
| Cumulative PV capacity | Installed capacity stock under the source's definition | Annual module purchasing or shipments |
| MWdc / MWac | DC module capacity / AC rated capacity | Cost and capacity-factor measures using a different denominator |
| Time-weighted price | Average price across available market intervals | A solar project's realized price |
| Generation-weighted price | Interval prices weighted by simulated generation | Net receipts under a commercial contract |
| LCOE | Levelized cost using the stated cost scope and energy denominator | A market quotation, achievable selling price, or complete asset cost |
| NPV | Net value of the defined cash flows at a specified discount rate | Verified market value or an actual transaction valuation |
| IRR | Discount rate at which the defined cash flows have zero NPV | A single return measure where multiple admissible roots exist |

These distinctions are particularly important when comparing manufacturing statistics with project data. Converting a module quote per Wdc to total capital cost per kWac requires the DC/AC ratio and a reconciliation of included cost categories.

## 2.3 Observations, calculations, and assumptions

The manuscript distinguishes reported observations from derived results and analytical assumptions. MIIT's annual price changes are reported observations. Capture prices are calculations from the generation and price inputs. The connection between contracts and receipts is a commercial mechanism. The fixed $40/MWh price and its unpaid-energy reduction are scenario assumptions.

The underlying periods also differ. Manufacturing observations for 2024 and selected FY2025 disclosures, weather and prices for 2023–2025, publications released in 2026, and modeled demand for 2030 do not constitute a single contemporaneous dataset. Publication dates, observation periods, acquisition dates, and projection years must remain separate.

Policy sections require verification against the final publication cutoff. The historical pages establish the material available at their acquisition dates; they do not by themselves certify the current application of a rule.

## 2.4 How to read scenario results

> **Box 1. How to read the numbers in this report.** The system is hypothetical: 100 MWac / 132 MWdc in Pecos County. Returns are pre-tax, unlevered and exclude tax credits, financing and unverified project costs. Nodal scenarios repeat a historical price shape for 30 years, with disclosed degradation and selected price trends; fixed-price scenarios hold a nominal price constant and deflate it by 2.5% annually. The 4.27% real discount rate is an analytical benchmark, with 6% and 8% alternatives. Statistical estimates describe conditional associations, not causal effects. Upside/downside bundles, tail stresses and three-year mixtures have no forecast probabilities attached.

The scenario results are conditional on stated assumptions and are not a verified valuation of an actual asset.



## 2.5 Five working hypotheses

**H1 — Equipment price.** Lower module prices improve project economics, but their effect may be smaller than financing, interconnection delay, curtailment or realized power prices.

**H2 — Demand and value.** Data-center load growth does not automatically raise an individual solar project's realized price or bankability.

**H3 — Value chain.** Manufacturing scale and lower upstream prices can coexist with weak value capture along the solar value chain.

**H4 — Grid constraints.** Grid constraints can affect the deliverable value of solar output.

**H5 — Storage.** Storage can improve solar economics by changing delivery timing, subject to its incremental costs and operating limits.

> **Limits of this chapter.** (1) Source observations, accounting identities, conditional associations and hypothetical returns answer different questions. (2) Prices, costs and demand are dated separately. (3) See Box 1 and the technical notes for model boundaries.

# 3. Global Solar Demand: Industry Scale Does Not Define an Accessible Market

## 3.1 Installed capacity establishes the scale of deployment

the IRENA series reports global solar PV capacity increasing from 293,159 MW in 2016 to 2,383,162 MW in 2025. China increases from 77,788 MW to 1,200,359 MW over the same period. China is included within the world total; the two series are not additive. [S03]

![Figure 3-1. Global and Chinese cumulative solar PV capacity, 2016–2025](figures/04_irena_capacity.png)

*Source: IRENA, Renewable Capacity Statistics 2026, physical PDF pages 37–38. Underlying table: the corresponding source table. China's entries carry the source flag u. The series retains the source's capacity definition.*

The data establish deployment scale, but installed stock is not a sufficient measure of a supplier's addressable market. It does not identify procurement volumes in a particular year, replacement demand, technology requirements, supplier eligibility, or attainable margins. For market-entry decisions, the procurement flow and the conditions of access are more directly relevant than cumulative capacity alone.

## 3.2 Capacity changes, shipments, and production measure different activity

The difference between adjacent years of capacity is a net change in the reported stock. It is not necessarily identical to new installations or module shipments. Construction timing, channel inventory, transport, retirements, revisions, and capacity definitions can separate these measures.

A manufacturing-to-demand balance therefore requires compatible flows. Subtracting changes in global installed capacity from Chinese module production would combine unlike measures and could create a misleading estimate of inventory or excess supply.

The timing of commercialization also matters. Equipment may be manufactured and shipped before a project's connection or financing is secured. A change in technology or module power density may alter procurement requirements without a proportional change in reported generating capacity. These mechanisms require explicit data before their magnitude can be assessed.

## 3.3 Regional evidence

### Country contributions reveal concentration within global growth

the IRENA tables place global PV capacity at 1,872.8 GW in 2024 and 2,383.2 GW in 2025. Their difference is 510.3 GW. China's corresponding change is approximately 314.2 GW, or 61.6% of the global change. India contributes approximately 37.0 GW and the United States 34.0 GW. Germany, Brazil, and Spain follow at approximately 15.1, 11.6, and 9.0 GW. These figures describe where installed capacity increased under IRENA's definitions; they do not identify the origin of equipment purchased or the profitability of serving each market. 

![Figure 3-2. Country contributions to 2025 PV capacity growth](figures/S01_country_net_change.png)

*Source: the IRENA country series, derived 2025 minus 2024; GW. Net capacity change can differ from gross annual installations. Small differences reflect rounding in the source and saved tables.*

Concentration matters for market development because global scale can overstate the demand directly accessible to an exporter. Country demand must be evaluated alongside trade treatment, local procurement preferences, distribution channels, and the mix of utility-scale and distributed systems. Estimating a supplier's accessible revenue pool requires regional product and market-access assumptions as well as capacity growth.

EIA's July 2026 U.S. capacity table separately reports approximately 165.3 GW of utility-scale solar and 62.8 GW of estimated small-scale solar, with a printed total of 228.2 GW. Rounded components need not sum exactly to the printed total. The observation date and measurement conventions differ from IRENA's year-end 2025 U.S. stock. The two sources are presented as separate views rather than reconciled through an unsupported adjustment. 

### The manufacturing-to-installation comparison does not close a quantity balance

For the 2024 comparison (distinct from the 2025 additions above), China's reported module manufacturing output of 588 GW exceeds the 457.7 GW change in global PV capacity by approximately 130.3 GW. The arithmetic is reproducible, but its economic interpretation is limited. Output, shipments, construction, commissioning, and stock reporting occur at different times; capacity conventions and geography also differ. The residual has no validated inventory, unsold-product or overcapacity interpretation. A defensible inventory bridge would require compatible shipment, trade, opening-stock, closing-stock, and loss data. 

The comparison is therefore useful as a warning about incompatible measures, rather than as an estimate of excess supply. Evidence of pricing pressure and producer margins remains analytically separate from the unclosed physical quantity balance.

## 3.4 Implications for market screening

The available capacity series establishes a large and expanding deployment base. A supplier's attainable orders, margins and delivery obligations require separate commercial evidence.

Market screening should therefore proceed through four questions: the scale and composition of end demand; eligibility to supply; the ability to deliver the required product; and the economics of serving that demand. Chapters 4–8 address the mechanisms and evidence needed for the latter three questions.



> **Limits of this chapter.** (1) Net capacity additions differ from shipments and manufacturing output. (2) Country demand is not equipment origin. (3) Inventory and effective capacity remain unmeasured on a comparable basis.

# 4. China's Solar Manufacturing Industry: High Output Can Coexist with Margin Pressure

Several reported businesses combine losses or weak margins with reduced long-lived-asset spending. The panel below distinguishes segment profitability, group cash generation and investment cash outlays: these measures identify commercial pressure without assigning a common cause or ranking manufacturers across different businesses and currencies.
## 4.1 The 2024 manufacturing evidence

MIIT's publication reports Chinese polysilicon output exceeding 1.82 million metric tonnes in 2024, alongside wafer output of 753 GW, cell output of 654 GW, and module output of 588 GW. These are successive manufacturing stages. Adding their GW figures would double-count successive production stages; differences between them do not measure inventory. [S01]

**Table 4-1. Manufacturing-stage observations, 2024.**

| Stage or indicator | Reported 2024 observation | Supported interpretation |
|---|---:|---|
| Polysilicon output | More than 1.82 million metric tonnes | Production scale at the specified stage |
| Wafer output | 753 GW | Stage-specific manufacturing output |
| Cell output | 654 GW | Manufacturing output, not generating capacity |
| Module output | 588 GW | Manufacturing output, not U.S. deliveries |
| Polysilicon price change | -39.5% | Source-reported annual price direction |
| Module price change | -29.7% | Source-reported annual price direction |

![Figure 4-1. Reported price changes at selected manufacturing stages](figures/01_miit_prices.png)

*Source: the supplied MIIT PDF and the official republication used for reconciliation. Underlying table: the corresponding source table. The chart shows annual changes, not a continuous transaction-price series.*

The price declines justify investigation of procurement opportunities, but the observations lack a continuous product-specific price series and transaction terms. They do not identify intra-year price floors, contract lock-in, or technology premiums. Applying the reported module decline directly to U.S. project CAPEX would ignore both the module share of investment and the cost of delivery into the relevant market.

## 4.2 Company financial panel: margins and cash flows answer different questions

**Table 4-2. Company financial observations; cash amounts in billions of the stated currency.**

| Company | Stage | FY | Gross margin | Net result | OCF | Asset cash | Currency | Basis |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Canadian Solar | Modules + projects | 2024 | 16.7% | n/a | -0.89 | 1.11 | USD | Group; productive-asset cash |
| Canadian Solar | Modules + projects | 2025 | 18.3% | n/a | -0.25 | 0.96 | USD | Group; productive-asset cash |
| Daqo New Energy | Polysilicon | 2024 | -20.7% | n/a | -0.44 | 0.36 | USD | Group; PPE cash |
| Daqo New Energy | Polysilicon | 2025 | -20.7% | n/a | 0.05 | 0.17 | USD | Group; PPE cash |
| First Solar | Thin-film modules | 2024 | 44.2% | n/a | 1.22 | 1.53 | USD | Group; PPE cash |
| First Solar | Thin-film modules | 2025 | 40.6% | n/a | 2.06 | 0.87 | USD | Group; PPE cash |
| JinkoSolar Holding | Integrated PV | 2024 | 10.9% | n/a | 16.85 | 9.09 | CNY | Group; PPE cash |
| JinkoSolar Holding | Integrated PV | 2025 | 2.2% | n/a | 1.08 | 3.19 | CNY | Group; PPE cash |
| Trina | Integrated PV | 2025 | 4.6% | -7.03 | 6.90 | 4.67 | CNY | Segment margin; LLA cash* |
| JA Solar | Cells/modules | 2025 | −2.1% | -4.61 | 4.28 | 5.04 | CNY | Segment margin; LLA cash* |
| Tongwei | Silicon/cells + feed | 2025 | −1.12% | -9.55 | 1.38 | 13.06 | CNY | Segment margin; LLA cash* |
| LONGi | Modules/cells | 2024 | 6.27% | n/a | n/a | n/a | CNY | Segment only |
| LONGi | Wafers/ingots | 2024 | −14.31% | n/a | n/a | n/a | CNY | Segment only |

Sources: company annual filings and XBRL [S02, R-D, R-F]. Net result is profit attributable to shareholders where available; n/a means unavailable in the extracted comparable panel, not zero. OCF means operating cash flow. PPE cash is cash paid for property, plant and equipment; Canadian Solar’s extracted productive-asset cash line has a broader reported scope. LLA cash is cash paid for fixed, intangible and other long-lived assets; *the consolidated-versus-parent statement scope for these three extracted amounts has not been separately confirmed. The A-share gross margins are segment measures: PV for Trina and Tongwei, new energy for JA. Tongwei's group cash flows include feed/food activities. LONGi's rows show segment margins only. Currencies are not converted, so cash levels are not a cross-company ranking.

Daqo's two margins both round to −20.7%, but are different observations: FY2024 gross loss of $212.932m on $1,029.080m revenue, versus FY2025 gross loss of $137.851m on $665.415m revenue. The underlying annual XBRL entries confirm that the apparent duplication is rounding, not a repeated input. [R-D]

## 4.3 Procurement implications extend beyond the quoted price

A procurement assessment needs to consider delivery continuity, warranty execution, and system compatibility alongside equipment price. The timing of these exposures differs: a lower acquisition price reduces an initial outlay, while performance or supply failures may affect subsequent delivery and operations. The evidence does not quantify supplier default probabilities or expected warranty losses.

For producers, competitiveness during a period of price declines requires assessment of costs, liquidity, product differentiation, and market access. That assessment requires more than one gross-margin observation. Differences in geography and product mix can affect profitability without establishing a corresponding difference in manufacturing efficiency.

## 4.4 Competitive analysis requiring further evidence

A matched competitive panel would align product technology, segment boundaries, currency, fiscal period, utilization denominator and the treatment of incentives. Until those definitions are comparable, Table 4-2 is a financial observation panel rather than an efficiency league table.






## 4.5 Common-period company evidence shows heterogeneous financial outcomes

The expanded panel uses the filings for JinkoSolar, Canadian Solar, Daqo, and First Solar, with FY2024 and FY2025 reported separately. The companies participate in different technologies and stages of the value chain. Consolidated gross margins are therefore useful for describing outcomes within each company over time, but differences in business scope preclude an unadjusted competitive ranking. 

![Figure 4-2. Within-company gross-margin changes](figures/S02_company_margins.png)

*Source: the SEC filings and extracted annual XBRL contexts. Percent; consolidated reported gross profit divided by revenue. Company order is alphabetical; this is not a ranking of operating efficiency.*

Cash generation adds another dimension. JinkoSolar's operating cash flow falls from approximately CNY16.85 billion to CNY1.08 billion between FY2024 and FY2025. Canadian Solar reports operating outflows in both years, while First Solar reports positive operating cash flow. Daqo's FY2025 operating cash flow is positive despite a negative gross margin. Working-capital movements, business mix, and other cash-flow items can produce such differences; equipment prices alone are not an identified explanation for reported cash flow.

Capital spending also requires account-level interpretation. Canadian Solar's extracted cash-flow item covers payments to acquire productive assets, a broader label than an automatically comparable factory-expansion measure. LONGi's FY2024 investing cash flow is broader than capital expenditure and is not used as that measure here. The panel consequently preserves currencies and filing definitions rather than combining all companies into a single cost or cash-efficiency league table.

## 4.6 Utilization indicators require explicit capacity denominators

LONGi's FY2024 disclosures provide reported utilization and production measures for its own operations. Those company-defined measures can support a within-company discussion when the production boundary and effective-capacity denominator are used. They describe LONGi, not industry-average utilization. Daqo's annual production divided by a point-in-time nameplate figure is a different indicator: capacity may have changed during the year, so that ratio is not a validated annual utilization measure. 

Daqo's disclosed selling prices likewise describe its own product mix and sales period. They provide corroborating company evidence of pressure at one manufacturing stage, rather than a continuous extension of MIIT's industry price-change series. FY2025 A-share annual reports and a consistent multi-company capacity panel remain necessary before drawing broader cycle or utilization conclusions.

## 4.7 Additional FY2025 disclosures broaden the manufacturing sample

The extended analysis adds the FY2025 annual reports for Trina Solar, JA Solar, and Tongwei to the four-company panel. Reported revenue is approximately CNY66.97 billion, CNY49.13 billion, and CNY84.13 billion respectively; attributable net losses are approximately CNY7.03 billion, CNY4.61 billion, and CNY9.55 billion. Tongwei includes feed-related activities, and the companies' consolidation and product boundaries differ. These results therefore broaden evidence of financial pressure without constituting a product-matched efficiency ranking. [R-F]

Reported cash payments for construction and acquisition of long-lived assets also decline: approximately CNY4.67 billion versus CNY13.29 billion for Trina, CNY5.04 billion versus CNY11.83 billion for JA Solar, and CNY13.06 billion versus CNY28.39 billion for Tongwei in FY2025 versus FY2024. The spending measure is the under its filing definition and is not automatically equivalent to incremental capacity investment. Lower spending can reflect project completion, reduced expansion, or financing and working-capital choices; the observations alone do not identify which mechanism dominates.

The expanded sample supports a more differentiated view of manufacturing economics. Consolidated loss, segment gross margin, cash generation, and capital spending measure distinct outcomes. LONGi's full FY2025 annual report remains unavailable in the research, and a harmonized segment panel remains incomplete.

> **Limits of this chapter.** (1) Consolidated and segment accounts differ; currencies and business mixes remain separate. (2) Losses and lower capital spending indicate pressure but do not identify an industry-wide cause or rank producers. (3) The additional evidence required is listed in Appendix C.

# 5. Cost Transmission: A Lower Module Price Reduces Only Part of Project Investment

## 5.1 The delivered-cost bridge

Manufacturing price changes can be translated into project costs only after three questions are resolved: whether the products are comparable; which delivery and trade terms apply; and what share of the relevant project budget the product represents.

Prices expressed per watt may differ in technology, currency, taxes, freight, delivery date, warranty, and payment terms. A decline in an annual manufacturing-price measure does not demonstrate an equivalent saving for a U.S. buyer purchasing a compliant product under specified delivery conditions.

The commercial comparison is consequently between complete procurement packages. A lower factory price may be offset by changes in logistics, sourcing conditions, timing, or other costs. The magnitude and direction of those offsets require evidence rather than a general assumption about imported-equipment competitiveness.

## 5.2 Module share determines the direct CAPEX effect

With module quantity, system design, and all other costs held constant, the direct relationship is:

**Relative change in total CAPEX ≈ initial module share of CAPEX × relative change in module unit price.**

Let the initial module cost share be `s` and the module price change be `m`. The isolated effect on total investment is then `s × m`. The evidence does not support filling `s` with a verified project-specific or comparable delivered-cost share. The MIIT decline of 29.7% is therefore not applied directly to total CAPEX. Section 5.5 shows an illustrative calculation using a benchmark component share.

Changes in efficiency, module power, or system design may also affect racking, land, installation, or electrical requirements. Those effects require a component-level analysis. A single price multiplier holds product and project scope constant.

## 5.3 What the ATB benchmark contributes

The economic scenarios use ATB overnight capital cost, or OCC, plus grid-connection cost, or GCC. These references provide a national technology-cost anchor and cost definitions. They do not measure the transmission of Chinese manufacturing prices into a particular U.S. project.

The cost extract does not separately itemize module procurement within the scenario CAPEX. Consequently, the total-CAPEX sensitivity measures a change in the complete capital budget, not an isolated module-price effect. [S08, S09]

## 5.4 Evidence required for an empirical transmission analysis

An empirical delivered-cost bridge needs matched module specifications, dates, origin, logistics, duties and procurement terms. The next section quantifies the conditional engineering-cost channel using national model inputs; it does not measure transaction-price transmission.






## 5.5 A reproducible component model bounds the transmission mechanism

Re-evaluation of the DOE/NLR 2025Q1 utility-scale cost-model inputs produces a PV-only modeled market price of approximately $1.115/Wdc in 2024 dollars. The corresponding minimum sustainable price is approximately $1.066/Wdc. These are modeled national benchmarks with different economic interpretations, not alternative quotations offered to the hypothetical Pecos County project. Published PV-plus-storage component groups reconcile within $1/kWdc, and the rounded PV-only total provides a separate cross-check. This does not constitute validation against observed project invoices. 

![Figure 5-1. Components of the PV-only modeled market price](figures/S03_cost_components.png)

*Source: reimplementation of DOE/NLR PVSCM 2025Q1 inputs; 2024 dollars per Wdc. Storage and storage-related items excluded. Shares are derived from the unrounded total. The chart uses the DC denominator throughout.*

Modules account for approximately 26.1% of the modeled market-price total. Electrical balance of system and fieldwork are also material. The cost model includes sales tax, contingency, overhead, and developer profit, so a change in the module input affects more than the module line itself. Under the additive percentage structure, a $1/kWdc change in the module input changes total modeled cost by approximately $1.144/kWdc, with all other inputs held constant. 

Applying MIIT's reported 29.7% module-price decline to that U.S. model input would reduce total modeled capital cost by approximately 8.9%. This is a hypothetical comparative-static exercise. It assumes that the U.S. component input changes by the same percentage as MIIT's reported measure, holds specifications and every other model input constant, and does not estimate actual observed U.S. price transmission. Observed U.S. delivery-price transmission remains unmeasured.

![Figure 5-2. Hypothetical module-input changes and total modeled cost](figures/S04_passthrough.png)

*Source: baseline module share multiplied by the modeled marginal factor, with all other inputs fixed. Horizontal axis: assumed module-input percentage change; vertical axis: modeled total PV-only capital-cost percentage change. This is neither a historical regression nor a forecast.*

Only DC-basis benchmark values are used. See Appendix B for denominator qualifications.

## 5.5a From the component-cost example to project NPV

Applying the rounded 8.9% percentage to the ATB-based scenario CAPEX reduces the end-2026 cash outlay by approximately $12.79 million. Evaluating the existing annual cash-flow equation with that single changed payment improves node_base NPV from -$85.97 million to -$73.18 million, closing 14.87% of its gap; fixed_base improves from -$73.74 million to -$60.95 million, closing 17.34%. Other costs and receipts are held constant. This calculation is exact for the rounded 8.9% input and the model's cash-flow timing; the transmission percentage itself is illustrative. [R-A, S08]

This applies the PVSCM-derived percentage to the ATB-based scenario cost; it is not observed U.S. price pass-through. It shows that this component-price example alone leaves a substantial capital-recovery gap under the reference 2025 conditions. It supplies no general ranking of other return drivers.

## 5.6 Policy changes make procurement dates and classification commercially relevant

Proclamation 11052, published August 11, 2026, specifies a $0.38/W minimum import price for solar modules. Its operative provisions apply from December 4, 2026 to covered entries and include documentation rules, pre-existing-contract treatment, additional duties, and exceptions. The headline price is not a universal delivered-project quotation. Product classification, origin, entry date, and applicable exceptions require separate verification before building a procurement cost. The annex-level HTS mapping remains unresolved in this report. [Federal Register, clauses 1–6](https://www.govinfo.gov/content/pkg/FR-2026-08-11/html/2026-16400.htm)

The additional trade register is the as an evidence map, not a certified all-in tariff calculator. IEEPA treatment, the interaction of duties, and unresolved investigation outcomes remain outside the quantified cost bridge. No tariff benefit or incentive eligibility is assigned to the hypothetical project.

The cost benchmark's module line is about $0.29/Wdc, whereas the cited proclamation records a $0.38/W import-price floor for covered entries from December 4, 2026. These belong to different cost boundaries and dates: the benchmark uses a U.S.-assembled module input including its stated subsidy treatment, while the rule applies to covered imported products. A verified common nameplate-Wdc denominator and product/origin/exception match are **not disclosed in this edition**. The nominal comparison signals a possible limit to factory-price transmission, rather than a quantified duty-inclusive procurement saving. [R-A, P01]

## 5.7 Import value and sourcing shifts provide context, not a delivered-price series

the Census analysis covers monthly U.S. imports from January 2024 through August 2026 for specified solar cell and module classifications. Module customs value under HS 854143 is approximately $14.4 billion in 2024 and $6.4 billion in 2025. On the comparable January–August window, values are approximately $11.64 billion, $4.43 billion, and $2.82 billion in 2024, 2025, and 2026. A decline in customs value can reflect quantity, product mix, reported unit value, and sourcing changes; it is not itself an estimate of end-market demand contraction or project savings. [R-T]

The reported country composition changes substantially. Vietnam and Thailand represent large shares in 2024, while Indonesia and Laos become more prominent in 2025; the 2026 January–August mix includes larger shares attributed to the Philippines, Ethiopia, and Kenya. These are the categories reported in the customs data. Identifying physical production routes, circumvention or the causes of sourcing shifts requires additional evidence.

For HS 8541430010, the January–August value-per-unit calculation is approximately $152.5 in 2024, $106.6 in 2025, and $105.5 in 2026. The quantity unit is an item, not watts. Module capacity, product specification, delivery terms, tariffs, and logistics are not sufficiently matched to convert this into a U.S. delivered price per watt. The data strengthens trade context while leaving the procurement bridge open.

> **Limits of this chapter.** (1) The 8.9% cost bridge is illustrative and combines two national benchmarks. (2) Delivered quotes, product specifications and full trade applicability remain missing. (3) Only DC-basis benchmark component values are used.

# 6. Data-Center Demand: Annual Energy and Continuous Supply Are Different Products

## 6.1 National scenarios establish a range of modeled demand

Berkeley Lab's United States Data Center Energy Usage Report: 2025 Update, published in June 2026, presents seven scenarios for 2030 in Table 2. The reference case is 649 TWh. The compounded-uncertainty low and high cases are 521 TWh and 843 TWh, corresponding to 9.5% and 15.3% of U.S. electricity consumption. These are modeled scenarios, not statistical confidence intervals. [S04]

![Figure 6-1. U.S. data-center electricity-demand scenarios for 2030](figures/08_lbnl_scenarios.png)

*Source: the original report from the official DOE document path, physical PDF page 11 / printed page 9, Table 2. Underlying table: the corresponding source table. Coverage is all U.S. data centers, not AI alone or ERCOT.*

Presenting all seven cases preserves the sensitivity to deployment and technology assumptions. Selecting only the largest outcome would conceal the range of modeled demand. Translating any national case into regional generating-project orders requires additional evidence on location, project realization, and procurement.

## 6.2 Procurement requirements determine the product being sold

Annual renewable-energy procurement concerns energy or attributes over a defined period. Hourly matching introduces a time requirement. Continuous supply additionally requires arrangements for reliability and shortfalls. A solar system's annual contribution does not eliminate the need to address nighttime or low-output periods.

For developers, these distinctions affect obligations and risk allocation. As-generated purchases, fixed delivery blocks, and continuous supply place different quantity responsibilities on the seller or buyer. Contract prices and risks consequently depend on the product and obligations as well as demand.

The present discussion sets out commercial mechanisms. Comparable contract samples have not yet been assembled, so no specific customer's procurement terms are attributed to the market as a whole.

## 6.3 ERCOT's observed operating shapes illustrate the timing issue

the non-DST-day sample for 2025 contains 363 dates and 8,712 matched hours. Mean system solar output peaks at local hour-ending 14, while mean system load peaks at hour-ending 18. This describes average system operation, not the load profile of a particular data center. [S05]

The timing difference supports investigation of complementary supply and delivery products. It does not quantify unmet data-center demand. ERCOT includes other generation resources and non-data-center loads; subtracting the two system curves would not establish a customer's storage requirement.

## 6.4 Regional realization and procurement evidence

The regional process records below separate requests, approvals and observed energized load. Commercial qualification additionally needs a customer, connection date and specified procurement product; these are distinct from the national energy-demand scenarios.




## 6.5 Regional process evidence separates requested load from operating demand

ERCOT's March 2026 status deck reports a 238.6 GW total in its 2030 large-load process table. Approximately 5.8 GW is classified as observed energized. The source defines that operating measure through historical noncoincident peak observations, so it should not be described as simultaneous metered demand. The other categories concern requests, studies, or approvals and represent materially different levels of completion. 

![Figure 6-2. Large-load process categories in the March 2026 snapshot](figures/S05_load_status.png)

*Source: ERCOT March 2026 large-load status table, 2030 column; GW. Category totals describe the source's process snapshot, not a probability-weighted load forecast. Observed energized is a noncoincident historical measure. The chart does not add Batch Zero quantities.*

The disparity between requested and operating quantities makes project qualification more important than the headline queue size. An equipment supplier or developer needs to know whether a prospective customer's location, electrical connection, construction schedule, and power procurement have progressed together. The public status table does not reveal customer-specific conversion probabilities or contracted solar requirements.

September 2026 Batch Zero materials classify 204 projects and 66.4 GW as conditional base load, and 158 projects with 125.4 GW in the studied-load chart. The deck also uses 127.9 GW in its narrative. That source inconsistency remains unresolved; 125.4 GW is the only as the chart-labeled quantity, with the alternative explicitly disclosed. Excluded requests form a separate category. None of these September quantities is added to March's process total. Different dates, population definitions, and conditional treatment prevent a defensible additive demand estimate. [R-C: Batch Zero deck, physical pages 1 and 6–8]

## 6.6 Self-supply evidence indicates a requirement for more than solar energy

The September deck reports resource power capacities associated with 11 WLPUN projects: approximately 12.824 GW of gas, 1.654 GW of solar, 0.637 GW of wind, and 0.330 GW of battery capacity. Gas represents approximately 83.0% and solar 10.7% of the reported mix. Component sums differ by 1 MW from the printed total, consistent with source rounding. These are reported power-capacity categories, including storage, rather than shares of generated energy or a census of data-center supply contracts. 

![Figure 6-3. Resource power capacities associated with 11 WLPUN projects](figures/S06_wlpun_capacity.png)

*Source: ERCOT September Batch Zero deck; GW. Battery capacity is a power rating, not primary energy generation. The sample is not a census of data-center procurement.*

The sample points to a supply-service distinction: gas is about 83% and solar about 11% of the reported power-capacity mix. A solar offer for a buyer requiring continuous supply may need firming, storage or coordination with dispatchable generation. Procurement preferences outside this sample remain unmeasured. It does not quantify the cost premium for continuous supply, determine the optimal gas/solar/storage combination, or prove that an individual buyer has selected a particular product. Such conclusions require dispatch, reliability, fuel, emissions, network, and contract analysis on a common service basis.

> **Limits of this chapter.** (1) Process requests and observed noncoincident peaks are different quantities. (2) March and September snapshots are not additive. (3) The 11-project self-supply mix is power capacity, not energy or a census of data-center procurement.

# 7. ERCOT Market Conditions: Location and Timing Jointly Shape Value

## 7.1 Market references and settlement exposure

Nodal prices provide historical references for specific settlement locations. Hubs and load zones provide broader market context. These locations are not interchangeable, and the hypothetical system has no documented actual settlement relationship.

The NP6-905-CD product examined here reports 15-minute real-time settlement-point prices. Combining day-ahead, real-time or different-location prices requires explicit identification of the change in price basis. Actual receipts may also depend on contracts, dispatch, fees, and quantity obligations. The modeled nodal revenue is gross energy value under the specified reference-price rule. [S06]

## 7.2 Intraday and seasonal system conditions

![Figure 7-1. Mean intraday load and solar output in ERCOT, 2025](figures/05_ercot_hourly.png)

*Source: the ERCOT native-load and Solar/FINAL files. Underlying table: the corresponding source table. The sample covers 363 non-DST dates. Load is in MW; solar is MWh per hour, shown separately.*

![Figure 7-2. Seasonal ERCOT load and solar output, 2025](figures/06_ercot_seasonal.png)

*Underlying table: the corresponding source table. All 365 dates are used. Monthly mean load is weighted by actual source hours; solar is summed from source-aligned intervals. Annual coverage reconciles to 8,760 load hours and 35,040 solar intervals.*

Average load is approximately 66.4 GW in August and 46.7 GW in March. System solar generation is approximately 7.42 TWh in August and 3.34 TWh in January. These observations show seasonal variation. They do not isolate weather effects: installed-capacity changes, availability, and dispatch can also affect system generation. [S05]

## 7.3 Regional screening requires more than solar-resource quality

A high-resource location need not be the preferred commercial location. Resource quality, construction cost, connection timing, and energy value may favor different sites. A regional ranking requires comparable site, cost, connection and settlement evidence beyond the single-node example.

A stronger screening framework would compare resource, network access, development conditions, and price exposure on compatible geographic and temporal bases. Network mechanisms require direct evidence; a low or negative price alone does not quantify a transmission constraint or connection delay.




## 7.4 Pipeline and network records support screening rather than guaranteed supply

The analysis adds EIA generator records and ERCOT pipeline snapshots with fuel, county, expected commissioning year, and process-status fields. These permit separation of operating capacity from planned projects and changes between successive snapshots. A signed interconnection agreement is stronger evidence of process advancement than an announcement, but commissioning, final costs and actual delivery remain separate milestones. 

Installed and planned capacity must retain the source denominator. The additional material includes ERCOT-area nameplate capacity and national net-summer capacity; dividing one by the other would create a mixed-basis market share. That comparison is excluded. Texas geography is also not identical to the ERCOT balancing-authority footprint.

Official transmission-constraint and interconnection materials identify mechanisms and locations warranting further examination. They do not by themselves attribute the reference node's negative-price exposure to a particular binding constraint. A causal assessment would require interval-level constraint status, shadow prices, dispatch or curtailment records, and a supported counterfactual. The grid-constraint hypothesis therefore retains its evidence limit.

> **Limits of this chapter.** (1) The prices are real-time settlement references. (2) Site settlement rights, losses, fees and price finality require project evidence. (3) Pipeline status and persistent price differences are screening information, with causes unassigned.

# 8. Solar Value Capture: High-Output Hours May Have Lower Prices

## 8.1 The reference-node price comparison

TAYGETE2_ALL is a historical price reference. Its selection rationale, location-to-site mapping and settlement relationship are not disclosed in this edition. The 2025 TAYGETE2_ALL series contains prices for 35,038 of the expected 35,040 intervals. Matching it to the hypothetical system's generation yields a time-weighted price of $46.37/MWh and a generation-weighted price of $22.13/MWh before negative-price shutdown. The latter is approximately 48% of the former. [S06, S07]

The result demonstrates the importance of temporal alignment. Annual generation multiplied by the average market price would omit the covariance between output and price. The capture ratio is specific to the priced output profile. The observed relationship has no identified single cause.

![Figure 8-1. Hypothetical solar output and reference-node intraday prices](figures/S1_intraday_output_and_price.png)

*Source: NSRDB/PVWatts generation simulation and 2025 NP6-905-CD prices. The system design is hypothetical, and the reference node has not been established as its actual commercial settlement point. [S06, S07]*

## 8.2 Negative-price exposure and the assumed operating response

Negative prices occur in 2,189 available intervals, approximately 6.2% of priced intervals. Those intervals coincide with approximately 15.24% of potential simulated generation. The difference between time exposure and energy exposure is important: negative prices overlapping with high-output periods affect more energy than their interval count alone suggests. [S07]

The nodal route assumes zero exports whenever the reference price is below zero. Delivered energy falls to approximately 247.8 GWh, gross first-year energy revenue is approximately $6.55 million, and the delivered-energy-weighted price is $26.43/MWh. The higher weighted price applies to the remaining exports; it does not indicate additional generation. [S08]

This calculation assumes complete responsiveness to interval prices. Actual dispatch feasibility, negative-price contract provisions, and other market costs have not been verified. Economic shutdown in response to price also differs from forced curtailment, which requires separate operating or constraint evidence.

For comparison, exporting through negative prices gives modeled first-year receipts of $6.471 million and NPV of -$87.20 million in the existing rule-off sensitivity, versus $6.551 million and -$85.97 million when negative-price exports stop. This small difference is specific to the zero-incentive, pre-tax merchant case; contracts or production-linked benefits can change the preferred behavior. Receipts are obtained from the frozen generation-weighted price and output, and NPV from the existing sensitivity row. [S08]

## 8.3 Monthly outcomes separate volume from value

![Figure 8-2. Monthly simulated generation and price capture](figures/S2_monthly_energy_and_capture.png)

*Underlying table: the corresponding source table. energy_gwh is potential simulated energy; tw is the time-weighted price; gw is the generation-weighted price; gw_curt is the delivered-energy-weighted price after the assumed negative-price shutdown.*

March and August have similar simulated generation, approximately 27.5 GWh and 27.7 GWh, respectively. Their generation-weighted prices before shutdown differ substantially, at approximately $11.84/MWh and $31.11/MWh. Similar monthly energy volumes therefore do not imply similar revenue.

The monthly comparison includes simultaneous changes in weather, load, supply, and market conditions. It is a descriptive result rather than a causal attribution to any one mechanism.

## 8.4 A common three-year sample

The main comparison contains 485 officially classified resource nodes with complete prices on the shared published grid in 2023–2025. Market-wide unpublished intervals are excluded uniformly; no price is interpolated or replaced with zero. One simulated output profile is valued against all nodes. The technical appendix documents the calendar and classification rules. [E-S]

## 8.5 Reference-node representativeness

In a separate 2025 cross-section, TAYGETE2_ALL lies near the 37th percentile of absolute production-weighted prices but near the third percentile of the ratio to its own time-weighted price. The low ratio indicates unfavorable timing relative to this node's own price level; it is not a ranking as the third-percentile absolute revenue location. The 2025 distribution below and the three-year panel use different samples. The commercial settlement relationship and reason for choosing this reference node are **not disclosed in this edition**. [R-B]

![Figure 8-3. 2025 production-weighted price distribution](figures/S07_node_prices.png)

*Source: 2025 one-year resource-node cross-section [R-B]. Potential-output weighting precedes the export response. Detailed sample counts and the sample-reconciliation exhibit are in Appendix B.*

## 8.6 Conditional associations between system solar and electricity prices

The empirical study estimates hourly benchmark-price relationships over 2023–2025, controlling for system load, wind, Henry Hub gas prices, four-city daily temperature, and calendar patterns. Alternative specifications include nonlinear load, date fixed effects, and solar interactions. The reported linear solar coefficients in pooled specifications are approximately -$2.7 to -$3.8/MWh per additional GW. Where nonlinear or interaction terms enter, a coefficient on the solar level is not a constant marginal association across the sample. [E-B]

![Figure 8-4. Solar-price associations across specifications](figures/empirical/F5_solar_price_association_forest.png)

*Source: multi-year analysis, original exhibit F5 (reproduced here as Figure 8-4) and regression coefficient tables. Coefficients describe conditional associations; confidence intervals use the stated HAC or block-bootstrap methods. They are not causal effects or project revenue forecasts.*

The relationship varies substantially by year. The reported annual solar coefficients are approximately -$8.4/MWh per GW in 2023, -$3.1 in 2024, and -$1.9 in 2025. Excluding scarcity hours or limiting tail influence reduces the pooled magnitude, while the median regression is smaller again. The common sign across estimates is accompanied by substantial instability in magnitude.

Electricity prices, solar output, load, and other supply conditions share simultaneous drivers. Missing outage, available-capacity, import, and interval-constraint data limit the interpretation; the national gas benchmark and daily urban temperature average are proxies. The estimates support an observed conditional relationship within this sample, not a causal claim that one additional GW would mechanically reduce future prices by the fitted coefficient.

## 8.7 Negative-price association and predictive stability

The negative-price models use hourly mean prices and therefore answer a different question from counting individual negative 15-minute intervals. Results vary with threshold, dependent market reference, and functional form. Several Logit specifications fail or do not converge. The multi-year analysis yields no robust, specification-independent solar relationship with negative-price incidence. Absence of a robust result is not evidence that solar has no role. [E-B]

![Figure 8-5. Price patterns and negative-hour incidence](figures/empirical/F6_price_vs_solar_and_negative_hours.png)

*Source: multi-year analysis, original exhibit F6 (reproduced here as Figure 8-5). Binned patterns are descriptive. Regression interpretations require the corresponding controls, frequency, sample, and inference method.*

The reported held-out comparison is an important practical limit: a model fitted on 2023–2024 has a 2025 RMSE of approximately $66/MWh, compared with approximately $45 for an hour-of-week mean and $39 for a constant benchmark. The regressions therefore should not supply the report's future price forecast, terminal price assumption, or expected project receipts. In-sample coefficient significance does not overcome this lack of predictive performance. [E-B]

## 8.8 Node basis persists, but its cause remains unidentified

The rank correlation of node mean basis to HB_BUSAVG is approximately 0.77–0.88 across pairs of years. A descriptive variance decomposition assigns approximately 83.4% of node-year mean-basis variation to node identity, 0.4% to common year differences, and 16.2% to the remaining node-by-year component. This shows persistence in the sampled price differentials; it does not identify the economic cause of that persistence. [E-B]

![Figure 8-6. Cross-year persistence of node basis](figures/empirical/F7_node_basis_persistence.png)

*Source: multi-year analysis, original exhibit F7 (reproduced here as Figure 8-6) and basis tables. Basis is node price less the specified benchmark, not a direct measure of congestion cost. The panel uses one current classification snapshot.*

The load-zone association results add geographic context, but do not isolate congestion. Persistent differences could reflect network conditions, settlement definitions, supply composition, or other unobserved factors. Direct interval constraints, shadow prices, dispatch information, and a supported counterfactual would be required for a stronger attribution.

> **Limits of this chapter.** (1) One simulated site profile is priced at different nodes; these are not different asset valuations. (2) Output weighting precedes the negative-price response unless labeled otherwise. (3) Regressions describe associations; forecast performance is weak and network causality is unresolved.

# 9. Independent Generation Simulation: Resource, Design, and Weather-Year Effects

## 9.1 Reference location and weather coverage

The hypothetical system uses NSRDB grid cell 1142134 near the Pecos County internal point, at approximately 30.78°N, 102.71°W, about 1.08 km from that reference. The location is neither a county average nor a verified operating asset site. [S07]

Weather inputs come from the 2025 NSRDB weather extracts, comprising 105,120 five-minute UTC observations or modeled data points. Variables include irradiance, temperature, wind speed and surface albedo; data-quality flags are documented in Appendix B. the block includes 58 Pecos County cells, but does not cover the entire county.

The three-year extension adds the 2023 and 2024 extracts from the same cell, as described in Section 9.4. An actual weather year describes the conditions of that year. It does not independently establish long-run typical output or a probability distribution of generation.

## 9.2 System configuration

**Table 9-1. Hypothetical system design.**

| Parameter | Setting | Evidence class |
|---|---:|---|
| AC / DC capacity | 100 MWac / 132 MWdc | Hypothetical case scale |
| DC/AC ratio | 1.32 | Reference design |
| Tracking | Single-axis with backtracking | Reference and design assumptions |
| Ground-coverage ratio / inverter efficiency | 0.30 / 96% | Software defaults |
| Bifaciality | 0.70 | Analytical assumption |
| Initial aggregate losses | 14.0757% | Software loss stack |
| Annual degradation | 0.7%, from operating year 2 | Cash-flow reference assumption |

Generation is simulated with PVWatts; the software version is recorded in Appendix B. Degradation and subsequent export reductions are applied in the financial layer. Availability is already included in the initial loss stack and is not deducted again. These conventions prevent the same loss from being applied in multiple parts of the model. [S07, S09]

## 9.3 Generation and design sensitivities

Potential first-year generation is approximately 292.4 GWh, equivalent to an AC capacity factor of 33.38% under the assumed DC/AC ratio of 1.32, single-axis tracking and bifacial design. These design choices contribute to output per unit of inverter capacity; this is not an observed fleet benchmark. Tests using aggregate losses of 10% and 18% produce approximately 302.4 GWh and 280.7 GWh, respectively. The monofacial test produces approximately 282.3 GWh. Annual generation at the other sampled cells ranges from approximately 290.6 GWh to 299.2 GWh. That range describes the sampled spatial sample rather than the county as a whole. [S07, S10]

These results quantify the influence of selected design and loss assumptions. They are not plant-performance guarantees. Terrain, actual layout, seasonal soiling, equipment failures, and construction quality have not been constrained by site-specific evidence. AC capacity factors and DC energy yields require their respective denominators and are not interchangeable.

## 9.4 Three weather years improve comparison without establishing long-run uncertainty

The extension adds 2023 and 2024 weather from the same NSRDB cell and retains the 2025 design. Annual AC generation is approximately 282.3, 292.1, and 292.4 GWh, a spread of about 3.6%. The comparison shows observed weather-year variation within this simulation; it does not estimate the long-run output distribution, a P50, or a P90. [E-S]

Calendar handling and leap-day approximation are documented in Appendix B.

> **Limits of this chapter.** (1) Output is simulated for a reference cell and assumed design. (2) Three weather years do not establish P50/P90 output. (3) Fill flags, leap-day approximation, time mapping and performance uncertainties are detailed in Appendix B.

# 10. Financial Scenarios: Cash-Flow Definitions Precede Return Interpretation

## 10.1 Timing, currency basis, and model scope

The model assumes all capital expenditure is paid at the end of 2026, followed by 30 operating years from 2027 to 2056. Real values are expressed in 2025 dollars, and NPV is measured at the 2026 valuation point. ATB capital and fixed operating costs, originally in 2023 dollars, are converted using CPI-U, with a factor of approximately 1.0566. [S08, S09]

The analysis is pre-tax and unlevered. Income taxes, tax incentives, depreciation tax shields, debt proceeds, interest, and principal repayments are excluded. These are scope choices rather than findings that such items are immaterial to an actual project. The 4.27% real discount rate is a scenario parameter; 6% and 8% comparisons are also reported. It is not a verified project WACC.

The 4.27% analytical real rate is obtained from ATB reference nominal debt cost 6.5%, equity return 8.0% and debt fraction 0.7457, without a tax shield: [(0.065 × 0.7457 + 0.080 × 0.2543) + 1] / 1.025 - 1 ≈ 4.27%. The input register identifies workbook rows 52–68. It is a scenario discount convention, not a verified project WACC or investor hurdle. The 6% and 8% comparisons remain visible. [S09]

## 10.2 Cost coverage and unquantified items

Base capital expenditure is approximately $1,436.75/kWac, or $143.67 million, using ATB OCC plus GCC. Fixed O&M is approximately $24.49/kWac-year. Variable O&M follows the ATB value of zero; this does not imply that other cost categories are zero. [S08]

Additional assumptions include $35/kWac of replacement expenditure in operating year 16 and $30/kWac of net decommissioning expenditure in year 30. Replacement costs may overlap with component-failure provisions in FOM. A zero-replacement sensitivity is available, but it does not certify the elimination of every potential overlap. Site-specific land, tax, insurance, network-upgrade, and market-service costs have not been separately established. [S09]

The ±20% CAPEX and ±30% FOM sensitivities are selected analytical stresses. They are not verified bounds on unknown costs and do not demonstrate that all omitted categories are covered.

## 10.3 Two distinct revenue mechanisms

The nodal route uses the 2025 reference-price and output shapes, holds the base price profile constant in real terms over subsequent years, and adjusts output for degradation. Exports during negative-price intervals are set to zero. The price path is a scenario convention, not a forecast; the hypothetical plant's impact on market prices is not modeled.

The fixed-price route has no observed contract. Its 15.24% unpaid-energy deduction is an analytical allocation of payment risk, not a documented clause. A negative-price exclusion clause could create unpaid output, but no such agreement is assumed to have been obtained. The fixed-price route assumes a flat nominal price of $40/MWh and an unpaid reduction equal to 15.24% of potential energy. The reduction is anchored to the negative-price energy share for analytical purposes. It is neither an observed physical curtailment rate nor an actual contract provision. With assumed inflation, a flat nominal price declines in real purchasing power; it must not be interpreted as a flat real price.

**Table 10-0. Scenario settings — price, cost and operating assumptions.**

| Scenario | Price rule / level | Unpaid energy / response | CAPEX $/kWac | FOM $/kWac-year | Initial losses | Degradation /yr | Inflation /yr |
|---|---|---|---|---|---|---|---|
| node_base | 2025 reference profile; +0.0%/yr real | Stop exports below $0 | 1,436.7 | 24.49 | 14.0757% | 0.7% | 2.5% |
| node_downside | 2025 reference profile; -1.5%/yr real | Stop exports below $0 | 1,504.1 | 25.05 | 18% | 1.0% | 2.5% |
| node_upside | 2025 reference profile; +0.5%/yr real | Stop exports below $0 | 1,346.9 | 23.77 | 10% | 0.5% | 2.5% |
| fixed_base | $40/MWh nominal flat | 15.24% | 1,436.7 | 24.49 | 14.0757% | 0.7% | 2.5% |
| fixed_downside | $32/MWh nominal flat | 30.48% | 1,504.1 | 25.05 | 18% | 1.0% | 2.5% |
| fixed_upside | $48/MWh nominal flat | 15.24% | 1,346.9 | 23.77 | 10% | 0.5% | 2.5% |

*Sources: scenario input register and scenario outputs [S08, S09]. CAPEX and FOM are in real 2025 dollars. Downside/base/upside costs follow ATB Conservative/Moderate/Advanced technology cases, respectively; the labels describe bundled assumptions, not probabilities. Replacement is $35/kWac in operating year 16 and net decommissioning $30/kWac in year 30 across all cases. Nodal delivery responds to each interval price; its negative-price output share is endogenous. Fixed-route shares are imposed assumptions.*

The 2.5% inflation input follows the ATB workbook's financial-assumption row 52. For fixed_base, 247.8195 GWh × $40/MWh gives $9.9128 million nominal receipts in 2027; dividing by 1.025 squared gives $9.4351 million in 2025 dollars. The two-year deflation follows the model's stated calendar convention.

## 10.4 Scenario results

**Table 10-1. Six scenarios priced at reference node TAYGETE2_ALL or the fixed contract setting.**

| Scenario | First-year delivered GWh | First-year real revenue, $m | NPV at 4.27% / 6% / 8%, $m | Real LCOE at 4.27%, $/MWh | Single real IRR |
|---|---:|---:|---|---:|---|
| node_base | 247.8 | 6.55 | -86.0 / -95.3 / -103.3 | 48.9 | Not a single rate: multiple roots |
| node_downside | 237.7 | 6.27 | -114.6 / -118.9 / -122.9 | 54.8 | Not a single rate: multiple roots |
| node_upside | 256.6 | 6.80 | -63.3 / -75.7 / -86.2 | 43.6 | -0.42% |
| fixed_base | 247.8 | 9.44 | -73.7 / -82.8 / -91.0 | 48.9 | Not a single rate: multiple roots |
| fixed_downside | 195.2 | 5.94 | -125.4 / -127.5 / -129.7 | 66.7 | Single rate not certified |
| fixed_upside | 256.3 | 11.71 | -33.5 / -47.5 / -60.0 | 43.7 | Not a single rate: multiple roots |

*Source: the corresponding source table. Amounts reflect the declared scenario scope. Upside and downside cases are parameter combinations, not probability bounds.*

![Figure 10-1. Scenario economics and controlled IRR reporting](figures/S3_scenario_outcomes.png)

*Source: the corresponding source table, six hypothetical scenario settings. NPV and IRR retain the stated unlevered financial assumptions; undefined IRR is not zero. These results are not verified asset returns. [S08, S10]*

## 10.5 Operating receipts and capital recovery answer different questions

![Figure 10-2. Annual real cash flows](figures/S4_annual_cash_flows.png)

*Underlying table: the corresponding source table. Initial capital expenditure, operating flows, replacement, and decommissioning are separately recognized.*

In both base cases, revenue exceeds modeled FOM in every operating year. Coverage of omitted operating costs remains unverified. Cumulative undiscounted real cash flow also remains negative in both base cases. The modeled revenue therefore fails to recover the defined capital outlay and subsequent costs over the operating period.

The result is specific to the tested revenue and cost definitions. Actual procurement, contracts, incentives, and financing may produce different outcomes. The conditional shortfall applies to the tested cash-flow definitions; it is not a market-wide finding about solar development.

## 10.6 LCOE, contract duration and IRR

Base LCOE is $48.85/MWh using delivered energy and 4.27% real discounting. Using potential generation instead gives $41.41/MWh because the denominator includes energy not sold. Both measures use the same real cost stream; a flat nominal contract needs a separate inflation adjustment. [S08]

In fixed_upside, first-year realized price is $45.69/MWh and real LCOE is $43.69/MWh, yet NPV is -$33.45 million. The contract price stays flat in nominal terms, so its real value falls with 2.5% annual inflation. A first-year price above a constant-real levelized cost therefore does not ensure lifetime capital recovery.

All six scenarios have negative NPV at the modeled positive discount rates. A single IRR is not a reliable comparison for cases with multiple roots: node_base has two negative numerical roots, approximately -96.52% and -2.53%; fixed_upside has roots near -86.48% and +1.41%. Neither case is summarized by selecting one preferred root. The node_upside case has a certified unique numerical IRR of about -0.42%; the fixed_downside case has no certified unique rate. NPV and cash flows provide the decision measure. Technical root qualifications are in Appendix B. [S10]

## 10.7 Benchmark scope and tax context remain separate from project cash flows

The expanded cost crosswalk distinguishes modeled national overnight cost from observed commissioned-project cost. Berkeley Lab's utility-scale publication reports a 2024 commissioned-project cost reference of approximately $1.22/Wdc or $1.61/Wac. Its coverage and sample differ from PVSCM, and the publications use different deflation conventions. A shared real-dollar label does not make the figures fully harmonized. Attributing the difference to scope requires a component-level reconciliation. 

PVSCM's land-lease and operating-cost treatment also differs from a complete site budget. Benchmark O&M or replacement allowances should be reconciled before combining them with scenario cash-flow lines. Public reference costs do not verify the hypothetical site's land, insurance, property tax, market-service, network-upgrade, or decommissioning obligations.

IRS Notice 2025-42 addresses construction-start rules for relevant wind and solar credit provisions; Notice 2026-15 supplies interim guidance relating to restricted foreign entities. Eligibility depends on the applicable statutory and project facts. The scenario assigns neither a tax credit nor a tax-credit financing benefit, and this report makes no project-specific eligibility determination. The rules register is a route to subsequent due diligence, rather than a new tax input. [P02, P03]

## 10.7a Illustrative credit sensitivity

A simplified cash-credit example assumes a receipt equal to 30% of total scenario CAPEX at the end of the first operating year. At 4.27%, its present value is $41.34 million. Holding the pre-tax operating cash flows constant, node_base NPV becomes -$44.63 million and fixed_base NPV -$32.40 million; the flat nominal fixed-route break-even price falls from $65.97/MWh to about $51.41/MWh. [S08]

This is **illustrative only; no eligibility determination**. It is a cash-receipt sensitivity, not an ITC/PTC tax model: total scenario CAPEX is assumed to be the qualifying base solely for this example. Payment timing, eligible basis, tax capacity, transfer discounts, recapture, basis adjustments, depreciation and tax-equity costs are excluded. The 30% assumption is not a statement of the statutory rate available to this system. No credit benefit is added to the six original scenarios.

## 10.8 Historical price-year substitution changes the sign of modeled NPV

The extended empirical scenario preserves the pre-tax unlevered cost structure and the 4.27% real discount rate. Under those assumptions, discounted project value is an affine function of first-year modeled receipts: approximately NPV = 15.47 × receipts − $187.3 million. The revenue threshold is about $12.1 million. The multiplier incorporates the degradation and discounting assumptions. The $187.3m intercept comprises initial CAPEX and the present value of modeled fixed operating costs, replacement and decommissioning; this is a cash-flow identity, not a market valuation multiple. [E-A, E-C]

**Table 10-2. Same-year comparison: median across 485 resource nodes.**

| Same-year price and weather pairing, common calendar | Median first-year receipts, $m | Median lifetime NPV, $m | Share of 485 sampled nodes with positive NPV |
|---|---:|---:|---:|
| 2023 | 18.56 | +99.8 | 100% |
| 2024 | 6.83 | -81.6 | 2.68% |
| 2025 | 6.85 | -81.3 | 0.41% |

*Source: multi-year analysis, weather-price matrix summary. All rows use the hypothetical Pecos profile, common calendar, negative-price export rule, and identical finance assumptions. Medians describe each distribution separately; no actual asset portfolio is valued.*

Positive cases are therefore not exclusive to 2023. What distinguishes 2023 is their prevalence across the sample and their dependence on that year's high-price opportunities. The reference node is negative in 2024 and 2025; the sample contains a small positive tail. Neither statement should be substituted for the other.

The original six scenarios in Section 10.4 remain 2025-based cost and commercial stress settings. They are not replaced by the three historical-year experiments. Taxes, financing, actual commercial mapping and complete project cost remain absent from both sets.

> **Limits of this chapter.** (1) Returns are pre-tax and unlevered. (2) Taxes, credit eligibility, financing, land, insurance, network upgrades and several market-service costs remain unverified. (3) Flat nominal contracts lose real value over time. Multiple cash-flow sign changes make a single IRR ambiguous.

# 11. Sensitivity and Break-Even Analysis: Turning Results into Testable Conditions

## 11.1 One-way sensitivities measure effects within chosen ranges

![Figure 11-1. One-way sensitivities over specified parameter ranges](figures/S5_one_way_sensitivity.png)

*Underlying table: the corresponding source table, with 49 unique identifiers. Perturbations are analytical ranges, not probabilities or certified limits on unknown costs.*

Around the nodal base case, a ±20% CAPEX change moves NPV by approximately ±$28.7 million, while a ±20% price-level change moves it by approximately ±$20.3 million. In the fixed-price route, changing the price by ±$8/MWh moves NPV by approximately ±$22.7 million. The tested unpaid-energy reduction range produces an NPV change of approximately ±$20.4 million. [S08]

These comparisons demonstrate that both construction outlays and commercial realization materially affect the tested cases. The comparisons provide no universal ranking of return drivers. Wider perturbations generally generate larger effects, and some inputs are correlated. Total-CAPEX sensitivity is not an isolated module-price sensitivity.

## 11.2 Physical performance and commercial realization interact

Losses, bifacial design, and degradation change potential generation. Prices, negative-price responsiveness, and unpaid-energy rules determine the value assigned to that generation. Incremental physical output need not produce proportional incremental revenue if it occurs in lower-value intervals.

The existing spatial financial sensitivity primarily scales the base output curve by annual-energy ratios. It does not independently simulate capture prices for every location. Its financial range therefore describes an output-scaling sensitivity, not a fully spatially resolved revenue comparison. [S10]

## 11.3 Break-even conditions

**Table 11-1. Break-even conditions under base assumptions.**

| All other base assumptions held constant | 4.27% real discount rate | 6% | 8% |
|---|---:|---:|---:|
| Flat nominal fixed price, $/MWh | 66.0 | 74.3 | 84.6 |
| Break-even CAPEX, nodal route, $/kWac | 577 | 484 | 403 |
| Multiplier on the nodal price profile | 1.85 | 2.13 | 2.49 |
| Break-even CAPEX at a fixed $40/MWh, $/kWac | 699 | 609 | 527 |

*Source: the corresponding source table. Fixed-price thresholds retain the base unpaid-energy reduction, nominal-price convention, costs, and degradation. They are not market PPA quotations. Nodal multipliers scale the price profile and are not forecasts.*

The nodal break-even capital cost of $577/kWac is about 40% of the base $1,437/kWac, a reduction of roughly 60%. The thresholds translate a general question about economic viability into conditions that can be checked. Relevant questions include the achievable price and paid-volume rule, the construction cost consistent with that revenue, and the effect of eligible incentives or alternative risk allocation on cash flows.

A modeled break-even price requires a willing buyer before it becomes a contracting opportunity. Similarly, a break-even capital budget is not evidence that the system can be built for that amount. The thresholds identify the evidence that would change a commercial assessment.

## 11.4 Two-way sensitivities

![Figure 11-2. Two-way cost and price break-even analysis](figures/S6_two_way_breakeven.png)

*Underlying table: the corresponding source table. Cash flows are recomputed for each grid cell. A fixed-price grid and a nodal-price scaling grid represent different revenue mechanisms.*

Lower costs reduce the required selling price but may not fully offset weak value capture. Around base CAPEX, the existing fixed-price grid crosses zero NPV between approximately $65/MWh and $70/MWh on a flat nominal basis. When costs, prices, and coverage change jointly, the case must be recalculated rather than inferred by adding separate sensitivity effects.




## 11.5 Remaining robustness questions

The central robustness question is whether capital recovery survives a different price year, removal of the highest-price intervals and alternative output-price pairing. Sections 11.6–11.9 answer these as historical stress tests, with no probability assigned to their recurrence.

## 11.6 Crossed weather and price years reveal the source of model sensitivity

The 3×3 experiment holds the site design constant and pairs each of three weather profiles with each of three historical price shapes. Diagonal cells are same-year pairings of simulated output and observed prices; off-diagonal cells are counterfactual combinations. Calendar mapping and common exclusions are held fixed, using the fixed UTC-6 calendar key and disclosed DST correspondence described in Section 8.4. [E-A]

![Figure 11-3. Weather-year and price-year scenario matrix](figures/empirical/F2_weather_by_price_matrix.png)

*Source: multi-year analysis, original exhibit F2 (reproduced here as Figure 11-3) and 3×3 tables. NPV uses 4.27% real discounting and a 30-year repetition of first-year price conditions. The common-calendar matrix is not a probability distribution or a price forecast.*

Under 2023 prices, changing the weather profile leaves median NPV positive, although it changes its magnitude. Under 2024–2025 prices, the median remains negative across all three weather profiles. Weather volume alone therefore does not explain the sign change. More energy can coincide with a lower value when its timing matches high prices less well.

## 11.7 Price levels and output-price matching explain most of the change

The large post-2023 deterioration is predominantly associated with the price year, with a much smaller weather contribution. The separate price-and-volume accounting below shows substantial contributions from both lower overall prices and weaker output-price matching. These are two distinct accounting methods; the price/volume table is not a nested breakdown of the weather/price method. [E-A]

A separate log-mean Divisia decomposition expresses potential revenue through volume, the overall price level, and the output-price matching ratio, with the change in the negative-price export-rule adjustment reported separately. Its component medians are:

**Table 11-2. Volume, price and timing contributions to NPV change.**

| Transition | Volume, $m | Overall price level, $m | Timing match, $m | Export-rule adjustment, $m |
|---|---:|---:|---:|---:|
| 2023 to 2024 | +5.6 | -110.1 | -84.1 | +0.3 |
| 2023 to 2025 | +6.3 | -77.3 | -111.5 | +0.9 |
| 2024 to 2025 | +0.4 | +18.9 | -14.8 | +0.6 |

*Source: multi-year analysis, LMDI component tables, expressed through the finance link in NPV dollars. These are a second decomposition of the total change, not subcomponents of the Shapley price contribution in Appendix B. Node-level sums hold under the stated construction; component medians need not add.*


![Figure 11-4. Components of the year-to-year change](figures/Client_LMDI_decomposition.png)

*Source: existing component table [E-A]. LMDI separates volume, overall price, timing match and the export rule. Values are medians across nodes and need not add to the median total. The weather/price Shapley allocation and original exhibit are in Appendix B.*

Between 2024 and 2025, the overall-price component improves while output-price matching deteriorates. Capacity growth, load changes and congestion remain possible explanations, not identified causes.

The 2023 context in these results is a high-price-tail environment, not simply a higher uniform electricity price: the top 1% of price intervals account for 54.7% of median node receipts, compared with 13.6% in 2024 and 4.9% in 2025. Calendar-month and time-of-day detail is tabulated in the accompanying 2023 price-context table. An externally sourced event attribution is **not disclosed in this edition**; no particular outage, heat event or binding constraint is assigned as the cause. [E-C]

In the system benchmark hourly series, 61 hours in 2023 average at least $1,000/MWh: 39 occur in August and 12 in September, with the rest in June, July and October. These hours fall between hour indices 12 and 20 on a fixed UTC−6 clock; the largest hourly average is about $5,073/MWh. This describes the benchmark, not the reference node or the separate 15-minute tail statistic. [E-B]
## 11.8 Tail dependence qualifies the positive historical scenario

In the empirical sample, the top 1% of 2023 price intervals generate 54.7% of the median node's modeled receipts. The corresponding shares are much smaller in 2024 and 2025, approximately 13.6% and 4.9%. The concentration statistic is specific to the output weights, price ranking, export rule, and sample. [E-C]

![Figure 11-5. Revenue concentration and tail stresses](figures/empirical/F4_tail_concentration_and_stress.png)

*Source: multi-year analysis, original exhibit F4 (reproduced here as Figure 11-5) and tail tables. The figure's reference-node results are distinct from cross-node medians reported in the text. Tail deletion and caps are stress scenarios beside the original prices, not corrections to history.*

Removing receipts from the top 1% of intervals turns modeled NPV negative for 99.4% of the sample under 2023 conditions. The reported median stress-case NPV is approximately -$56.6 million. A 99th-percentile price cap produces a median around -$10.6 million; excluding dates containing an interval at or above $1,000/MWh produces a median around -$82.5 million. Those settings retain costs while deliberately reducing receipts and do not represent forecasts of attainable annual revenue.

The best-hours stress statistic gives a median of about 23 hours. It measures the narrow revenue buffer in this constructed case, rather than identifying 23 hours that a developer can know in advance or guarantee will recur. The commercial question is whether access to rare high-price periods is durable and contractually used; the present evidence is insufficient to answer it.

The roughly 23-hour figure is an equivalent duration of the highest-revenue 15-minute intervals, sorted from highest modeled receipts downward. In the median positive 2023 node case, removing the modeled receipts from approximately that many accumulated intervals exhausts the NPV surplus. These intervals need not be consecutive, and the statistic is not a schedule of hours known in advance. [E-C]

## 11.9 Resampling and mixture scenarios have limited meanings

Within-year block resampling preserves some local dependence but conditions on the historical year's market environment. Reported 2023 NPV intervals change materially with block length, illustrating uncertainty within that year. They do not estimate how often a 2023-like regime will occur. In particular, the fraction of positive resampled draws is not a probability that a future project will be profitable. [E-C]

![Figure 11-6. Within-year resampling and a three-year mixture setting](figures/empirical/F8_bootstrap_and_mixture_scenario.png)

*Source: multi-year analysis, original exhibit F8 (reproduced here as Figure 11-6). Resampling is conditional on a particular year. The mixture is an equal-weight analytical setting rather than an estimated probability-weighted expectation.*

An equal-weight average of each node's first-year receipts across the three years gives a median NPV of approximately -$21.4 million, with 12.2% of sampled nodes positive. Equal weights are a chosen stress setting. With only three observed years, neither those weights nor the resulting positive share establish a long-run return distribution.

> **Limits of this chapter.** (1) Perturbation ranges are analyst-selected, with some correlated inputs. (2) Decomposition components are accounting contributions; component medians need not add. (3) Tail deletions, resampling and equal-year mixtures are stresses, not event probabilities or price forecasts.

# 12. Five Research Hypotheses: Evidence, Alternative Explanations, and Revision Conditions

## 12.1 Equipment-price hypothesis — Mixed

**Working hypothesis:** Lower module prices improve project economics, but their effect may be smaller than financing, interconnection delay, curtailment or realized power prices.

The original proposition is that lower module prices improve economics, but may have a smaller effect than financing, interconnection delay, curtailment, or realized power prices. Manufacturing evidence supports price pressure, and the scenario sensitivities establish that total CAPEX affects NPV. The direct bridge from delivered module prices to project capital expenditure is still absent. The full comparative proposition has therefore not been established.

Alternative explanations include changes in technology, non-module scope, trade treatment, and delivery terms. A stronger conclusion requires the component mapping described in Appendix C and comparisons using consistent, justified perturbations. National total-cost variation and isolated component-price effects have different scopes.

**What this means for you.** Use component-specific delivered quotes before ranking cost savings against other risks.

## 12.2 Demand-value hypothesis — Not testable

**Working hypothesis:** Data-center load growth does not automatically raise an individual solar project's realized price or bankability.

The proposition is that data-center load growth does not automatically raise an individual solar project's realized price or bankability. National demand scenarios can coexist with low historical solar capture prices, but that coexistence is not a causal test of demand growth at a specific node. Asset-level contracts, location, and credit conditions remain absent.

Alternative explanations include non-data-center load, network conditions, changes in other supply, and fixed-price contracts that separate receipts from spot-market outcomes. The three-year capture-price analysis strengthens the historical market context, while GAP-08 still limits any demand-specific conclusion. An actual bankability conclusion would still require project evidence and is outside the current scenario mandate.

**What this means for you.** Qualify the buyer, settlement location and payment shape; a load request alone is not a price uplift.

## 12.3 Value-chain hypothesis — Mixed

**Working hypothesis:** Manufacturing scale and lower upstream prices can coexist with weak value capture along the solar value chain.

MIIT price observations, LONGi segment margins, and deployment scale are consistent with pressure along parts of the value chain. They do not identify overcapacity as a cause or quantify downstream U.S. cost transmission. Inventory, technology substitution, utilization, and accounting scope remain alternative explanations.

The company panel and customs series broaden the evidence, while the empirical revenue analysis shows that price shape can materially alter value capture. None of these additions establishes observed pass-through from factory prices to complete project costs. Comparable production, inventory, prices and delivered costs described in Appendix C could change the assessment. Individual-company disclosures describe the reported businesses, not industry-average profitability.

**What this means for you.** Assess company-specific cash generation and product economics alongside manufacturing volumes.

## 12.4 Grid-constraint hypothesis — Not testable

**Working hypothesis:** Grid constraints can affect the deliverable value of solar output.

System timing differences and negative-price exposure motivate research into delivery and price risks. They do not directly measure the cost of network constraints or the marginal value of adding the hypothetical system. Weather, fleet composition, and other market conditions can also explain the observations.

A revised conclusion requires direct constraint or curtailment evidence, interconnection timing and costs, or a supported counterfactual. General descriptions of network mechanisms do not close this evidence requirement. The persistent node-basis findings add descriptive support for studying location, but do not supply this causal evidence. GAP-09 remains the relevant research route.

**What this means for you.** Investigate actual constraints and settlement exposure before attributing a node price difference to congestion.

## 12.5 Storage hypothesis — Not testable

**Working hypothesis:** Storage can improve solar economics by changing delivery timing, subject to its incremental costs and operating limits.

Storage may change delivery timing, but the present analysis contains no storage power/energy configuration, efficiency, degradation, dispatch, or cost model. A timing mismatch is not proof of positive storage NPV.

Efficiency losses, cycling degradation, narrowing arbitrage spreads, and incremental costs may offset timing benefits. Storage economics remain a conditional extension, separate from completion of the solar-only report.




**What this means for you.** Treat storage as a separate incremental investment case; a timing mismatch alone supplies no storage return.

## 12.6 Controlled update after the empirical extension

**Table 12-1. Controlled conclusions and revision evidence.**

| Hypothesis | Controlled conclusion | Additional support | Alternative explanation and revision evidence |
|---|---|---|---|
| Lower module prices improve project economics, but their effect may be smaller than financing, interconnection delay, curtailment or realized power prices. | Mixed | Component model quantifies a conditional cost mechanism; customs data adds sourcing context | Trade treatment, specifications and non-module costs can offset savings; matched procurement and complete budgets remain necessary |
| Data-center load growth does not automatically raise an individual solar project's realized price or bankability. | Not testable as a causal or asset-level proposition | Dated large-load categories and hourly market associations improve context | Load requests may not connect or may procure a different product; actual timed local load and procurement are absent |
| Manufacturing scale and lower upstream prices can coexist with weak value capture along the solar value chain. | Mixed | Expanded company panel and model-based revenue decompositions show different outcomes across stages | Technology, incentives, financing, working capital and market price shape differ; matched segment and procurement evidence is needed |
| Grid constraints can affect the deliverable value of solar output. | Not testable causally | Node basis persists in the corrected panel | Settlement, supply and network factors are not separated; interval constraints, dispatch and a credible counterfactual remain necessary |
| Storage can improve solar economics by changing delivery timing, subject to its incremental costs and operating limits. | Not testable; deferred | Negative-price exposure and tail dependence motivate a research question | Storage costs, charging, dispatch, degradation and contract rights can reverse benefits; no independent storage case is modeled |

Statistical association, accounting contribution, and investment relevance remain distinct. The empirical findings support conditional screening, with the asset-level boundaries in Box 1.

> **Limits of this chapter.** (1) Controlled conclusions apply only to their stated evidence. (2) Comparative driver rankings, causal demand or congestion claims and storage economics remain untested. (3) The additional evidence required is listed in Appendix C.

# 13. Commercial Applications: Procurement, Development, and Market Screening

## 13.1 Equipment suppliers: demonstrate value within the customer's system

A commercially useful procurement assessment has three stages: compare delivered prices for comparable specifications; assess compatibility, performance, and reliability; and evaluate the customer's connection and revenue conditions. Equipment-price reductions directly affect only part of that assessment and do not guarantee a construction decision.

Sales and strategy materials should therefore connect product attributes with customer requirements. The present evidence has not measured service premiums or established supplier winners. Those conclusions require comparable product, delivery, and customer evidence.

For the component-price example, an 8.9% capital saving closes about 14.9% of the reference gap. A supplier should therefore show the delivered project saving, warranty and system consequences alongside the module quote. Covered import rules may limit transmission; the $0.38/W versus $0.29/Wdc comparison remains conditional on compatible product and denominator definitions. [R-A, P01]

## 13.2 Developers: assess generation and payment rules together

Identical annual generation can produce different receipts when settlement timing, location, or contract rules change. Development screening should identify the site, system design, settlement point, and commercial arrangement before assigning asset-level meaning to a result.

The current thresholds can support internal questions: whether a quotation change is large enough to alter the scenario; whether a nominal contract price is consistent with real costs; and how unpaid-energy provisions affect capital recovery. They do not constitute an available financing solution or a completed project appraisal.

Under the reference assumptions, the fixed route needs about $66/MWh flat nominal, while the nodal route requires CAPEX near $577/kWac or a price-profile multiplier near 1.85. These are alternative break-even tests. The -$81.3m 2025 median-node NPV indicates that switching to the median price reference alone leaves a sizeable modeled gap. [S08, E-A]

## 13.3 Research teams: test each link in the market thesis

Lower equipment costs, growing electricity demand, and stronger project returns are separate propositions. Examining each link identifies which additional evidence could change the conclusion and reduces repeated collection of general background material.

The present draft contributes manufacturing observations, regional operating context, and economic thresholds. The most useful extensions concern transmission into delivered costs, the representativeness of market outcomes, and customer procurement needs.

## 13.4 Electricity buyers: compare the product and the obligations

Energy, environmental attributes, scheduled delivery, and continuous supply are distinct procurement objectives. Their quantity, location, and shortfall responsibilities differ. Two prices expressed per MWh may therefore refer to materially different products.

A contract-reading framework should identify those responsibilities before comparing prices. Customer-specific procurement recommendations require evidence about the actual product and obligation, which has not yet been assembled.




## 13.5 A decision matrix for using the expanded evidence

**Table 13-1. Commercial decisions and evidence requirements.**

| Reader decision | Evidence available now | Required commercial qualification | What this report shows |
|---|---|---|---|
| Test whether a lower module quote is material | PV-only component shares and conditional transmission factor | Match specifications, tax basis, delivery terms, and non-module scope | 8.9% CAPEX example closes 14.9% of reference NPV gap |
| Challenge a claim based on average power prices | Common-output nodal capture-price distribution | Match actual settlement point, hourly output, and payment rules | 2025 reference capture ratio about 48%, before export response |
| Qualify a large-load prospect | Dated process categories and conditional Batch Zero results | Verify customer identity, connection milestones, operating date, and procurement status | 238.6 GW requested versus about 5.8 GW observed energized; different measures |
| Compare solar with broader supply products | Public self-supply capacity mix and service distinctions | Evaluate reliability and dispatch on a common service basis; do not compare energy-only LCOE with firm supply cost | Self-supply power capacity: about 83% gas, 11% solar |
| Assess a scenario's capital recovery conditions | Reviewed break-even thresholds and broader price substitution | Replace assumptions only with sourced inputs; preserve excluded taxes, debt, and cost items until modeled | About $66/MWh flat nominal, or $577/kWac on the nodal route |

The practical product of this research is a set of screening questions and transparent conditional calculations. It is suitable for initial market development, commercial hypothesis testing, and planning subsequent diligence. Customer acquisition forecasts, investment recommendations, and guaranteed procurement savings remain outside the evidence supported by the report.

> **Limits of this chapter.** (1) The screening thresholds are conditional and provide questions for diligence. (2) Actual orders, settlement terms, buyer credit, all-in budgets and contracting rights are still needed before an investment or procurement decision. (3) The additional evidence required is listed in Appendix C.

# 14. Outlook and Updates: Conditional Scenarios with Identifiable Evidence

## 14.1 What the present evidence permits

The evidence supports an analytical monitoring framework, but not an independent market-size or electricity-price forecast. Manufacturing conditions, load realization, network development, and procurement can evolve at different speeds and require separate indicators. Unsupported growth rates are not inserted into future-year tables.

## 14.2 Conditional market developments

If load materializes faster than network expansion, location differentials, connection timing, and reliable delivery become important questions for further analysis. If demand and network development advance together, procurement, competing supply, and contract transmission become central. If announced demand materializes more slowly, customer pipelines and equipment-demand expectations require reassessment.

These are logical scenarios awaiting quantification. They carry no assigned probabilities and do not substitute for a forecast model.

For solar receipts, the first path is ambiguous: scarcity can support market prices while connection delays and delivery restrictions impair realization. Coordinated load and network expansion can improve market access, but competing supply may absorb the demand increase. Slower load realization weakens the demand-side thesis, holding supply and other conditions constant. None of these paths has a quantified net price effect here.

## 14.3 Indicators and revision triggers

**Table 14-1. Indicators that would change the assessment.**

| Area | Proposed indicators | Analysis potentially affected |
|---|---|---|
| Manufacturing supply | Comparable output, effective capacity, inventory, specification-consistent prices | Competitive conditions and procurement interpretation |
| Regional demand | Actual load, approved connections, project-status changes | Regional demand assessment and customer screening |
| Supply and networks | Commissioning, constraints, connection timing, network progress | Location and delivery risks |
| Electricity value | Capture prices, negative-price energy, nodal differentials | Revenue assumptions and scenario recalculation |
| Costs and contracts | Component costs, delivered prices, quantity and payment rules | CAPEX transmission and break-even conditions |

The framework is a proposed update process, not an already operating monitoring system or an automated-service commitment.




## 14.4 Interpretation of the extended investment evidence

Three distinctions govern use of the empirical results. First, a historically positive modeled outcome is conditional on that price pattern, not an expected return. Second, broad negative outcomes under two historical price years do not prove that every solar project is uneconomic. Third, persistent node price differences do not identify their cause. Each stronger claim would require additional evidence beyond the present scenario and association framework.

The most useful investment question is whether a proposed commercial structure can support the required receipts at a complete and substantiated cost. The present study supplies conditional thresholds and identifies exposure to a concentrated price pattern. Future prices, contracting rights, tax eligibility, financing terms and collection probabilities remain unresolved.

For readers assessing entry into the market, the immediate implication is to qualify the revenue product as carefully as the equipment price: energy-only sales, fixed-price contracts, shape guarantees, scarcity participation and firm supply allocate different risks. A contract can transfer exposure rather than eliminate its cost. No unsupported ranking of these routes is made.

> **Limits of this chapter.** (1) The outlook uses qualitative conditional paths without assigned probabilities. (2) Faster load growth may support prices yet worsen access and delivery risks; the net project effect depends on location, competing supply and contract terms. (3) The additional evidence required is listed in Appendix C.

# Appendix A. Sources, Data, and Evidence Locations

Bracketed identifiers identify source families, not additional independent studies. Research results [S08, S10, E-A, E-B, E-C] are calculations on the listed official inputs; their computation files have no official publication URL. Dates below are publication dates or statistical periods as recorded in the source catalog. The accompanying Client-Source-Index table preserves the full URL, original file location and catalog identifier; source catalogs contain acquisition details and hashes.

**S01.** MIIT-2024-FUJIAN-REPUBLICATION (2024): [official source](https://gxt.fujian.gov.cn/zwgk/gysj/xysj/xxcy/202504/t20250418_6902400.htm)

**S02.** LONGI-2024-ANNUAL-REPORT (FY2024): [official source](https://static.longi.com/LON_Gi_annual_report_2024_0026f3477f.pdf)

**S03.** IRENA-2026-CAPACITY-STATS (2016-2025): [official source](https://www.irena.org/Publications/2026/Mar/Renewable-capacity-statistics-2026)

**S04.** LBNL-2025-UPDATE-DOE (2030 modeled; publication June2026): [official source](https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update)

**S05.** ERCOT-LOAD (2025): [official source](https://www.ercot.com/gridinfo/load/load_hist); ERCOT-SOLAR (2025): [official source](https://www.ercot.com/gridinfo/generation)

**S06.** NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD)

**S07.** NSRDB V4 5-minute block extract, gid 1142134, 2025 (2025): [official source](https://developer.nrel.gov/docs/solar/nsrdb/)

**S08.** Scenario input register (finance parameters, 2026-10-07; local method, no official publication URL); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**S09.** NLR-2025-ATB (2026 projection): [official source](https://atb.nlr.gov/electricity/2025/data)

**S10.** Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**R-A.** U.S. Utility-Scale Solar, 2025 Data Update (slides PDF) (2025-10): [official source](https://emp.lbl.gov/sites/default/files/2025-10/Utility%20Scale%20Solar%202025%20Edition%20Slides.pdf); Solar Photovoltaic System Cost Benchmarks (web page) (2026-09-02 (page modified)): [official source](https://www.energy.gov/eere/solar/solar-photovoltaic-system-cost-benchmarks); Q1-2024 Solar Cost Benchmarks (dataset page) (2025-12-01 (submitted)): [official source](https://data.nlr.gov/submissions/307); 2025Q1 PV System Cost Benchmark Model (zip: PVSCM 2025.xlsm, UPV/CPV/RPV 2025Q1.txt, description PDF, ReadMe) (2025-11-13 (Program.Date in parameter file)): [official source](https://data.nlr.gov/system/files/304/1767739491-2025Q1%20PV%20System%20Cost%20Benchmark%20Model.zip)

**R-B.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); CIM SP List and EB Mapping (snapshot 2026-09-10) (snapshot 2026-09-10): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP4-160-SG)

**R-C.** Large Load Interconnection Status Update (TAC report), 2026-03-13 (2026-03-12 (posted; deck dated 2026-03-13)): [official source](https://www.ercot.com/files/docs/2026/03/12/March-TAC-Report.pdf); Board Item 14: Batch Zero Update, 2026-09-14/15 (2026-09-11 (posted)): [official source](https://www.ercot.com/files/docs/2026/09/11/14-Batch-Zero-Update.pdf); Board Item 9.1: Batch Study Update, 2026-04 (2026-04-13 (posted)): [official source](https://www.ercot.com/files/docs/2026/04/13/9.1-Batch-Study-Update.pdf)

**R-D.** Electric Power Monthly Table 6.1 (June to July 2026) (2026-09 (release for July 2026 data)): [official source](https://www.eia.gov/electricity/monthly/xls/table_6_01.xlsx); EIA-860M, August 2026 generator file (2026-09 (file for August 2026)): [official source](https://www.eia.gov/electricity/data/eia860m/xls/august_generator2026.xlsx); Form 20-F for FY2025 (2026-04-29): [official source](https://www.sec.gov/Archives/edgar/data/1481513/000110465926050737/jks-20251231x20f.htm); Form 20-F for FY2025 (2026-04-10): [official source](https://www.sec.gov/Archives/edgar/data/1375877/000110465926041976/csiq-20251231x20f.htm); Form 20-F for FY2025 (2026-04-20): [official source](https://www.sec.gov/Archives/edgar/data/1477641/000110465926045134/dq-20251231x20f.htm); Form 10-K for FY2025 (2026-02-24): [official source](https://www.sec.gov/Archives/edgar/data/1274494/000127449426000021/fslr-20251231.htm)

**R-T (formerly R2-A).** Census International Trade API: HS6/HS10 solar imports by country, monthly 2024-01.2026-08 (2024-01 to 2026-08): [official source](https://api.census.gov/data/timeseries/intltrade/imports/hs); Census API query log (no key stored) (2024-01 to 2026-08): [official source](https://api.census.gov/data/timeseries/intltrade/imports/hs)

**R-F (formerly R2-D).** Trina Solar, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-30/1225263857.PDF); JA Solar, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-29/1225249462.PDF); Tongwei, 2025 Annual Report (FY2025 (calendar), comparatives FY2024): [official source](https://static.cninfo.com.cn/finalpage/2026-04-30/1225259224.PDF)

**E-S.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); CIM SP List and EB Mapping (snapshot 2026-09-10) (snapshot 2026-09-10): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP4-160-SG)

**E-A.** NSRDB V4 5-minute block extract, gid 1142134, 2023 (2023): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); NSRDB V4 5-minute block extract, gid 1142134, 2024 (2024): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); NSRDB V4 5-minute block extract, gid 1142134, 2025 (2025): [official source](https://developer.nrel.gov/docs/solar/nsrdb/); Scenario input register (finance parameters, 2026-10-07; local method, no official publication URL); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**E-B.** Fuel Mix archive 2007-2024 (IntGenbyFuel2023, IntGenbyFuel2024 used) (2023-2024): [official source](https://www.ercot.com/gridinfo/generation); Fuel Mix IntGenbyFuel2025 (2025): [official source](https://www.ercot.com/files/docs/2025/02/07/IntGenbyFuel2025.xlsx); Native Load 2023 (2023): [official source](https://www.ercot.com/files/docs/2023/02/09/Native_Load_2023.zip); Native Load 2024 (2024): [official source](https://www.ercot.com/files/docs/2024/02/06/Native_Load_2024.zip); Native Load 2025 (2025): [official source](https://www.ercot.com/files/docs/2025/02/11/Native_Load_2025.zip); Henry Hub natural gas spot price, daily (1997-2026): [official source](https://www.eia.gov/dnav/ng/hist_xls/RNGWHHDd.xls); GHCN-Daily TMAX/TMIN, DFW IAH SAT AUS (2023-2025): [official source](https://www.ncei.noaa.gov/access/services/data/v1?dataset=daily-summaries)

**E-C.** NP6-905-CD SPP at resource nodes, hubs and load zones, 2023 monthly archives (2023): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2024 monthly archives (2024): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); NP6-905-CD 2025 monthly archives (2025): [official source](https://www.ercot.com/mp/data-products/data-product-details?id=NP6-905-CD); Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)

**P01.** Adjusting Imports of Polysilicon and Its Derivatives Into the United States (91 FR 51975) (2026-08-11): [official source](https://www.federalregister.gov/documents/2026/08/11/2026-16400/adjusting-imports-of-polysilicon-and-its-derivatives-into-the-united-states)

**P02.** Notice 2025-42 (beginning of construction, wind and solar) (2025-08-15): [official source](https://www.irs.gov/pub/irs-drop/n-25-42.pdf)

**P03.** Notice 2026-15 (prohibited foreign entity / material assistance cost ratio interim guidance) (2026-02-12): [official source](https://www.irs.gov/pub/irs-drop/n-26-15.pdf)

**P04.** U.S. Utility-Scale Solar, 2025 Data Update (slides PDF) (2025-10): [official source](https://emp.lbl.gov/sites/default/files/2025-10/Utility%20Scale%20Solar%202025%20Edition%20Slides.pdf)

**Table A-1. Local analysis files associated with report claims.**

| IDs | Data files |
| --- | --- |
| S01 | data/miit_2024_observations.csv; data/miit_pdf_verification.json |
| S02–S05 | data/longi_product_margins.csv; data/irena_pv.csv; data/lbnl_2030_scenarios.csv; data/hourly_profile.csv |
| S06–S09 | data/scenario_metrics.csv; data/scenario_annual_cash_flows.csv; data/scenario_input_register.csv; data/breakevens.json |
| R-A–R-D | data/supplement/A–D/ (component, load, node and financial tables) |
| R-T; R-F | data/r2/A/; data/r2/D/ |
| E-S–E-C | data/empirical/ (sample, regression, decomposition and tail tables) |
| New client examples | data/Client-Illustrative-Calculations.json; data/2023-Benchmark-Price-Context.csv |


# Appendix B. Methods and Technical Notes

Technical details accompany the cost and market comparisons: current versus historical node classifications, time-zone mapping, shared missing intervals, leap-day approximation, weather fill flags, cost denominator differences, and finance definitions. The full original methods text is preserved in the accompanying technical notes; these qualifications remain part of the interpretation of the results.

## B.1 Layer 2: the ERCOT environment

**System data.** Native load and Solar/FINAL fuel-mix files describe the ERCOT system. The 2025 intraday exhibit uses 363 non-DST dates (8,712 matched hours); the seasonal exhibit retains all 365 dates (8,760 load hours, 35,040 solar intervals). Load (MW) and solar (MWh per hour) are shown on separate axes because their units differ. System solar is not a project output.

**Large-load and self-supply records.** The March 2026 process table (238.6 GW in the 2030 column; 5.8 GW observed energized on a noncoincident basis) and the September 2026 Batch Zero materials (including 11 WLPUN projects whose reported resource power capacities are 12.824 GW gas, 1.654 GW solar, 0.637 GW wind and 0.330 GW battery) are process snapshots with different dates and population definitions. They are not added together and are not demand forecasts. A 125.4 GW chart label and a 127.9 GW narrative figure in the same source deck are retained as an unresolved source inconsistency.

**Settlement point prices (NP6-905-CD).** The product reports 15-minute real-time settlement point prices. Prices are mapped to UTC from the delivery date, hour, interval and DST flag; the local-year grid has 35,040 intervals (35,136 in 2024). Hubs, load zones and DC ties are market benchmarks and never stand in for a node's missing price. Resource-node identity requires published type RN and membership of the 2026-09-10 official list, which is a current snapshot, not a historical record.

**Which node sample is which.**

| Sample | Definition | Used for | Not to be mixed with |
|---|---|---|---|
| 641 nodes (first round) | Type RN, on the official list, complete in **2025 only**; 2025 price substitution with the 2025 output curve | Figure 8-3 (capture-price distribution), Section 8.5 percentile statement | The three-year panel; a percentile from this population is not a result for the 485 nodes |
| 485 nodes (three-year common panel) | Type RN, on the official list, complete on the market-wide grid in **all three** years | Sections 8.5–8.8, 10.8, 11.6–11.9; Figures 8-3 to 8-6 and 11-3 to 11-6 | The first-round 641 sample |
| 757 points (R2 count; **incorrect as a resource-node count**) | Complete in all three years but not filtered on type: 486 RN-type points (485 on the list), 155 PCCRN, 67 LCCRN and 49 PUN points | Not used | Any statement about resource nodes |

The reconciliation is itemized in `data/empirical/tables/R2-757-Itemized-Screening.csv` and `Sample-Flow-By-Year.csv`.

**Common missing intervals.** Every published settlement point lacks the same few intervals: three in 2023 (13 April 15:45 and 16:00, 31 December 23:45), one in 2024 and two in 2025 (`Market-Wide-Missing-Intervals.csv`). On the raw grid no node is complete; after dropping those intervals for all series alike, 485 resource nodes are complete in all three years. Nothing is interpolated or set to zero. The two daytime 2023 gaps carry about 47.6 MWh of simulated site energy.

**Full-year versus common-calendar results.** The reference node's full-year NPV values (+97.76, −91.84 and −85.97 million USD for the 2023, 2024 and 2025 same-year pairings) come from the unmodified finance model on each year's own price grid (retained independent recomputation, `support/inherited/empirical-verification/independent_check.json`). The common-calendar matrix drops 29 February from every cell and uses the intersection of valid intervals across the three price years; its same-year cells for the reference node are +97.76, −92.15 and −85.97 million USD (`data/empirical/A_3x3_cells_by_node.csv`). The differences (0.31 million USD for 2024, 0.009 million USD for 2025) arise from the leap day and the removal of other years' gap intervals. The two are labeled separately in the report and neither replaces the other.

**Leap-day approximation.** PVWatts accepts only 8,760-hour multiples, so 29 February 2024 is simulated through a neighbouring-day slot. The 28 February slot gives 872.1 MWh for the day and the 1 March slot gives 878.2 MWh; the annual difference is 6.6 MWh (about 0.002%). This is a sensitivity between two approximations. It is not a bound on the exact leap-day output, and the common-calendar matrix excludes the day entirely.

## B.2 Layer 3: hypothetical project scenarios

**System.** 100 MWac / 132 MWdc (DC/AC 1.32), single-axis tracking with backtracking, ground-coverage ratio 0.30, inverter efficiency 96%, bifaciality 0.70, aggregate losses 14.0757%, annual degradation 0.7% from operating year 2. Weather comes from the retained NSRDB GOES CONUS v4 5-minute extracts at grid cell 1142134 in Pecos County for 2023, 2024 and 2025, simulated with PVWatts v8 through PySAM 7.1.1. The location is neither a county average nor a verified asset site.

**Finance model.** Pre-tax and unlevered; capital expenditure at the end of 2026 (about $1,436.75/kWac, ATB OCC plus GCC converted from 2023 to 2025 dollars with CPI-U), 30 operating years from 2027, real 2025 dollars, NPV at the 2026 valuation point and a 4.27% real discount rate (6% and 8% also reported). Replacement ($35/kWac, year 16) and net decommissioning ($30/kWac, year 30) are included. Taxes, credits, debt, market fees and site-specific land, insurance and network costs are not.

**Two revenue routes.** The nodal route repeats the first-year price shape in real terms for 30 years and sets exports to zero whenever the price is below zero. The fixed-price route uses a flat nominal $40/MWh and an unpaid-energy reduction of 15.24% of potential energy, anchored to the negative-price energy share; it is neither an observed curtailment rate nor a contract term.

**Linear NPV identity.** With the retained degradation and discounting, NPV = 15.47 × first-year receipts − $187.3 million, and break-even first-year receipts are about $12.1 million. This identity is what links the three-year receipts in Section 10.8 to NPV; it is not a valuation multiple.

**IRR.** A single IRR is reported only where the cash flows have a certified unique real root. In the six 2025-based scenarios the node_upside case has a unique root (−0.42%); node_base, node_downside, fixed_base and fixed_upside have multiple admissible roots, and fixed_downside has no certified single root. Single-IRR fields are null where required. No IRR is computed for the 485-node empirical sample.

**Scenario groups, sensitivities and break-evens.** Downside and upside cases move several inputs together and are not probability bounds. One-way sensitivities (49 identifiers) and two-way grids are analytical ranges. Break-even thresholds (for example about $66/MWh flat nominal at base CAPEX, or CAPEX of about $577/kWac in the nodal route at 4.27%) identify what evidence would change a conclusion; they are not market quotations.


## B.3 Alternative weather/price accounting

The two-factor Shapley decomposition allocates the interaction between weather-profile and price-profile changes equally to those two factors. It produces the following component medians:

**Table B-1. Weather and price contributions: Shapley allocation.**

| Transition | Total NPV change, $m | Weather contribution, $m | Price contribution, $m |
|---|---:|---:|---:|
| 2023 to 2024 | -190.6 | -5.4 | -184.7 |
| 2023 to 2025 | -183.0 | -8.5 | -174.4 |
| 2024 to 2025 | +6.0 | -3.4 | +9.1 |

*Source: multi-year analysis, Shapley component tables. Exact addition holds for each node. Separately calculated component medians need not add to the median total; they are not a decomposition of a single representative median node.*

The price-profile contribution is much larger than the weather-profile contribution for the transition out of 2023. This conclusion is about the model and sample. It leaves unverified why prices changed or how future market conditions will develop.


The original mixed exhibit below retains pure effects plus interaction in its left panel. Its left bars are not the Shapley allocations in Table B-1. It is preserved as a technical diagnostic and must not be compared as if the numbers were identical.

![Figure B-1. Original pure-effect and price-volume diagnostics](figures/empirical/F3_npv_change_decomposition.png)

# Appendix C. Research Limits

The remaining research gaps concern comparable industry output/capacity/inventory, delivered project quotes, product-specific trade applicability, customer procurement commitments, historical node identity and price finality, longer-run weather/price distributions, full project costs, taxes, financing and storage. Each limits box identifies the relevant commercial boundary. Gap identifiers GAP-01 through GAP-16 and the original detailed restrictions are preserved in the supporting research-limit record.



**Research-limit index (legacy identifiers).** GAP-13a denotes sensitivity coverage; GAP-13b denotes the resampling/mixture limitation. The archival original is preserved with its original labels. No evidence gap is closed by editorial renaming.

**GAP-01.** The summary now incorporates the empirical and second-round results. Expected returns, forecast probabilities, a verified project shortlist, and asset-specific validation remain unestablished.

**GAP-02.** Country-level net changes and the U.S. segment snapshot are incorporated below. Comparable segment histories and market forecasts remain open.

**GAP-03.** The incompatible manufacturing/capacity comparison is explained below. A reconciled shipment, trade, and inventory balance remains unavailable.

**GAP-04.** Seven-company coverage now includes Trina, JA Solar and Tongwei FY2025 filings. LONGi FY2025 full-report coverage and comparable segments remain incomplete.

**GAP-05.** Company-specific utilization boundaries and prices are discussed below. A comparable industry capacity and product-price panel remains open.

**GAP-06.** PVSCM components, conditional transmission and Census import context are integrated. Customs value per item is not a delivered price per watt; the AC-denominator inconsistency remains unresolved.

**GAP-07.** Official proclamation and IRS context are incorporated below with effective dates and scope limits. HTS annex mapping, IEEPA interactions, unresolved ITC outcomes, and procurement applicability remain unverified.

**GAP-08.** March and September ERCOT process evidence incorporated below. Source inconsistency, a comparable later status series, customer-level commitments, and hourly procurement requirements remain open.

**GAP-09.** Pipeline and network evidence incorporated below. Interval-level causal attribution, actual interconnection costs, and reliable commissioning probabilities remain open.

**GAP-10.** Three-year nodal comparisons and classification correction are incorporated. Historical identity coverage, longer-run representativeness, price-finality and asset-specific settlement remain incomplete. Hubs and load zones remain benchmarks only.

**GAP-11.** Three same-site weather years are available and used. Long-run weather uncertainty, validated P50/P90 and project-specific performance remain unestablished; no additional weather simulation was run during this editorial integration.

**GAP-12.** Public benchmark coverage, policy context and the finance-to-revenue link are integrated. Complete project cost, commercial mapping, tax eligibility and financing remain unavailable.

**GAP-13a.** Multi-node price substitution integrated below. Weather-year, contract, and cost-coverage robustness remain open; this is not actual asset valuation.

**GAP-13b.** Same-year comparisons, decomposition and tail stresses are integrated. Price forecasts, regime probabilities, causal estimates and actual investment returns remain outside the evidence. Existing regressions and pipelines were not rerun for this edition.

**GAP-14.** Deferred: independent storage design, dispatch, degradation, and incremental cash flows. Solar-only analysis remains usable.

**GAP-15.** The decision matrix is extended by historical tail dependence and conditional price associations. Actual customer orders, procurement terms, reliable price forecasts and opportunity returns remain unverified.

**GAP-16.** The report incorporates three historical market years and explicit stress settings. Long-run regime probabilities, quantified forecasts and validated update thresholds remain unestablished.

# Appendix D. Glossary


| Term | Meaning in this report |
| --- | --- |
| ERCOT | Electric Reliability Council of Texas; grid and wholesale-market operator for most of Texas. |
| MIIT / IRENA | Ministry of Industry and Information Technology (China) / International Renewable Energy Agency. |
| DOE / NLR | U.S. Department of Energy / National Laboratory of the Rockies; older source documents use NREL, National Renewable Energy Laboratory. |
| ATB / PVSCM | Annual Technology Baseline / Photovoltaic System Cost Model; national reference models, not project quotes. |
| OCC / GCC / FOM | Overnight capital cost / grid-connection cost / fixed operations and maintenance. |
| NSRDB / PVWatts / PySAM | National Solar Radiation Database / photovoltaic output model / Python interface to the System Advisor Model. |
| Settlement point / resource node | Pricing location; RN denotes the official resource-node type used to filter this report’s sample. |
| Hub / load zone | Aggregated market-price reference locations; not substitutes for the asset’s settlement node. |
| HB_BUSAVG | System benchmark identifier used in the hourly analysis; its formal name is not disclosed in this edition. |
| NP6-905-CD | ERCOT’s 15-minute real-time settlement-point price report, not day-ahead prices. |
| Basis | Node price minus the specified benchmark price. |
| Time-/generation-weighted price | Average across equal-duration intervals / price averaged with simulated output as weights. |
| Capture ratio | Generation-weighted price divided by time-weighted price; denominator and export rule must be stated. |
| LCOE / NPV / IRR | Levelized cost of energy / net present value / internal rate of return; definitions in Table 2-1. |
| TAC | Technical Advisory Committee (ERCOT). |
| Batch Zero | One-time transitional reliability study for eligible large-load interconnections under PGRR145; September deck, p.5 [R-C]. |
| WLPUN / BYOG | Withdrawal Limited Private Use Network / Bring Your Own Generation; September deck p.8 and April study deck p.1 [R-C]. |
| Noncoincident peak | Individual peak observations may occur at different times; their aggregate is not a simultaneous system load. |
| HS / HTS / IEEPA | Harmonized System / U.S. Harmonized Tariff Schedule / International Emergency Economic Powers Act. |
| ITC / PTC | Investment tax credit / production tax credit; the cash-credit illustration is not an eligibility calculation. |
| P50 / P90 | Output exceeded with 50% / 90% probability over a defined horizon; three weather years do not establish these probabilities. |
| Shapley / LMDI | Allocation of interacting changes by averaging orders / log-mean Divisia index accounting decomposition. |
| HAC / block bootstrap | Heteroskedasticity and autocorrelation consistent uncertainty estimates / resampling consecutive time blocks. |
| RMSE | Root mean squared error; a prediction-error measure. |
| DC/AC / bifaciality / GCR | Module-to-inverter nameplate ratio / rear-to-front conversion efficiency ratio / ground-coverage ratio. |


# Appendix E. Project Governance Notes — internal

This customer-readable research edition is an editorial successor to v0.5; it is not the original project Version 1.0. The original ten acceptance criteria remain unchanged. Criterion 6 retains the project-specific resource, nodal-finality/commercial-mapping, cost, tax and financing gaps. The original 67-field register has 59 blocked, 5 not_yet_verified and 3 reference_assumption fields. Its 13 prohibited outputs remain null. Scenario results are kept separate from those interfaces.

The complete earlier governance and technical passages, gap records and update instructions are preserved without deletion in support/Original-Governance-and-Technical-Notes.md and support/Original-Limits-and-Gaps.md. Prior research verification keeps its original date and scope. This revision does not authorize publishing, sale, external sending, account access or changes to actual hours or work logs.


## E.1 Updates should preserve comparable observations

The next regional-demand update should compare the same process definitions and identify migrations between statuses, rather than add a later headline total to an earlier snapshot. The next nodal update should retain missing-interval handling, separately examine extreme prices, and distinguish a new weather-price year from a repetition of the 2025 output profile. Company updates should preserve fiscal periods, accounting concepts, currencies, and segment boundaries.

The delivered-cost bridge is the most direct next research target for assessing the manufacturing-to-project connection. A public U.S. trade unit value could provide context but would remain an aggregate quantity/value measure, affected by product and origin mix; it would not automatically become a bankable delivered-project quotation. A quotation-based bridge would additionally require specification, origin, logistics, duty, payment, warranty, and delivery-date terms.

No forecast probabilities or commercial conversion rates are supplied without a documented estimation basis. The present evidence supports directional mechanisms and conditional thresholds; it does not support extrapolating queue totals, a single historical price year, or one company's results into a quantified market forecast.

