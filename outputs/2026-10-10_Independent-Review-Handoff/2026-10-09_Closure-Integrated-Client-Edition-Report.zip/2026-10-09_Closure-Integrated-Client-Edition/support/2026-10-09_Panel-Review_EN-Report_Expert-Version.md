# 小组评审意见：《From China's Solar Supply Chain to U.S. Power Markets》客户可读版（Research edition，2026 年 10 月，56 页）

- 评审对象：Integrated-Market-Research-Report-EN_Client-Readable.pdf（Codex 按上一轮客户审读意见修订后的版本）
- 评审日期：2026-10-09
- 页码：按 PDF 页脚的 "Page N"。
- **版本说明：本文件是未经客户审查的专家版**，即四位审读人两轮评审后合并、尚未请中等知识量客户检查例句的版本。经客户审查修订的版本见 `2026-10-09_Panel-Review_EN-Report-Client-Readable.md`。
- 本文件只提意见，没有修改报告。它取代同日的单人审读文件 `2026-10-09_Expert-Review_EN-Report-Client-Readable.md`；单人意见中与小组一致的部分已并入本文。

## 评审小组与流程

| 代号 | 审读人 | 专精方向 |
|---|---|---|
| **A** | 专家 A | ERCOT 电力市场与商业结构：节点/枢纽价格与结算、PPA 结构、稀缺定价与市场规则、储能、发电量与弃电 |
| **B** | 专家 B | 跨境贸易与美国政策：AD/CVD、Section 201/301/232、UFLPA、海关数据、45Y/48E/45X 税收抵免与外国实体规则、采购合同 |
| **C** | 专家 C | 中国光伏产业链与企业财务：各环节产量、价格与产能，产业政策，企业财报，海外产能布局 |
| **D** | 经济学家 D | 计量与定量方法：回归、预测检验、分解方法、重抽样、样本构造 |

三位专家都具备电力市场、跨境贸易和中国光伏产业链的基础知识，但各有专精；经济学家只评审计量和定量模型部分。

评审分两轮。第一轮四人各自独立评审；第二轮互相阅读，回答别人点名的问题，指出同意、反对和需要合并的意见，并修订自己的意见。本文由汇总人按共识程度合并而成，每条注明来源（例如"A-2 + D-T4"表示专家 A 第 2 条与经济学家 D 第 T4 条合并），审读人之间的分歧单列在第三部分。各审读人的原始意见保存在评审工作稿中，需要时可以提供。

**硬性标准：改完的稿子仍须让知识面中等的客户读得懂。** 这类客户了解节点电价、PPA、负电价、LCOE/NPV 等基本概念，但不是 ERCOT 交易员、贸易律师或计量经济学者。因此每条建议都附有可读性标签：
- 【正文可直接加入】
- 【需白话改写】
- 【建议放附录】

凡是要进正文的内容，都给出了建议的英文白话例句。凡是技术细节，都建议"正文一句白话 + 附录详述"。第六部分是给修订者的可读性守则。

标注 **〔外部知识，需核对〕** 的内容来自审读人自己的行业知识，不是报告里的数据，引用前请核对原始来源。审读人的知识可能不覆盖 2026 年中期以后的事件。

---

## 总体判断（四位审读人的共识）

1. **算术可靠。** 四人分别用报告自己的数字复算了二十多处，几乎全部对得上（见第五部分），只发现一处小的口径偏差（10.7a 抵免现值应为约 4,033 万而不是 4,134 万美元）。报告在"不把话说过头"上做得很好。
2. **主要短板是漏掉了几项对结论影响最大的现实因素，恰好落在标题承诺的三个领域：**
   - **ERCOT 市场**：没有交代 2023 年之后市场规则和储能装机的变化，却把单一年份的价格形态重复 30 年；固定价路线的合同形式与市场实际做法不一致。
   - **跨境贸易与美国政策**：没有讲美国贸易措施如何把美国组件价格和中国价格隔开；没有讲税收抵免资格如何取决于开工日期以及设备来源和所有权。后者正是"中国供应链"和"美国项目价值"之间最直接的联系。
   - **中国产业链**：数据停在 2024 年；没有交代 2025–2026 年的产业政策变化，也没有交代中国企业通过海外工厂进入美国市场的路径。
3. **计量部分的结论站得住，但正文方法词过密，表与表之间对不上账。** 建议正文只留白话结论，方法放附录；分解表改用能加总的均值。
4. **客户版里仍有内部内容和编辑残句**，包括附录 E（标着 internal）、内部文件路径，以及第 13、16、19 页的残句。
5. **最重要的一句白话结论目前没有写出来**：在报告自己的模型里，决定项目成败的是电价年份（约 1.8 亿美元量级），而不是设备价格或天气（各约 1,000–1,500 万美元量级）；即使组件免费，2025 年价格下项目也收不回投资。

---

## 一、优先修改的 12 条（按重要性排序）

### 1. 说清 2023 年的高价不能当作可重复的情景：三个价格年份都在市场规则变化之前
**来源：A-2 + D-T4 + D-S7 + D-S6 + A/B/D 关于抵免时期负电价的回应**
**位置：** 第 3 页 1.1 第 4 条；第 4 页 1.3；第 34 页 10.8；第 39–41 页 11.7–11.9；第 47 页 14.2、14.4

- **问题：**
  - 报告把 2023、2024、2025 年的价格形态各自重复 30 年。但〔外部知识，需核对〕2023 年以后 ERCOT 有几项公开的重大变化：2023 年夏季创纪录高负荷，9 月出现电力紧急状态；2023–2025 年电池储能大量投运，压低了傍晚的高价；2025 年 12 月 ERCOT 改变了实时稀缺定价的规则（实时联合优化）。三个样本年份全部在这次规则变化之前，新规则下的价格形态无法从这批数据推断（D）。
  - 2023 年的正收益依赖的是一段比较窄的价格（D-T4，数据来自技术报告）。具体结果如下：

    | 压力测试方式 | 结果 |
    |---|---|
    | 删除前 1% 区间的收入 | 99.4% 的节点转负 |
    | 价格按 99 分位封顶 | 约 84% 的节点转负 |
    | 价格按 99.9 分位封顶 | 所有节点仍为正 |
    | 剔除含 ≥$1,000 区间的日期 | 共 34 天，占全年收入 65% |

    也就是说，正收益靠的是约 80 小时"高但不是最极端"的价格。这一价格带恰恰是储能套利和新的稀缺定价最先压平的部分（A）。客户版没有报告 99.9 分位封顶的结果，也没有给出 34 天、65% 这两个数。
  - 报告没有说明 2023、2024 年的名义电价是否换算成了 2025 美元（D-S6）。如果没有换算，2023 年 NPV 约低估 1,600 万美元：18.56 × 1.0566 × 15.47 − 187.3 ≈ +116，而表中是 +99.8。
- **建议：**
  - 11.7 末尾加 3 句白话说明背景，不做因果归因；出处列在附录，例如 ERCOT 独立市场监测机构的年度报告、ERCOT 规则变化公告。
  - 执行摘要只写一句结论，三种压力测试的对比放在 11.8。
  - 附录 B.2 写明各年电价的美元口径。
- **正文例句：**
  - 11.7：*"Since 2023, Texas has added many large batteries and changed its market rules for pricing power shortages. Both tend to make extreme price spikes rarer. All three price years in this report come before that rule change, so a 2023-style year should not be assumed to return."*
  - 执行摘要：*"2023's positive result depended on roughly 80 hours of high—but not the most extreme—prices; removing them erases it."*
  - 10.8：*"Repeating one year's prices for 30 years assumes the solar fleet and market rules stay as they were."*（A 认为储能在中午充电会抬高午间价格，所以不建议在正文断言"重复单年偏乐观"，见第三部分分歧 7。）

【需白话改写；缩写和出处建议放附录】

### 2. 税收抵免：改成"按时开工投运 / 延误"两种情形，并写明抵免资格与设备来源和所有权挂钩
**来源：B-1 + B-2 + C-5 + A、D 的回应；10.7a 数字由 B 提出、D 核实**
**位置：** 第 6 页 Box 1；第 33–34 页 10.7、10.7a；第 42 页 12.1；第 44–45 页 13.1、13.5

- **问题：**
  - **时间窗口。**〔外部知识，需核对〕2025 年 7 月的联邦税法修订（OBBBA）规定，2026 年 7 月初以后才开工的风电、光伏项目，必须在 2027 年底前投运才能拿到 45Y/48E 抵免；更早开工的项目适用连续施工安全港。报告的时间表是 2026 年底付清投资、2027 年投运，但没有给出开工日期。按时投运时，"无抵免"是保守情景；延误时，"无抵免"才是现实情景（B，A、D 补充了开工日期这一前提）。
  - **量级。** 10.7a 的示例显示，抵免能补上约一半的资本缺口，是第 1.1 节之外最大的单项改善，但执行摘要没有提。
  - **来源和所有权。**〔外部知识，需核对〕新的外国实体规则（prohibited foreign entity）有两层限制：一是来自受限实体的设备占比超过门槛，项目会失去抵免资格；二是受限实体本身作为业主，不能申领抵免。所以"更便宜的组件"可能同时意味着"失去抵免"。本例中抵免是组件降价收益的数倍（B）。此外，即使能拿到抵免，组件降价也会同时降低抵免基数：降价的净收益约为 12.79 − 0.30 × 12.79 ÷ 1.0427 ≈ 9.1 百万美元，而不是 12.79（B，C、D 已复核）。
  - **10.7a 的折算小误差。** 抵免是固定的名义金额，不随通胀上调。按模型自己的口径计算，现值约为 4,033 万美元，不是 4,134 万：0.30 × 143.67 × 1.025 ÷ 1.025² ÷ 1.0427。相应地，node_base NPV 约为 −45.6m，固定价保本电价约为 $51.8/MWh（原文 $51.4）。结论方向不变（B 提出，D 核实）。
- **建议：**
  - 10.7 加一张三列小表：开工日、投运日、截止日。开工认定方式、外国实体规则细则放附录。
  - 执行摘要加一句白话。
  - 12.1 的替代解释改为 "trade duties and tax-credit eligibility tied to equipment origin and supplier ownership"。
  - 13.5 决策矩阵加一行 "Check whether the supplier's ownership affects the buyer's tax credit"。
  - 10.7a 改用 40.33，或者写明"假设抵免随通胀调整"。
  - 发电量型抵免（PTC）的示例只放附录，见第二部分 B 组。
- **正文例句：**
  - *"If the project starts construction in time and enters service on schedule, a federal tax credit is likely available and roughly halves the modeled gap; if it slips past the deadline, the no-credit case applies."*
  - *"For a U.S. buyer, a cheaper module is not automatically a better deal: under current U.S. tax rules, equipment linked to certain foreign-owned suppliers can reduce or remove the project's tax credit. In this example the credit is worth several times the module saving."*

  不要写"约 3.2 倍"，也不要把这个倍数放进执行摘要的数字列表，见分歧 4。

【需白话改写；法条细节建议放附录】

### 3. 把 8.9% 的组件降价示例改成不依赖中国价格的写法，并补一句"组件免费也不够"
**来源：C-2 + B-3 + D 的回应 + A 新增的"组件免费"复算**
**位置：** 第 3 页 1.1 第 3 条；第 14–17 页 5.2–5.7；第 44–45 页 13.1、13.5

- **问题：**
  - 8.9% 的算法是把 MIIT 报告的中国国内组件价格跌幅（−29.7%）直接套到美国组件价格上，算式为 0.261 × 1.144 × 0.297 ≈ 8.87%，算术无误。问题在于美国组件价格被贸易措施隔开，两边价格可以长期朝不同方向走（B、C）。〔外部知识，需核对〕全文没有出现 AD/CVD、Section 201/301、UFLPA 这些决定传导程度的规则。
  - 报告自己给出的 $0.38/W 进口价格下限，比模型里约 $0.29/Wdc 的组件价格还高。在相关产品范围内，价格传导的方向可能是涨而不是跌（C）。
  - 对制造商读者来说，最有冲击力的事实没有写出来（A 复算）。按报告的比例，组件约占造价 1,437 × 0.261 × 1.144 ≈ $429/kWac。即使组件免费，造价也只降到约 $1,008/kWac，仍高于节点路线的保本造价 $577 和 $40 固定价下的 $699，NPV 约为 −43m。
- **建议：**
  - 5.5 改为参数化写法，计算放附录：美国组件价每降 10%，总造价约降 3%，NPV 约改善 430 万美元（0.261 × 1.144 × 10% × 143.67）。附录给 10%、20%、30% 三行（D、C）。
  - 原来的 8.9% 示例可以保留，但要加一句白话说明它的前提。
  - 5.1 加一个四步的白话成本链："factory price → shipping → U.S. duties and tariffs → delivered to site"。B 建议的八级到岸成本明细和贸易措施登记表（措施、依据、覆盖国家、生效日、状态）放附录。
  - 13.1 加上"组件免费"这句。
- **正文例句：**
  - *"The 29.7% fall is a Chinese domestic price change. U.S. buyers pay a separate, higher price, because U.S. trade duties sit between the factory and the U.S. site. A Chinese price fall can therefore coexist with flat or higher U.S. prices."*
  - *"Each 10% fall in the U.S. module price lowers total cost by about 3% and improves NPV by about $4 million."*
  - *"Even if modules were free, the modeled project would still not recover its capital at this node under 2025 prices; equipment price alone cannot close the gap."*

【正文可直接加入；成本明细和措施登记表建议放附录】

### 4. 新增一张"同一把尺子"小表，让客户一眼看出主要矛盾是电价，不是设备
**来源：B 第二轮提议 + D 第二轮补充；A 反对表中列入天气年份，见分歧 2**
**位置：** 建议放在第 1.2 节关键数字表之后，或第 11 章开头

| 变动（各项假设不同，不是概率） | 对 NPV 的影响（百万美元） | 依据 |
|---|---|---|
| 价格年份：2023 → 2024 年价格（485 节点中位数） | 约 −181 | 表 10-2：−81.6 − 99.8 |
| 30% 投资抵免示例 | 约 +40 | 10.7a，修正后 |
| 组件免费（极端假设） | 约 +43 | 1,437 × 0.261 × 1.144 × 100 MW |
| 美国组件价每降 10% | 约 +4 | 0.299 × 10% × 143.67 |
| 每瓦组件价变动 $0.10 | 约 ±15 | 0.10 × 1.144 ÷ 1.115 × 143.67 |
| 模拟发电量 ±10% | 约 ±10 | 15.47 × 6.55 × 10% |

- 表下一句白话：*"In this model, which price year you assume matters roughly ten times more than equipment cost or output assumptions."*
- 天气年份的影响（约 1,200–1,300 万美元）放附录，并说明它混有"天气与电价的同步关系被切断"的效应，不是天气好坏本身（D-T1，A）。

【正文可直接加入】

### 5. 说明固定价路线代表哪种合同；指出 15.24% 不付费电量是一个很严厉的设定
**来源：A-1 + A-5 + B 的补充；汇总人在单人审读中提出的复算；D 对措辞的修正**
**位置：** 第 30–31 页 10.3、表 10-0；第 33 页 10.6；第 36 页 11.3 表 11-1；第 3 页 1.1 第 2 条

- **问题：**
  - **合同形式与市场实际不符。** 从计算方式看，固定价路线等于"买方在项目自己的节点按发电曲线收电 30 年"。〔外部知识，需核对〕ERCOT 公司买家（包括数据中心）更常见的是在交易枢纽（西德州项目通常是 HB_WEST）结算的虚拟 PPA，期限 10–15 年，之后是商户尾段；节点和枢纽之间的价差风险留给卖方（A）。所以 $66/MWh 不能直接拿去和市场 PPA 报价比。
  - **负电价很浅。** 报告自己的数字显示，参考节点负电价时段的平均价只有约 −$1.8/MWh：(6.471 − 6.551) ÷ 44.6 GWh。在无抵免的商户情景下，停发几乎没有损失。但固定价路线把这 15.24% 的电量按 $40 全部不付款，每年少收约 178 万美元，NPV 影响约 2,000 万美元（11.1 的 ±20.4m 与此一致）。也就是说，合同里的负电价条款比停发行为本身重要得多（A）。
  - **对盈亏平衡价的影响。**（汇总人复算）如果去掉不付费电量，固定价盈亏平衡价约为 66.0 × (1 − 0.1524) ≈ $56/MWh。执行摘要的头条数字 $66 很大程度上取决于这个设定。
  - **fixed_downside 的 30.48% 没有依据。** 它只是 15.24% 的两倍，没有说明代表什么情形（A-20）。
  - **有抵免时结论会变。** 如果项目拿的是按发电量计的抵免（PTC），它在小幅负电价时仍会发电，"停发几乎无损失"就不成立（A、B、D）。
- **建议：**
  - 10.3 用一句话说明固定路线代表哪类合同。
  - 表 11-1 增加一行"无不付费电量时的盈亏平衡固定价"（约 $56）。
  - 1.1 第 2 条说明 $66 已包含 15.24% 不付费的假设。
  - 附录 B 加一张风险分配表，列出商户节点售电、节点交付 PPA、枢纽结算虚拟 PPA 三种结构下，电量、形状、基差、负电价和政策这五类风险分别由谁承担（A、B）。
  - 如果可行，附录补一个"枢纽结算 + 节点基差"和"12–15 年合同 + 商户尾段"的敏感性。
- **正文例句：**
  - *"The fixed-price route assumes the buyer takes delivery at the project's own price node for 30 years. Most corporate contracts in ERCOT instead settle at a trading hub for 10–15 years, which leaves the seller exposed to the price gap between the node and the hub. The $66/MWh threshold should therefore not be compared directly with hub-settled PPA quotes."*
  - *"Negative prices at this node were shallow, averaging about −$2/MWh, so in the no-credit case a plant loses little by switching off. Under a fixed-price contract, however, a clause that withholds payment during negative prices removes about 15% of paid volume. The contract clause matters more than the shutdown itself. Without that clause, the break-even price falls to about $56/MWh."*
  - *"Each solar MWh was worth about $24 less than an average around-the-clock MWh at this node."*（$46.37 − $22.13。D 指出这是价值差，不是把光伏变成连续供电的成本，不要写成 "floor"，见分歧 3。）

【正文可直接加入；风险分配表建议放附录】

### 6. 给出参考节点的选择理由，并与交易枢纽对照
**来源：A-3 + A-7 + D-E10；汇总人单人审读同见**
**位置：** 第 4 页 1.3；第 23 页 8.1；第 25 页 8.5；第 55 页附录 D

- **问题：**
  - "not disclosed in this edition" 全文出现 7 次以上，客户读起来像有所隐瞒。〔外部知识，需核对〕从名称看，TAYGETE2_ALL 很可能是佩科斯县一座已运行光伏电站（Taygete 二期）的资源节点。如果是这样，选择理由很自然，而且它的捕获率处于第 3 百分位也有了解释：它反映的是西德州光伏密集带来的午间压价。
  - 报告没有把参考节点和西德州项目最自然的商业参照 HB_WEST 放在一起对比。
  - 〔外部知识，需核对〕HB_BUSAVG 是 ERCOT 公开定义的枢纽母线平均价格，可视为系统参考价。术语表写"正式名称本版不披露"，会让专家读者质疑作者对 ERCOT 的熟悉程度。
- **建议：**
  - 核实节点身份后写一句理由。如果仍无法说明，就只在 1.3 说一次，并把措辞改为 "has not been documented"。
  - 8.1 或 8.5 加一行对照：同一模拟出力在 HB_WEST、LZ_WEST、HB_BUSAVG 上的发电加权价格和捕获率（数据已在 NP6-905-CD 中）；图 8-3 上标出 HB_WEST 的位置。
  - 术语表给出 HB_BUSAVG 的白话解释。
- **正文例句：**
  - *"TAYGETE2_ALL is the price node of an existing solar plant in the same county [if confirmed]. Its midday prices are unusually weak relative to its own daily average, so it is a less favourable example than the typical node. Priced at the West hub, the same output would earn $X/MWh."*

【正文可直接加入】

### 7. 改正"485 个节点"的表述：这是按规则筛出的老节点，正值占比不是概率
**来源：D-T2 + A-12 + A-15 + D-E7**
**位置：** 第 3 页 1.1 第 4 条；第 25 页 8.4–8.5；第 34 页表 10-2；第 41 页 11.9；第 50 页附录 B 样本表

- **问题：**
  - 485 个节点是 2023–2025 年三年价格都完整、且在 2026 年官方清单上的全部资源节点，不是随机抽样。2024–2025 年新增的 156 个节点被排除在外。偏差方向需要对比这 485 个节点和 156 个新节点才能确定（D 在第二轮收窄了措辞）。
  - 所有节点用的是同一条西德州出力曲线，彼此高度相关。"2.68% 为正"描述的是这个节点群，不是新项目盈利的概率。
  - 附录 B 样本表把图 8-3 和第 8.5 节同时归到 641 节点和 485 节点两个样本下，前后矛盾。而且 8.6–8.7 的回归用的是系统基准价，并不是 485 节点面板。
- **建议：**
  - 全文 "sampled nodes" 改为 "screened nodes"。
  - 1.1 第 4 条加上半句说明。
  - 修正附录 B 样本表的"用途"一列。
  - 表 10-2 脚注说明 13 个正值节点分布在哪些负荷区。
  - 附录对比 485 个老节点与 156 个新节点的 2025 年价格分布。
- **正文例句：**
  - *"The 485 nodes are every official generator pricing point with complete prices in all three years, the same West Texas output profile is priced at each. The share of positive nodes describes this group, not the chance that a new project is profitable."*

【正文可直接加入；对比分布建议放附录】

### 8. 补齐中国产业链：数据时效、两层价格、政策、海外产能与所有权
**来源：C-1 + C-5 + B-2 + B-5 + C 第二轮补充**
**位置：** 第 3 页 Edition scope；第 9–13 页第 4 章；第 16–17 页 5.6–5.7；第 44–45 页 13.1；第 47 页 14.2–14.3

- **问题：**
  - **数据过时。** 报告日期是 2026 年 10 月，但行业数据只有 MIIT 2024 年这一份，用的还是福建省转载版；LONGi 只有 FY2024 数据，也没有 2026 年半年报。〔外部知识，需核对〕到 2026 年 10 月，这些数据按惯例都应已公开。
  - **两层价格没有分开。**〔外部知识，需核对〕全球价格由中国工厂决定；能进入美国的产品是另一个更高的价格层。−29.7% 描述的是前者（C）。
  - **缺少产业政策。**〔外部知识，需核对；政策名称、日期、幅度请作者核实〕"反内卷"行业治理、出口退税调整、新能源全面入市（136 号文）对国内需求的影响，都没有写。标题里的 "Industry Restructuring" 基本没有展开。
  - **缺少中国供应链进入美国的路径。**〔外部知识，需核对〕主要经由海外工厂，来源国随美国措施逐轮转移（第 17 页的海关数据就是痕迹）；多家中资企业出售或稀释了美国工厂股权（交易明细请作者逐一核对）。由于业主层面的外国实体限制，中资企业在美国更可能当供应商，而不是项目业主（B）。
  - **展望只有需求侧。** 第 14 章没有"中国减产提价成功或失败"的供给侧情景（C-S12）。
- **建议：**
  - 补 MIIT 或 CPIA 的 2025 年数据、LONGi FY2025 数据；补不了就在 Edition scope 里明确写出。
  - 第 4 章末新增约半页小节 "How Chinese supply reaches the U.S. market"：C 主笔中国政策和海外产能，B 主笔美国准入条件（原产地、外国实体、UFLPA）。政策条文、工厂与股权明细放附录。
  - 14.2 补两句供给侧情景；表 14-1 的制造业一行改为具体指标，并新增一行"贸易与税收政策"。
- **正文例句：**
  - *"China's manufacturing data in this edition stop at 2024 for the industry and FY2025 for companies; treat them as the starting point of the downturn, not its current state."*
  - *"There are effectively two module prices: a global price set by Chinese factories, and a separate, higher price for products eligible to enter the U.S. The 29.7% fall describes the first."*
  - *"Most Chinese-brand modules sold in the U.S. are made in factories outside China, and the countries involved have shifted each time new U.S. trade measures arrived. For a Chinese-owned supplier, who owns the factory can matter as much as where it is."*
  - *"If China's production cuts succeed, upstream prices may rise and the module saving shown in Chapter 5 shrinks further; if they fail, prices may fall again, but U.S. trade rules limit how much of that reaches U.S. buyers."*

【需白话改写；条文与明细建议放附录】

### 9. 公司财务面板和 H3：结论可以更明确，口径要先理清
**来源：C-3 + C-4 + C-S5 + B-S4 + D-Q6 + C 关于幸存者偏差的补充**
**位置：** 第 9–13 页第 4 章；表 4-2；图 4-2；第 42–44 页 12.3、表 12-1

- **问题：**
  - **H3 判"Mixed"偏保守。** H3 是一个"可以并存"的存在性命题，报告自己的数据已经证明了它：Trina、JA、Tongwei FY2025 归母净亏损约 70、46、96 亿元，Daqo 两年毛利率都是 −20.7%。而且面板只包括仍在披露的头部上市公司，退出的二三线企业不在样本里，行业困境只会被低估（C、D）。
  - **12.3 正文与表 12-1 不一致。** 12.3 正文只引用了 LONGi，而表 12-1 写的是"扩充的公司面板"；表 12-1 还把 ERCOT 的电站收入分解当作 H3 的支持证据，这是项目层面的价值，不是制造环节的价值（C、D）。
  - **表 4-2 的口径问题：**
    - 合并毛利率和分部毛利率混在同一列；
    - 美股公司的净利润全部标 n/a，而年报里有；
    - A 股三家只列了 FY2025，正文却给了 FY2024 的资本开支；
    - 合并报表还是母公司报表"未确认"，这是发布前应完成的基本核对。
  - **First Solar 不是可比同行。** 它是美国本土薄膜厂商，〔外部知识，需核对〕毛利率中有相当部分来自 45X 制造抵免（计入销售成本抵减）。Canadian Solar 的合并毛利还包含项目开发和储能业务。
  - **疑似取错列。** JA FY2025 归母净亏损 46.1 亿元与 FY2024 非常接近，请核对是否误取了比较期（C-Q8）。
- **建议：**
  - H3 改判为 "Supported for the sampled companies"；也可以另加一个更有信息量的可检验点，例如"利润压力在上游比下游更重"，LONGi 硅片 −14.31% 对组件 6.27%、Daqo −20.7% 可作初步证据。
  - 从 H3 证据中删去 ERCOT 收入分解；更对口的证据是分环节毛利率的时间序列。
  - 正文表只加一列不受币种影响的比率（净利率）和一句"范围"总结，其余比率放附录（各审读人一致认为表不宜变宽）。用报告数字可算出：Trina −10.5%、JA −9.4%、Tongwei −11.4%；资本开支同比 Trina −64.9%、JA −57.4%、Tongwei −54.0%、Jinko −64.9%。不要给中位数（D）。
  - 表注补三句：First Solar 等的毛利 "may include U.S. manufacturing credits"；幸存者偏差；美股上市主体与其 A 股子公司口径不同（C-S9）。
- **正文例句：**
  - *"All three A-share producers lost about 9–11% of revenue in FY2025, and most Chinese producers in the panel cut factory investment by more than half, while industry output stayed high. That is enough to say high output and weak profits coexisted; it is not enough to say why."*
  - *"First Solar's margins include U.S. manufacturing tax credits and reflect a protected U.S. market; they show what policy support is worth, not how efficient Chinese factories are."*
  - *"The panel covers large listed producers that are still reporting; smaller firms that exited are not included, so industry-wide distress is likely understated."*

【正文可直接加入；核对过程和其余比率建议放附录】

### 10. 计量部分：正文只留白话结论，方法移到附录；分解表改用能加总的均值
**来源：D-T3 + D-T5 + D-S1–S4 + A-6；A、B、C 都支持把技术内容移出正文**
**位置：** 第 25–27 页 8.6–8.8；第 38–39 页 11.6–11.7、表 11-2；第 52 页表 B-1

- **问题：**
  - **回归的反向因果没有点明（D-T3）。** 回归用的系统光伏出力是负电价时减发之后的实际值，存在"电价影响出力"的反向关系，负电价模型受影响最大。
  - **系数区间口径不一。** 区间 "−2.7 到 −3.8" 混入了一个含平方项和交互项的系数（S4 的 −3.45），它不是可比的边际效应。
  - **年度系数不能读成"压价作用在减弱"。** 从 −8.4 降到 −1.9，更可能是不同年份处在价格曲线的不同位置。
  - **表与表对不上账（D-T5）。** 用表 10-2 推算的 2023→2024 变化是 −181.4，表 B-1 写 −190.6；2024→2025 是 +0.3，表 B-1 写 +6.0。原因是中位数不能相加。NPV 与首年收入呈直线关系，所以跨节点均值可以精确相加。
  - **两套分解对客户负担过重。** Shapley 和 LMDI 同时出现在正文和附录。
  - **预测检验的设定没有交代（D-S1）。** 包括固定效应在预测年怎么处理、基准怎么算；"RMSE 不如常数"主要反映 2025 年价格水平漂移，不只是模型形状的问题。
  - **基差持续性需要参照系（D-S3）。** "节点身份解释 83.4%"应与随机噪声下约 33% 的基准相比；"年份只占 0.4%"大体是基差定义本身造成的。
  - **块自助法的构造没有交代（D-S4）。** 包括出力和电价是否成对抽样、是否按季节分层。
- **建议：**
  - 8.6–8.8 合并成 3 句白话；回归规格、代理变量、反向因果、logit 不收敛、HAC 和块自助的设定都放到新增的附录 B.4；图 8-4 移到附录。
  - 8.7 的正文改用"负电价从夜间移到中午"这一图 8-5 上已经能看到的事实（A-6）。
  - 正文只保留一张用均值、带"合计"列的分解表，正文中不出现 Shapley、LMDI 这两个词。
- **正文例句：**
  - *"In otherwise similar hours, the benchmark price was typically $2–4/MWh lower for each GW more system solar. The link was strongest in 2023 and weaker since. Solar plants turn down when prices are very low, which can make the link look stronger or weaker than it really is, so the numbers are descriptive."*
  - *"A model fitted to 2023–2024 predicted 2025 hourly prices worse than simply using a constant, mainly because 2025 prices were much less spiky. This report does not use these estimates to forecast prices."*
  - *"In 2023 negative prices mostly occurred overnight, when wind output was high; by 2025 they had shifted to midday, when solar output peaks."*
  - *"Nodes that were cheap relative to the system in one year were usually cheap in the others, but large transmission additions in West Texas could reshape these differences during a project's life."*（合并 A-8 与 D-S3。）
  - 分解表下：*"This is an accounting split of the change, not a list of causes. Averages are used because they add up exactly."*

【建议放附录（正文 3–4 句白话）】

### 11. 发电量模拟需要与实际电站对照
**来源：A-4；D 补充了影响的量级**
**位置：** 第 29 页 9.2–9.3；附录 B.2

- **问题：**
  - 33.38% 的交流容量因子（292.4 GWh ÷ 876 GWh）来自软件默认损失（14.0757% 正是 PVWatts 的默认总损失），没有和任何实际电站对照。〔外部知识，需核对〕西德州单轴跟踪电站的实际容量因子多在约 27–32%。
  - 发电量每低 10%，NPV 约少 1,000 万美元（D）。
- **建议：**
  - 9.3 加一句对照，数据可用 EIA-923 中同县电站的月度发电量；如果第 6 条推断成立，Taygete 电站本身就是最好的对照。
  - 如果本版不做对照，就在 9.3 明说"未与实际电站校准"。
  - 方法放附录。
- **正文例句：**
  - *"For context, operating tracking plants in Pecos County reported annual capacity factors of about X–Y% in 2023–2025. Our simulated 33.4% assumes bifacial modules and software-default losses, and has not been calibrated to any operating plant."*

【正文可直接加入；方法建议放附录】

### 12. 清理客户版里的内部内容和编辑残句
**来源：全体（A-21–A-24、B 编辑 1–4、C 编辑、D-E 系列）**
**位置：** 见第四部分清单

- **问题与建议：**
  - 附录 E（标着 "internal"，内容包括 59 blocked 字段、13 项 prohibited outputs、"不授权出版、销售"等）整体移出客户版。
  - 附录 A、B 中的内部文件路径和纠错历史（例如 "757 points (R2 count; incorrect…)"）移到内部技术附件。
  - "not disclosed in this edition" 只在 1.3 说一次。
  - 正文中的内部变量名（node_base、gw_curt 等）改成白话名称，例如 "nodal base case"。
  - 统一做一次人工通读校对。

【正文可直接加入】

---

## 二、其余意见（按审读人分组）

### A 组：ERCOT 市场（专家 A）

| 编号 | 位置 | 意见 | 可读性 |
|---|---|---|---|
| A-9 | 第 19–20 页 6.5–6.6 | 正文说明 238.6 GW 申请量为何远大于实际需求，例如同一客户多地重复申请。WLPUN 给一句白话："large loads behind a private network with their own generation—'bring-your-own-power' data centres"。〔外部知识，需核对〕德州 SB 6 对大负荷的接入要求放附录，并注明"截至某日的实施状态"（B 无法确认最新进展）。 | 需白话改写 |
| A-10 | 第 43 页 12.5 | 储能假设的结论把 "Not testable" 改为 "Not yet tested"。附录可选做一个"完美预见下的储能套利上界"，标题必须写明是上界（D）。 | 正文可直接加入 |
| A-11 | 表 10-0；第 47 页 14.2 | 负荷快速增长而电价持平，客户会疑惑。正文加一句：*"Holding prices flat is a neutral anchor, not a view: faster load growth could raise prices, but solar and battery additions have so far pushed midday prices down."* | 正文可直接加入 |
| A-13 | 第 3 页表 1-1；第 24 页 8.2 | "实际售价"有 $22.13 和 $26.43 两个口径。全文选定一个主指标，另一个在 8.2 用一句白话解释：*"$22.13 is the average across everything the plant could produce; $26.43 is the average across what it actually sells after switching off at negative prices."* | 正文可直接加入 |
| A-14 + D-Q2/Q3 | 第 21、23、39 页 | 时间轴口径不统一（hour ending、hour beginning、固定 UTC−6），全部统一为当地时间。11.7 的 "hour indices 12–20 on a fixed UTC−6 clock" 改为 "roughly 1 p.m. to 9 p.m. local summer time"。"non-DST dates" 应改写为"剔除两个夏令时切换日"。11.6 指向 8.4 的交叉引用失效。 | 需白话改写 |
| A-16 | 第 24 页 8.2 | 正文一句："in ERCOT this happens through the plant's price offer, not a manual decision"。机制说明放附录。 | 建议放附录 |
| A-17 | 第 3 页 1.1 第 6 条 | 238.6 GW 和 5.8 GW 时间维度不同，改为 *"requests for connection by 2030 total 238.6 GW, compared with about 5.8 GW of large load already operating"*，客户才不会把两者相除。 | 正文可直接加入 |
| A-18 | 第 39 页 11.7 | $5,073/MWh 高于 $5,000 的报价上限，加脚注说明结算价可能含加价或拥堵分量，以免读者怀疑数据有误。 | 建议放附录 |
| A-19 | 第 33 页 10.7 | 发电侧的市场费用（代理费、预测偏差成本）在附录用一句脚注说明量级。 | 建议放附录 |
| A 回应 D | 附录 | 回归的燃气控制变量：西德州的 Waha 气价曾大幅低于全国价格，会影响西部节点基差。正文一句：*"West Texas gas has at times sold far below national prices, which can lower local power prices; the national gas price used here does not capture that."* | 正文一句，其余放附录 |
| A-24、A-25、A-26 | 第 15、24、29、31 页 | 内部变量名改为白话；"the sampled spatial sample" 改为 "the sampled cells"；图 8-1 标题改为 "Simulated output peaks when node prices are lowest and most often negative"。 | 正文可直接加入 |

### B 组：跨境贸易与美国政策（专家 B）

| 编号 | 位置 | 意见 | 可读性 |
|---|---|---|---|
| B-5 | 第 44–45 页 13.1；第 11 页 4.3 | 给制造商加一张 6 行的"美国买家合同核对清单"，每行一个白话问句：*"Who pays if a new tariff applies after signing? Who is legally responsible for paying duties at the border? Can the supplier document where the polysilicon came from? Can the supplier certify its ownership for U.S. tax-credit rules?"* 另外，C 建议 13.1 分成"纯设备供应商"和"设备 + 开发一体化企业"两段。 | 正文可直接加入 |
| B-4① | 第 16 页 5.6 | 〔外部知识，需核对〕P01 的标题 "Adjusting Imports of Polysilicon and Its Derivatives" 是 Section 232 程序的措辞，正文应写明法律依据。正文还应用一句白话说明价格下限与其他关税是否叠加、已签合同如何处理（见 Q3），细节放附录。产业角度的白话：*"this sets a price floor for covered imports; it does not change Chinese factory prices"*（C）。 | 需白话改写 |
| B-4②–⑥ | 第 16–17 页 5.6–5.7 | 以下全部放附录：$0.38/W 与 $0.29/Wdc 的口径差（年份、价格层级、PVSCM 是否已扣 45X）；海关价值不含关税和运费；2024 年有囤货、不是干净基期，建议主要对比年改用 2025；补电池（HS 854142）进口数据（C-S10 同见）；每件价值换算成假设瓦数下的每瓦区间（约 $0.16–0.26/W），写明"如果典型组件是 400–650 W"（D 的三个条件）。正文一句即可：*"Falling module imports partly reflect more modules being assembled in the U.S. from imported cells, not only lower demand."*（以数据支持为前提） | 建议放附录 |
| B-4⑦ | 第 17 页 5.7 | 来源国变化与措施时间线并列，用 "consistent with"，不写因果（A、C、D 同意）。正文：*"The shift in reported origins followed the sequence in which U.S. duties were extended to new countries; customs data alone cannot show how much was caused by them."* 附录放一张月度进口曲线，并用竖线标出各措施生效日。埃塞俄比亚、肯尼亚的数字先核对是否只是个别大额报关。 | 正文可直接加入 |
| B-S1 | 第 33 页 10.7a | 附录补一个发电量型抵免（PTC）示例。现值约 5,500–7,000 万美元，取决于负电价时是否发电（C 修正了出力口径）。带衰减的 10 年系数约为 7.77（D）。抵免费率请作者核实。有 PTC 时，线性恒等式要加一项与发电量成正比的项（D），8.2 的停发对比和分解表中的 "export rule" 项也不再直接适用。正文一句：*"A per-MWh credit could be worth more here than the investment-based example, and would also change when the plant chooses to stop exporting."* | 正文一句，其余放附录 |
| B-S2(a) | 10.7a | 用全部 CAPEX 作抵免基数可能偏高：并网成本中的电网侧升级费用通常不计入基数。附录注明。 | 建议放附录 |
| B-S3 | 第 7–9 页 3.3 | 美国新增 34 GW 是"可进入市场"一说最好的例子。正文：*"The U.S. added about 34 GW, but most of that market is largely closed to modules made in mainland China; access depends on where the product is made and who owns the factory."* | 正文可直接加入 |
| B-S5 + C-S12 | 第 42、47 页 | 表 14-1 增加"贸易与税收政策"一行，列出：AD/CVD 裁决、232 实施细则、财政部后续指引、海关扣货统计、分来源国进口（含电池）。 | 正文可直接加入 |
| B-S6 | 第 16 页 5.6；第 30 页 10.1 | 假设项目的组件可能在 2026 年 12 月 4 日价格下限生效之前就已入关，那时价格下限根本不适用；反过来，组件晚到又会同时碰上价格下限和抵免截止日。并入第一部分第 2 条的时间线表。 | 需白话改写 |
| B-Q1 + C-Q4 | 第 54 页 GAP-07；第 55 页术语表 | GAP-07 中的 "ITC" 指美国国际贸易委员会，而术语表把 ITC 定义为投资税收抵免，中等知识量的客户几乎一定会读错。贸易语境改写为 "USITC"，术语表两个都列。 | 正文可直接加入 |
| B-Q2 | 第 33 页 vs 第 49 页 | 正文写 "restricted foreign entities"，附录写 "prohibited foreign entity"，统一用后者。术语表加一句白话，并说明旧称 FEOC。 | 正文可直接加入 |
| B-Q3 | 第 16 页 5.6 | 正文一句说明已签合同是否可能被区别对待，细节放附录。 | 需白话改写 |
| B-Q5 | 第 17 页 5.7 | 正文一句：*"The country shown in customs data is the declared origin; trade-remedy rules may treat the same product differently."* | 正文可直接加入 |
| B-Q8 | 第 6 页 2.3 | 2.3 说政策部分要按"最终发布截止日"核对，但全文没有给出这个日期。封面或 5.6 写明 "Policy status as of [date]"。 | 正文可直接加入 |
| B 编辑 6 | 附录 D | 术语表补词条，每条一句白话：AD/CVD、Section 232/301/201、UFLPA、prohibited foreign entity、45Y/48E/45X、beginning of construction、placed in service、customs value、minimum import price、USITC。 | 正文可直接加入 |

### C 组：中国产业链与企业财务（专家 C）

| 编号 | 位置 | 意见 | 可读性 |
|---|---|---|---|
| C-S1 | 第 9 页 3.3 | 产量与装机之间 130 GW 的缺口，没有点出两个主要原因：组件产量是直流（DC）口径，而不少国家按交流（AC）口径统计装机；中国还大量出口硅片和电池。D 建议用反推临界值表述（588 ÷ 457.7 ≈ 1.28），避免读者把示例当成估计值，算式放附录。正文例句：*"Factories count modules in DC watts, while some countries count installed capacity in AC watts, which is lower for the same plant; China also exports large volumes of wafers and cells for assembly elsewhere. Differences in how capacity is counted could by themselves explain most of the gap."* | 需白话改写 |
| C-S2 | 第 9–10 页 4.1 | 只有产量，没有产能和开工率，而行业"内卷"的核心是产能远超需求。引入 CPIA 或 MIIT 的产能数据并注明口径，至少用一句白话说明产能远大于产量。 | 正文可直接加入 |
| C-S4 | 第 10 页图 4-1 | MIIT 原始页面"无法访问"，只用了地方转载版。〔外部知识，需核对〕原文的降幅可能是"超过"的措辞，而且还给了硅片、电池片两个环节的降幅（单人审读同见）。核对后在图中补全四个环节。 | 正文可直接加入 |
| C-S6 | 第 11–13 页 | 正文只用 "working-capital movements" 解释"亏损而经营现金流为正"，信息量太低。附录补减值、折旧两个数。正文一句：*"Much of the reported loss is write-downs of factories and inventory, which reduce profit but not cash."* | 需白话改写 |
| C-S7 | 第 11 页 | 补现金、有息负债、资产负债率（放附录），正文一句：*"For a buyer worried about warranty claims ten years out, the supplier's cash and debt position matter more than this year's margin."* | 正文一句，其余放附录 |
| C-Q1 | 第 13 页 4.6 | 4.6 说"还需要 FY2025 A 股年报"，紧接着 4.7 就加入了这些年报，前后矛盾。 | 正文可直接加入 |
| C-Q2 | 第 13 页 4.6 | 讨论了 LONGi 的开工率，却不给数字。要么给出公司自报值，要么删掉这一段。 | 正文可直接加入 |
| C-Q3 | 第 53 页 GAP-04 | GAP-04 写"七家公司"，表 4-2 有八家，请写明口径。 | 正文可直接加入 |
| C-Q7 | 第 13 页 4.7 | 写明通威光伏分部的收入，避免读者以为饲料业务稀释了光伏亏损。 | 正文可直接加入 |
| C-Q10 | 第 3 页导读表 | 制造商一行改为 "1, 4, 5 (incl. 5.6–5.7), 10.7, 13.1"；开发商一行也加上 10.7（B）。 | 正文可直接加入 |
| C-Q11 | 第 9 页第 4 章开头 | 第 4 章开头先讲结论和免责，后给数据，顺序别扭。改为一句白话导语：*"Chinese factories produced record volumes in 2024, but most producers in our sample lost money and cut investment by more than half in FY2025."* | 正文可直接加入 |
| C 回应 A | 第 14 章表 14-1 | 指标表加 "U.S. delivered module price index and lead times (subscription data)"。 | 正文可直接加入 |

### D 组：计量与定量方法（经济学家 D）

| 编号 | 位置 | 意见 | 可读性 |
|---|---|---|---|
| D-S5 | 第 41 页 11.9 | "三年等权混合"依赖一个任意设定的权重，建议改用一个更好懂的数："需要多少年像 2023 才能回本"。中位数粗算：(12.11 − 6.84) ÷ (18.56 − 6.84) ≈ 45%；参考节点约 48%。数值请按节点重算，附录注明"2023 型年份在 30 年里均匀分布"的假设。正文例句：*"For the median node, roughly half of all operating years would need 2023-like prices for the project to break even—and those prices formed under market rules that have since changed."*（后半句是 A 要求加上的。） | 正文可直接加入（数字需重算） |
| D-S7 | 第 34 页 10.8；第 51 页 B.2 | 线性恒等式复算无误（乘数 15.472，截距 187.32）。正文说 "affine"，附录说 "linear"，统一为白话 "a straight-line relationship"。注明它只适用于节点路线：固定价路线按名义价格计算会逐年贬值，不适用。 | 正文可直接加入 |
| D-Q1 | 第 3 页；第 39–40 页 | "median node's receipts" 会让人以为存在一个"中位数节点"，改为 *"for the typical node, the top 1% … account for about 55% of receipts"*。 | 正文可直接加入 |
| D-Q4 | 第 26 页图 8-4 | 图注提到 HAC 和块自助法的设定，但客户版没有任何地方写出来。补到附录 B.4，并说明标准误随滞后阶数上升、自助抽样丢弃了部分样本。 | 建议放附录 |
| D-Q5 | 第 26 页图 8-4 | 标签 "S1, hours ≥ $1,000 excluded" 改为 "S1 excluding hours ≥ $1,000"；S4 改画平均边际效应，或者用不同的标记区分。 | 正文可直接加入 |
| D-Q7 | 第 40–41 页图 11-5、11-6 | 正文引用的是跨节点中位数，旁边的图却是参考节点的结果，容易对照着读错。图标题直接写 "(reference node only)"。 | 正文可直接加入 |
| D-Q8 | 第 26 页 8.6 | "common sign across estimates" 读起来像多次独立验证，实际是同一份数据的不同切法，改为 "all specifications on the same data share the sign"。 | 建议放附录 |
| D-Q9 | 技术报告 | 技术报告第 6 节写 "the extra solar capacity … pushed the prices at midday down"，是因果措辞，与客户版"可能原因、未识别"的表述矛盾。建议同步修改技术报告。 | 不涉及客户版正文 |
| D-E3 | 第 26 页 | "−$3.1 in 2024, and −$1.9 in 2025" 缺单位。 | 正文可直接加入 |
| D-E4 | 第 40 页 11.8 | "23 hours" 一段与下一段重复，合并为一段，并补上节点间范围 "1–198 hours"。 | 正文可直接加入 |
| D-E5 | 表 10-2 | 表头 "Median lifetime NPV" 改为 "Median NPV (30-year repetition)"。 | 正文可直接加入 |
| D-E8 | 第 25 页 8.4 | 这一段对客户太密。改为：*"485 official generator pricing points with complete prices in all three years; the few intervals missing for every point are dropped for all."* | 需白话改写 |
| D-E9 | 附录 B.1 | 47.6 MWh 后补 "(0.017% of annual energy)"，让读者知道影响可以忽略。 | 建议放附录 |

---

## 三、审读人之间的分歧及处理建议

| # | 议题 | 各方观点 | 处理建议 |
|---|---|---|---|
| 1 | 税收抵免"悬崖"是否成立 | B 第一轮说"并网推迟一年就可能失去抵免"。A、D 指出〔外部知识，需核对〕"2027 年底前投运"只约束 2026 年 7 月初以后开工的项目，报告没有给出开工日期。B 第二轮同意，改为"两种情形"的写法。 | 已达成一致：正文按"按时开工投运 / 延误"两种情形写，并注明取决于开工日期（第一部分第 2 条）。 |
| 2 | 天气年份的 NPV 影响（约 1,200–1,300 万美元）要不要进正文 | D、C 认为它和组件降价示例同一量级，对制造商有用。A 反对：这个数混入了"天气与电价同步关系被切断"的效应，客户会误以为选天气年份和降低组件价格一样重要。B 支持做"同一把尺子"的表。 | 采纳 A：正文的"同一把尺子"表不列天气年份，改列"模拟发电量 ±10%"（约 ±10m，D 的计算，含义清楚）；天气年份的数字和解释放附录。 |
| 3 | "$24/MWh" 的含义 | A 第一轮把它写成买方要连续供电时需补上的价值"下限"。D 指出它是每 MWh 光伏电量的价值差，不是补足成本，更不是下限。A 接受修正。 | 正文写 "worth about $24 less than an average around-the-clock MWh"，删去 "floor"。 |
| 4 | "抵免约为组件降价收益的 3.2 倍"放在哪里 | B 建议写进正文。D 认为这是两个假设值相除，不是发现。 | 正文写 "several times larger in this example"，不放进执行摘要的数字列表。 |
| 5 | 海关每件价值能否说明 $0.38/W 价格下限"有约束力" | B 第一轮认为可以。C、D 指出：海关价值不含关税和运费；件数里混有小功率组件；数据早于下限生效日。B 第二轮同意收窄。 | 只放附录，措辞改为 "consistent with the floor being above recent declared values"。 |
| 6 | 8.9% 示例的问题是不是"重复计算" | C 担心 2025Q1 的基准价已部分反映 2024 年的降价，再套一次会重复扣减。B 认为问题不在算法，而在中国价格本来就不适用于美国价格。 | 正文只讲"中国价格不等于美国价格"；时点问题在附录一句带过。 |
| 7 | "重复单年价格形态"是否偏乐观 | D 认为光伏还在增长，午间电价更可能走弱，所以偏乐观。A 指出储能在中午充电会抬高午间价格，方向不能断言。 | 正文只写"假设机组构成和市场规则不变"，不断言方向（第一部分第 1 条）。 |
| 8 | 产量与装机缺口的 DC/AC 示例 | C 用报告电站的 1.32 算出缺口可能反向。A 指出 1.32 是单轴跟踪电站的比例，全球平均更低，会高估口径效应。D 建议改用反推临界值 1.28。 | 采用 D 的反推写法，放附录（第二部分 C-S1）。 |
| 9 | 发电量型抵免（PTC）的现值 | B 用潜在出力 290 GWh 算出 6,400–7,000 万美元。C 指出停发规则下的有偿出力是 247.8 GWh。D 给出带衰减的系数 7.77。 | 附录写区间"约 5,500–7,000 万美元，取决于负电价时是否发电"，费率请作者核实；正文不写具体数。 |
| 10 | 表 4-2 要加几列比率 | C 第一轮建议加 3 列并拆分毛利率。A、B、D 都认为表会太宽、太难读。 | 正文只加净利率一列和一句"范围"总结，其余放附录，不给中位数。 |

---

## 四、文字与编辑问题清单（四人合并）

| 页码 | 问题 | 修改 |
|---|---|---|
| 7、8、17、18、28 | 句首小写："the IRENA series…"、"the IRENA tables…"、"the Census analysis…"、"the non-DST-day sample…"、"the block includes…" | 改为大写，并全文排查同类问题 |
| 13 | "The spending measure is the under its filing definition" | "The spending measure follows its filing definition" |
| 16 | "The additional trade register is the as an evidence map" | "The additional trade register serves as an evidence map"（"trade register" 客户不知道指什么，建议重写） |
| 16 | 悬空的引注 "Federal Register, clauses 1–6" | 改为 [P01] |
| 19 | "125.4 GW is the only as the chart-labeled quantity" | "125.4 GW is used as the chart-labeled quantity" |
| 25 | "it is not a ranking as the third-percentile absolute revenue location" | "it does not mean the node is in the bottom 3% by absolute revenue" |
| 6 | "The manuscript distinguishes…" | "This report distinguishes…" |
| 8 | 图 3-2 内嵌注释的来源写作 "(R-D)"，而附录 A 中 R-D 是 EIA 和公司年报 | 改为 [S03] |
| 各图 | 图内注释与图下斜体来源重复，且内容略有出入 | 只保留一处 |
| 8 处 | "Underlying table: the corresponding source table" 是空占位 | 写出具体表名，或删除 |
| 11 | 表 4-2 表头 "Currenc y" 断词；负号 "−" 与 "-" 混用；小数位不统一；"Asset cash" 含义不清 | 统一格式；"Asset cash" 改为 "Capex (cash)" |
| 16、31、33 | 编号 "5.5a"、"10.7a"、"Table 10-0" | 重新连续编号 |
| 48–49 | 附录 A：S08 与 S10 重复；P04 与 R-A 重复；三份 "Form 20-F" 没写公司名；R-D 把 EIA 数据和公司年报混为一族；只写 "official source"，客户无法追溯；使用内部目录 ID | 改为可读的书目格式，写出公司名和 URL |
| 49–51 | 表 A-1 和附录 B 中的内部文件路径、"757 points (R2 count; incorrect…)" | 移到内部附件 |
| 53–54 | 附录 C 多处 "incorporated below" 指向不存在的下文；"legacy identifiers"、"editorial integration"；GAP-06 的 "AC-denominator inconsistency" 从未解释 | 改写成客户能读的研究局限清单 |
| 55 | 术语表中 HB_BUSAVG "not disclosed"；ITC 只有一个含义；WLPUN 没有白话解释 | 见第一部分第 6 条、第二部分 B-Q1、A-9 |
| 56 | 附录 E | 整体移出客户版 |
| 全文 | 限定语过密：粗略统计 "not a" 43 次、"does not" 34 次、"conditional" 29 次 | 通用限定交给 Box 1 和各章 Limits 框，正文只保留与该段结论直接相关的限定 |

---

## 五、复算核对与数字修正

**报告数字复算一致**（A、B、C、D 和汇总人分别复算）：

| 项目 | 算式 | 结果 |
|---|---|---|
| 组件传导 | 0.261 × 1.144 × 0.297 | 8.87%；143.67 × 8.9% = 12.79m；12.79 ÷ 85.97 = 14.87% |
| 容量因子 | 292.4 ÷ 876 | 33.38% |
| 售价 | 6.551 ÷ 247.8；6.471 ÷ 292.4 | $26.44；$22.13 |
| 线性恒等式 | 乘数 Σ 0.993^(t−1) ÷ 1.0427^t | 15.472 |
|  | 截距 143.67 + 40.99 + 1.79 + 0.86 | 187.32 |
|  | 15.47 × 6.551 − 187.3 | −85.96 |
|  | 15.47 × 18.56 − 187.3 | +99.8 |
|  | 门槛 187.3 ÷ 15.47 | 12.1 |
| 折现率 | (0.065 × 0.7457 + 0.080 × 0.2543 + 1) ÷ 1.025 − 1 | 4.27% |
| 节点保本 CAPEX | (143.67 − 85.97) ÷ 100 | $577/kWac |
| 价格乘数 | 12.1 ÷ 6.55 | 1.85 |
| ±20% 敏感性 | 0.2 × 143.67；0.2 × 6.55 × 15.47 | ±28.7；±20.3 |
| fixed_upside 首年实际价 | 48 ÷ 1.025² | $45.69 |
| 尾部压力 | 482 ÷ 485；18.56 × (1 − 0.547) × 15.47 − 187.3 | 99.4%；≈ −57 |
| 负电价时段占比 | 2,189 ÷ 35,038 | 6.25% |

**需要修正或补充的数字：**

| 项目 | 现状 | 建议 | 来源 |
|---|---|---|---|
| 10.7a 抵免现值 | 41.34m | 40.33m；node_base 约 −45.6m，保本价约 $51.8 | B 提出，D 核实 |
| 2023、2024 年电价美元口径 | 未说明 | 写明；如果未换算，2023 年 NPV 约低 16m | D-S6 |
| 表 10-2 与表 B-1 的总变化 | −181.4 对 −190.6；+0.3 对 +6.0 | 改用均值，可精确加总 | D-T5 |
| 固定价保本价（无不付费电量） | 未给出 | 约 $56/MWh | 汇总人 |
| 组件免费时的 CAPEX 和 NPV | 未给出 | 约 $1,008/kWac，NPV 约 −43m | A |
| 抵免下组件降价的净收益 | 12.79m | 约 9.1m | B、C、D |
| 负电价时段均价 | 未给出 | 约 −$1.8/MWh | A |
| 99.9 分位封顶；剔除日期的天数和收入占比 | 未报告 | 所有节点仍为正；34 天、65% | D-T4（来自技术报告） |
| JA FY2025 归母净亏损 | 46.1 亿元 | 核对是否取了 FY2024 列 | C-Q8 |

---

## 六、给修订者的可读性守则（四人共识）

1. **正文一句白话，附录详述。** 推导、口径、法条、回归设定、分解方法一律放附录。
2. **缩写不进正文。** ECRS、ORDC、RTC+B、HCAP、MPF/HMF、MACR、LMDI、Shapley、HAC 这些词，正文用白话描述，缩写只进附录和术语表。必须保留的缩写（AD/CVD、PPA 等）在第一次出现时给一句白话。
3. **每个数字配一句"这对你意味着什么"。** 第一部分的例句可以直接套用。
4. **执行摘要每条只放一个数字。** 多种压力测试、多种口径的对比放到正文相应章节。
5. **一章一个限定框。** 正文不重复"不是预测""不是资产估值"这类通用限定。
6. **表格不加宽。** 新增比率最多一列，其余放附录。
7. **改完后请一位中等知识量的读者通读执行摘要、第 5、10、11、13 章**，确认新增内容不需要查术语表也能读懂。

---

## 七、需作者核对的外部知识清单

以下内容来自审读人的行业知识，引用前必须用原始来源核实：

- **美国税法：** 2025 年联邦税法修订对 45Y/48E 的开工和投运期限；Notice 2025-42 的开工认定方式；外国实体规则对设备和业主两个层面的限制；PTC 费率与通胀调整。
- **贸易措施：** 东南亚四国 AD/CVD 终裁；印尼、老挝、印度的新案；Section 301 的调整；Section 201 是否到期；IEEPA 关税的法律状态；P01 是否属于 Section 232，以及它与其他关税是否叠加。
- **ERCOT 市场：** 2023 年的紧急事件；储能装机规模；2025 年 12 月实时稀缺定价规则变化的具体内容；HB_BUSAVG 的正式定义；TAYGETE2_ALL 对应的电站；西德州实际容量因子区间；虚拟 PPA 的合同惯例；Waha 气价折价；德州 SB 6 的要点和实施状态；关键基础设施相关州法。
- **中国产业链：** MIIT 2024 年原文措辞（"超过"与否，以及硅片、电池片的降幅）；MIIT 或 CPIA 2025 年数据；"反内卷"、出口退税、136 号文的具体内容；中资企业美国工厂的股权变化；First Solar 的 45X 会计处理；Canadian Solar 的业务构成；美股上市主体与 A 股子公司的持股关系。
