"""Create a local author-handoff archive; never publish or send."""
from pathlib import Path
import csv,hashlib,zipfile
D=Path(__file__).resolve().parents[1]
def files():
 return sorted(p for p in D.rglob('*') if p.is_file() and not any(x in p.parts for x in ['__pycache__','.mplcache']) and not p.name.startswith('.DS_Store'))
rows=[]
for p in files():
 if p.name in ['File-Manifest.csv','SHA256SUMS.txt']:continue
 rows.append([p.relative_to(D).as_posix(),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
with (D/'File-Manifest.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['path','bytes','sha256']);w.writerows(rows)
(D/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(D).as_posix()+'\n' for p in files() if p.name!='SHA256SUMS.txt'))
out=D.with_suffix('.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files():z.write(p,arcname=D.name+'/'+p.relative_to(D).as_posix())
Path(str(out)+'.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print(out,len(rows),'payload files',out.stat().st_size,'bytes')
