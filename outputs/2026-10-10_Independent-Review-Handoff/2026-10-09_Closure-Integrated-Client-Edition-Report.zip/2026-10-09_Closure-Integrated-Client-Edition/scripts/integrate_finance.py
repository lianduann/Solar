"""Integrate frozen finance evidence; arithmetic and rendering only. No estimation."""
from pathlib import Path
import json, hashlib
import pandas as pd
import numpy as np
import chart_theme as th
D=Path(__file__).resolve().parents[1]; out=D/'data/finance';out.mkdir(exist_ok=True)
f=D/'finance-supplement'; z=json.loads((D/'data/panel/Panel-Calculations.json').read_text())
m=pd.read_csv(D/'data/scenario_metrics.csv').set_index('scenario_id');cf=pd.read_csv(D/'data/scenario_annual_cash_flows.csv');be=json.loads((D/'data/breakevens.json').read_text());r=.0427
credit=z['credit_pv']*z['occ']/z['capex']; gain=3500000/(1+r)**16
fc=cf[cf.scenario_id=='fixed_base'];slope=float((fc.revenue_real/40/(1+r)**fc.t).sum())
calc=dict(occ=z['occ'],gcc=z['gcc'],capex=z['capex'],old_credit_pv=z['credit_pv'],occ_credit_pv=credit,credit_reduction=z['credit_pv']-credit,node_with_occ_credit=float(m.loc['node_base','npv_real_selected'])+credit,fixed_with_occ_credit=float(m.loc['fixed_base','npv_real_selected'])+credit,break_even_with_occ_credit=be['fixed_breakeven_price_nominal_flat_at_0.0427']-credit/slope,reserve_removal_pv=gain,node_without_reserve=float(m.loc['node_base','npv_real_selected'])+gain,fixed_without_reserve=float(m.loc['fixed_base','npv_real_selected'])+gain)
shares=[0,be['negative_price_energy_anchor'],2*be['negative_price_energy_anchor']]
paid=pd.DataFrame({'unpaid_share':shares,'flat_nominal_breakeven_usd_mwh':[z['no_unpaid_breakeven']/(1-s) for s in shares]});paid.to_csv(out/'Unpaid-Energy-Stress.csv',index=False)
a=pd.read_csv(f/'data/EIA-Operating-Generation-Comparables.csv');b=a[(a.county=='Pecos')&(a['flags']=='clean full-year standalone PV')];rows=[]
for year in [2024,2025]:
 for label,g in [('All tracking types',b[b.year==year]),('Tracking Y',b[(b.year==year)&(b.tracking=='Y')]),('Tracking Y; Emerald excluded',b[(b.year==year)&(b.tracking=='Y')&(b.plant_id!=63233)])]:
  rows.append(dict(year=year,cohort=label,n=len(g),minimum=g.annual_capacity_factor_ac.min(),median=g.annual_capacity_factor_ac.median(),maximum=g.annual_capacity_factor_ac.max()))
cohort=pd.DataFrame(rows);cohort.to_csv(out/'EIA-Cohort-Reconciliation.csv',index=False)
g=b[(b.year==2025)&(b.tracking=='Y')].sort_values('annual_capacity_factor_ac');g.to_csv(out/'EIA-2025-Tracking-Chart.csv',index=False)
compar=pd.read_csv(f/'Comparable-Projects.csv');cost=pd.read_csv(f/'data/Finance-Arithmetic-Checks.csv');ids=['C-1377-ac','C-1519-ac','C-1431-ac','C-1451-ac','C-1463-ac'];cost=cost[cost.check_id.isin(ids)].copy();cost['project']=cost.check_id.map({'C-1377-ac':'Taygete II','C-1519-ac':'Emerald Grove','C-1431-ac':'Galloway 2','C-1451-ac':'Concho Valley','C-1463-ac':'Prospero II'});cost.to_csv(out/'Qualified-Investment-Comparisons.csv',index=False)
(out/'Finance-Integration-Calculations.json').write_text(json.dumps(calc,indent=2)+'\n')
th.apply();fig,ax=th.newfig(4.8);labels=[n.replace(' Energy Project','').replace(' Solar Project','')+(' *' if pid==63233 else '') for n,pid in zip(g.plant_name,g.plant_id)];ax.barh(labels,g.annual_capacity_factor_ac*100,color=th.TEAL);ax.axvline(33.38,color=th.AMBER,ls='--',label='Simulated potential 33.38%');ax.axvline(28.29,color=th.NAVY,ls=':',label='Simulated delivered 28.29%');ax.set_xlim(0,38);ax.set_xlabel('Annual AC capacity factor (%)');ax.legend(loc='lower right',fontsize=7);th.finish(fig,D/'figures/Finance_Operating_CF.png','Operating output provides a check on the simulated profile','2025 | EIA-record Pecos cohort | standalone PV, tracking Y | * county conflict')
th.apply();fig,ax=th.newfig(3.3);c=cost.sort_values('result');ax.barh(c.project,c.result/1000,color=th.NAVY);ax.set_xlabel('Self-reported qualified investment / 2025 AC capacity ($/Wac)');ax.set_xlim(0,1.25);th.finish(fig,D/'figures/Finance_Qualified_Investment.png','Public investment filings cover a narrower scope than total project cost','Mid-2023 filings | nominal dollars | five selected plants | not IRR or all-in CAPEX')
(D/'support/Finance-Chart-Snapshots.json').write_text(json.dumps(th.SNAP,indent=2))
text=(D/'Integrated-Market-Research-Report-EN_Panel-Revised.md').read_text()
baseline=text
def replace(old,new):
 global text
 assert old in text,old[:120]
 text=text.replace(old,new)
def section(start,end,new):
 global text
 i=text.index(start);j=text.index(end,i);text=text[:i]+new.strip()+'\n\n'+text[j:]
replace('Panel-revised research edition','Finance-integrated research edition')
section('The fiscal sensitivity in Chapter 10','## 1.2',f'''The revised credit illustration excludes the national grid-connection-cost component from the assumed basis. Its present value is **${credit/1e6:.2f}m**, leaving reference-node NPV at **−${abs(calc['node_with_occ_credit'])/1e6:.2f}m**. Eligibility remains unproven; the six original pre-tax scenarios are unchanged. Public records for nine named ERCOT plants disclose no definition-matched IRR or cash flows. The financial conclusions therefore remain scenario-based, with operating-output and cost comparables used as diligence checks rather than return benchmarks. [F01–F05]''')
section('TAYGETE2_ALL is the historical price reference','**Table 8-1.', '''TAYGETE2_ALL is the historical price reference inherited by this study. ERCOT's resource-node mapping associates it with TAYGETE2_UNIT1/UNIT2 at substation TAYGETE2. ERCOT's resource list identifies two 101.9 MW units in Pecos County, West zone, with a 2023 in-service year. Their combined 203.8 MW, name, county and year match EIA plant 64075, Taygete II Energy Project: 203.8 MWac / 258.4 MWdc, single-axis PV, first in service July 2023. EIA names West Texas Solar Project II LLC, also identified in Comptroller agreement #1377. [F01]

The ERCOT-to-EIA step is an **attribute match, not an official crosswalk**. The records now support a same-county operating-plant reference, but the original node-selection rationale is not disclosed in this edition. The hypothetical 100 MWac system is not Taygete II, and its settlement rights at this node remain unestablished. The 2025 series provides 35,038 of 35,040 expected intervals. Its time-weighted price is $46.37/MWh and potential-generation-weighted price $22.13/MWh, before the negative-price response. [S06, S07]

The current owner's 2025 filing reports a senior-lender-initiated foreclosure purchase after the previous owner failed to repay its loan. This is direct evidence of a financing event at the matched plant; it supplies neither an IRR nor the cause or scale of any investor loss. [F02, physical PDF p. 1, Section 2.7]''')
section('> **Location research pending — FIN-06.','The result demonstrates', '> **Location research partly addressed — FIN-06.** The current resource-unit mapping and plant attributes are documented. An official ERCOT–EIA crosswalk, historical identity/version chain and the hypothetical site’s actual settlement agreement remain missing. Hub prices remain comparison benchmarks.')
section('> **Performance research pending — FIN-02.','# 10.', '''## 9.5 Operating-plant evidence: a plausibility check, not calibration

The finance supplement joins EIA-923 net generation with EIA-860 plant design and capacity records. The retained table's county field defines an **EIA-record Pecos cohort**. The full-year standalone screen excludes hybrid sites, partial years, multi-unit aggregates and annual respondents. A separate tracking-Y screen corrects the supplement narrative's conflation of all standalone plants with tracking plants. [F03]

**Table 9-2. Operating AC capacity factors under explicit sample definitions.**

| Year | Screen | Plants | Median AC capacity factor |
|---|---|---:|---:|
'''+ '\n'.join(f"| {int(q.year)} | {q.cohort} | {int(q.n)} | {q['median']*100:.1f}% |" for _,q in cohort.iterrows())+'''

*Source: frozen EIA comparison table [F03]; arithmetic re-screening in data/finance/EIA-Cohort-Reconciliation.csv. Annual generation / (2025 recorded MWac × calendar hours); 2024 includes 8,784 hours. Full-year/COD screening does not independently establish every historical nameplate denominator.*

![Figure 9-1. 2025 operating capacity factors and simulated output](figures/Finance_Operating_CF.png)

*Source: EIA-860/923 comparison outputs [F03]; scenario design [S07]. Emerald Grove is classified as Pecos in the retained EIA record but Crane in ERCOT/Comptroller records; the table reports the result with that plant excluded. Other observed differences in technology, design, availability, curtailment and weather remain uncontrolled.*

The broader standalone cohort has medians of 24.8% in 2024 and 24.6% in 2025; restricting it to tracking Y gives 23.8% and 25.0%. The simulated 2025 potential factor of 33.38% exceeds every observed plant in these screened cohorts. Its 28.29% delivered factor falls within the 25.5%–29.7% range for the three 2023–2024-COD examples in the supplement: Taygete II, Emerald Grove and Greasewood II. That overlap does not validate the simulated system. Net operating generation and potential simulated output have different loss and operating boundaries, and the observed values are not weather-normalized.

> **Performance research partly addressed — FIN-02.** Actual generation now supplies a benchmark. Reconcile same-year capacity, technology, losses, availability, forced and economic curtailment, geographic discrepancies and metered delivery before calibrating output. P50/P90 remain unavailable. The existing shape-preserving 10% export sensitivity adds about $10.14m to NPV with costs unchanged; it is not a calibrated forecast.
''')
section('> **Contract research pending — FIN-03.','## 10.4', '''**Paid-volume stress.** Holding the existing contract cash-flow shape and costs fixed, the flat nominal break-even is $55.91/MWh at zero unpaid energy, $65.97/MWh at the 15.24% base share, and $80.43/MWh at 30.48%. The last value is arithmetic scaling of paid volume, not a new dispatch or contract simulation. Uniform unpaid shares are stress parameters, not observed contract clauses. [F04; data/finance/Unpaid-Energy-Stress.csv]

**A hub hedge requires two revenue legs.** For metered generation G, hedge quantity H and strike K, the simplified interval identity is G × node price + H × (K − hub price) + REC proceeds − fees. If H = G and the same metered volume enters both legs, energy value reduces to G × (K + node-minus-hub basis). Fixed-shape H, shutdown provisions and losses break that simplification. A hub hedge transfers price and shape exposures; substituting hub prices for node receipts does not model the hedge.

The output-weighted reference-node-minus-West basis is −$0.05, +$0.25 and +$0.67/MWh for 2023–2025. West hub weighted prices are $64.94, $20.60 and $21.46/MWh, with capture ratios 1.30, 0.75 and 0.65. Small annual weighted basis does not establish small interval basis or low contract risk. [F04]

A lender release identifies a long-term J. Aron hedge for part of Taygete I output and another rated purchaser. The supplement also retains a secondary description of a fixed-shape corporate product for the Taygete project. Neither source supplies a complete executed contract. Price, tenor, settlement point, negative-price clauses and REC ownership remain not disclosed in this edition. No indicative offer is treated as a comparable transaction. [F05; finance-supplement/Contract-Terms.csv]

> **Contract research partly addressed — FIN-03.** Contract structures and the cash-flow identity are documented; executed terms and a dated merchant-tail assumption remain missing. Proposed 10-/15-year VPPA routes require a separately labeled calculation version. No full-life contract IRR or merchant-tail NPV is assigned here.''')
section('> **Cost research pending — FIN-05.','## 10.8',f'''**Limited-scope cost observations.** Nine named comparables comprise eight standalone PV plants and one storage-hybrid site; two standalone plants entered service in 2021 and are earlier-vintage references. Five selected Comptroller filings imply $0.92–$1.10/Wac of self-reported qualified investment. These are mid-2023 nominal amounts divided by 2025 recorded capacity, with COD/reporting inconsistencies and possible later spending. Qualified investment excludes land and property outside the applicant’s qualifying ownership scope and does not reconcile every soft or financing cost. The figures are neither all-in construction prices nor a return range. [F01, F04]

![Figure 10-3. Selected qualified-investment observations](figures/Finance_Qualified_Investment.png)

*Source: Comptroller Form 773 amounts and EIA capacity in the frozen supplement arithmetic [F04]. Narrow reporting scope and mismatched vintages preclude replacing the $1.437/Wac national scenario input. The five selected comparisons exclude zero-spend and clearly incomplete construction cases; other supplement observations remain separately documented.*

**Replacement accounting.** PVSCM itemizes annualized component replacement alongside land, insurance, property and administration expenses. The supplement infers its linkage to ATB from ATB citations; it does not yet reconcile the exact FOM vintage and component amount used here. The year-16 reserve therefore remains in the frozen baseline. A separate accounting variant removes only the $3.5m real reserve, improving either base NPV by **${gain/1e6:.2f}m** at 4.27%: node **−${abs(calc['node_without_reserve'])/1e6:.2f}m**, fixed **−${abs(calc['fixed_without_reserve'])/1e6:.2f}m**. This arithmetic sensitivity identifies the scale of possible overlap without asserting that the entire reserve is duplicated. [F04]

**ERCOT connection-cost allocation.** Under 16 TAC §25.195(f), a generator pays its step-up transformers and protective devices. For SGIAs executed after 31 December 2025, transmission-provider interconnection-facility funding is capped at an allowance: $14m at or below 138 kV and $20m above 138 kV in the 2024 base, indexed annually by CPI. The applicable allowance is fixed at the generator’s notice-to-proceed date; costs above it are billed to the generator. Defined shared system upgrades remain the transmission provider’s responsibility, while connection substations are not treated as shared upgrades. [F06]

These allowances are not deductions from the national $17.63m GCC input. The facility scope, voltage, agreement date and ownership of the hypothetical connection are unverified. Likewise, a generic PVSCM network line cannot be removed from ATB GCC before a component match. Site-specific property tax should replace or reconcile the embedded allowance, not be added in full to unchanged FOM.

> **Cost research partly addressed — FIN-05.** Public cost definitions and the ERCOT allocation rule now constrain diligence. Reconcile the exact ATB/PVSCM vintage, replacement coverage, site tax and insurance, generator/TSP scope, EPC, owner and financing costs before changing the baseline budget.''')
section('## 10.8 Tax timing:','## 10.9',f'''## 10.8 Tax timing and basis: a revised illustration, not an entitlement

The six baseline scenarios remain pre-tax and unlevered. The revised illustration applies an assumed 30% rate only to **$126.04m of national PV overnight cost (OCC)**, excluding $17.63m GCC from the assumed basis. With the prior timing convention—2026 nominal basis, unchanged nominal receipt at end-2027, 2025-dollar deflation and one-year discounting at 4.27%—the credit PV is **${credit/1e6:.2f}m**. Node-base NPV becomes **−${abs(calc['node_with_occ_credit'])/1e6:.2f}m**, fixed-base NPV **−${abs(calc['fixed_with_occ_credit'])/1e6:.2f}m**, and fixed-route break-even **${calc['break_even_with_occ_credit']:.2f}/MWh**. No benefit is inserted into the original six scenarios. [F04]

The earlier full-CAPEX illustration produced $40.33m PV. Excluding GCC reduces it by ${calc['credit_reduction']/1e6:.2f}m. This is a conservative boundary for an unresolved national aggregate, not a determination that every OCC item qualifies or every generator-owned connection asset is ineligible. The special qualified-interconnection-property provision of section 48E applies only to facilities no larger than 5 MWac; it does not establish eligibility for this 100 MWac setting. [F07]

**Table 10-3. Timing branches requiring project evidence.**

| Construction and service facts | Timing interpretation | Treatment here |
|---|---|---|
| Construction begins on or before 4 July 2026 | Outside the new end-2027 termination branch, subject to other requirements | No qualifying start evidence supplied |
| Construction begins after 4 July 2026; service by 31 December 2027 | Service cutoff may be satisfied | Illustrative late-start route; schedule unverified |
| Construction begins after 4 July 2026; service after 31 December 2027 | Relevant wind/solar termination applies | No credit assumed |

*Source: P.L. 119-21 sections 70512/70513 [F07]. Payment at end-2026 is not evidence of actual construction commencement. The early-start branch remains available for evaluation if supported by qualifying contemporaneous records.*

A retained District Court opinion dated 6 June 2026 vacates Notice 2025-42 in full and remands it to the IRS. Current appeal, stay and subsequent-guidance status are not established in this edition; the vacated notice is not treated as controlling guidance. Construction-start methods and continuity require current legal review before assigning eligibility. [F08, physical PDF pp. 1, 57]

For facilities beginning construction after 2025, the material-assistance test includes a cost-ratio threshold of 40% for a 2026 construction start and 45% for 2027. These are the defined material-assistance cost ratios, not percentages of module origin or a generic permitted foreign-content share. Taxpayer ownership/control, supply-chain tracing and the applicable safe-harbor rules also matter. [F07; F09]

The 30% rate, wage/apprenticeship compliance, qualified basis, transfer price, cash timing and recapture exposure remain assumptions or missing inputs. An eventual after-tax model must reflect the section 50(c)(3) basis reduction—half the credit—as well as depreciation and other taxes. This edition does not claim the illustration is a complete after-tax NPV. [F07]

> **Tax research partly addressed — FIN-04.** Statutory timing and a more conservative illustrative basis are integrated. Establish construction/service facts, current litigation/guidance status, eligibility, ownership/material assistance, credit rate and monetization before valuation. Compare ITC/PTC only on consistent, supported after-tax cash flows.''')
section('> **Comparable-return and currency research pending — FIN-01 / FIN-07.','The 13 positive', '''**Comparable returns remain undisclosed.** None of the nine named projects in the retained panel reports a comparable project or equity IRR or project-level cash-flow series. A loan amount, investment filing and foreclosure event each answer a different question. They supply no defensible “typical solar IRR” interval. The ATB 6.5% nominal debt and 8.0% equity assumptions equal 3.90% and 5.37% real at 2.5% inflation, respectively; they remain reference inputs, not observed investment returns. The model retains its previously specified 4.27% real convention without silently replacing it with a differently rounded rate. [F01, F04]

> **Comparable-return and currency research partly addressed — FIN-01 / FIN-07.** Named projects and return-definition limitations are documented. A separate CPI-consistent price-year version would scale the 2023 and 2024 nominal price levels by 1.056583 and 1.026313 to 2025 dollars. That version is not implemented here; the frozen empirical results remain unchanged. Actual return terms and matched investor risk/hurdles remain not disclosed in this edition.''')
replace('| Illustrative nominal 30% credit | +40.33 | Same reference; assumed eligibility and end-2027 cash receipt |',f'| Illustrative 30% credit, OCC-only basis | +{credit/1e6:.2f} | Same reference; eligibility unproven; end-2027 receipt; not complete after-tax DCF |')
replace('Illustrative $40.33m credit benefit is conditional, not an entitlement',f'Illustrative ${credit/1e6:.2f}m OCC-basis benefit is conditional, not an entitlement')
# Retain the complete original scenario input table and cash-flow example.
i=baseline.index('**Table 10-1.');j=baseline.index('## 10.4',i)
replace('## 10.4 Scenario results',baseline[i:j]+'## 10.4 Scenario results')
refs='''## A.1 Finance-deepening evidence integrated on 9 October 2026

- **[F01]** Finance supplement, Comparable-Projects.csv and Entity-Node-Mapping.csv; ERCOT NP4-160, MORA resource records and EIA-860 design/capacity records. The ERCOT–EIA plant link is attribute-matched; source locators are in finance-supplement/Source-Catalog.csv.
- **[F02]** Texas Comptroller, agreement #1377, TY2024 Form 772 (2025 filing), physical PDF p. 1, Section 2.7. Local original: [Form 772](sources/finance/comparables/C06_ch313_1377_772_2025.pdf). Financing event; no return disclosure.
- **[F03]** EIA-860/923, frozen annual comparison and monthly generation tables in finance-supplement/data/. Full workbooks remain in the project raw archive; geographic and capacity-vintage limitations are described in Section 9.5. No raw-EIA extraction was rerun for this edition.
- **[F04]** Finance supplement, Finance-Arithmetic-Checks.csv, Cost-Coverage-Crosswalk.csv, Node-Hub-Solar-Capture-2023-2025.csv, plus frozen scenario cash flows. This edition recomputes the stated arithmetic and sample screens in scripts/integrate_finance.py.
- **[F05]** CIT/First Citizens, Taygete I financing announcement, 9 December 2020; source F01 in finance-supplement/Source-Catalog.csv and Contract-Terms.csv. Financing amount is not construction cost or IRR. Secondary fixed-shape description is separately marked F03 in that catalog.
- **[F06]** PUCT, [16 TAC §25.195](https://www.puc.texas.gov/agency/rulesnlaws/subrules/electric/25.195/25.195.pdf), subsection (f)(1)–(3). [Retained original](sources/finance/ERCOT/PUCT_16TAC_25.195_current.pdf).
- **[F07]** [P.L. 119-21](https://www.govinfo.gov/content/pkg/PLAW-119publ21/pdf/PLAW-119publ21.pdf), §§70512–70513 and amendments to §§48E, 7701; [retained original](sources/finance/tax/PLAW-119publ21.pdf). Eligible-basis and section 50 treatment also referenced in the supplement tax matrix; no personal tax conclusion.
- **[F08]** District Court, case 1:25-cv-04400, opinion dated 6 June 2026, physical pp. 1, 57: [GovInfo](https://www.govinfo.gov/content/pkg/USCOURTS-dcd-1_25-cv-04400/pdf/USCOURTS-dcd-1_25-cv-04400-0.pdf), [retained original](sources/finance/tax/USCOURTS-dcd-1_25-cv-04400-0.pdf). Appellate/stay status is unresolved.
- **[F09]** IRS Notice 2026-15, material-assistance cost-ratio and prohibited-foreign-entity provisions; [retained original](sources/finance/tax/n-26-15.pdf).

'''
replace('# Appendix B. Methods and Interpretation',refs+'# Appendix B. Methods and Interpretation')
replace('# Appendix C. Research Agenda and Unresolved Evidence','''## B.5 Finance integration: reproducible arithmetic and evidence boundaries

The new calculation layer reads frozen cash flows and finance-supplement tables. It changes no regression coefficient, simulated output, decomposition, sample estimate or baseline return. Credit PV scales the earlier illustration by OCC / total CAPEX; the year-16 zero-reserve variant adds $3.5m / (1.0427)^16; paid-volume stress divides the no-unpaid break-even by one minus the assumed unpaid share. These are separately labeled financial settings.

EIA cohort statistics are re-screened explicitly by year, county field, quality flag and tracking field. Both the broader and tracking-only samples are retained, along with a sensitivity excluding Emerald Grove’s disputed county assignment. Their nameplate denominator comes from the retained 2025 record. No weather normalization, causal calibration or EIA raw-workbook rebuild is claimed. Selected source PDFs are included for author handoff; raw archives remain project dependencies for upstream research reproduction.

# Appendix C. Research Agenda and Unresolved Evidence''')
replace('No debt-funded equity return is estimated.','Public records identify a $256m Taygete I financing and the Taygete II foreclosure, but do not disclose coupons, tenor, sizing, reserves or a tax-equity waterfall. The $256m financing amount is not CAPEX. No debt-funded equity return is estimated.')
# Preserve open-gap text and explicitly distinguish new evidence from closure.
replace('The following priorities identify evidence that would materially change the analysis.', 'The following priorities identify evidence that would materially change the analysis.') if 'The following priorities identify evidence that would materially change the analysis.' in text else None
idx=text.index('# Appendix C. Research Agenda and Unresolved Evidence')
text=text[:idx]+text[idx:].replace('| FIN-02 | EIA-matched actual plant output, design, availability and curtailment |','| FIN-02 | Operating benchmark integrated; reconcile capacity vintage, geography, weather, losses and curtailment |').replace('| FIN-06 | Historical node identity and verified plant-to-node mapping |','| FIN-06 | Unit mapping integrated; official crosswalk, historical identity and actual settlement rights remain missing |')
(D/'Integrated-Market-Research-Report-EN_Finance-Integrated.md').write_text(text)
lineage=[dict(figure='9-1',path='figures/Finance_Operating_CF.png',input='data/finance/EIA-2025-Tracking-Chart.csv',operation='sort and plot annual_capacity_factor_ac; scenario reference lines 33.38/28.29'),dict(figure='10-3',path='figures/Finance_Qualified_Investment.png',input='data/finance/Qualified-Investment-Comparisons.csv',operation='sort result; divide USD/kWac by 1000')]
(D/'support/Finance-Figure-Lineage.json').write_text(json.dumps(lineage,indent=2))
print(json.dumps(calc,indent=2));print('Finance manuscript, two figures and arithmetic tables written; no estimates rerun.')
