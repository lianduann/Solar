from pathlib import Path
import pandas as pd,json,re,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parents[1];t=(D/'stages/P1.md').read_text()
def tab(h,rs):return '\n'+'| '+' | '.join(h)+' |\n| '+' | '.join(['---']*len(h))+' |\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rs)+'\n'
def insert(marker,s):
 global t;t=t.replace(marker,s+'\n'+marker,1)
# New context counts use only frozen hourly input, fixed CST, no event attribution.
h=pd.read_csv(D/'data/empirical/plot_inputs/F6_hourly_HB_BUSAVG_and_system_solar.csv');h=h[h.year==2023].copy();dt=pd.to_datetime(h.utc,utc=True)-pd.Timedelta(hours=6);h['month']=dt.dt.month;h['cst_hour']=dt.dt.hour;hi=h[h.HB_BUSAVG_hourly_mean_usd_mwh>=1000]
ctx=h.groupby('month').agg(hours=('utc','size'),maximum_hourly_price=('HB_BUSAVG_hourly_mean_usd_mwh','max')).reset_index();ctx['hours_at_least_1000']=ctx.month.map(hi.groupby('month').size()).fillna(0).astype(int);ctx.to_csv(D/'data/2023-Benchmark-Price-Context.csv',index=False)
assert len(hi)==61 and sum(hi.month==8)==39 and sum(hi.month==9)==12
insert('## 11.8 Tail', 'In the system benchmark hourly series, 61 hours in 2023 average at least $1,000/MWh: 39 occur in August and 12 in September, with the rest in June, July and October. These hours fall between hour indices 12 and 20 on a fixed UTC−6 clock; the largest hourly average is about $5,073/MWh. This describes the benchmark, not the reference node or the separate 15-minute tail statistic. [E-B]')
# One transparent financial panel, keeping scopes visibly distinct.
w=pd.read_csv(D/'data/supplement/D/D_company_xbrl_wide.csv');a=pd.read_csv(D/'data/r2/D/D_ashare_peers_FY2025.csv');rows=[]
stages={'Canadian Solar':'Modules + projects','Daqo New Energy':'Polysilicon','First Solar':'Thin-film modules','JinkoSolar Holding':'Integrated PV'}
for _,r in w[w.fiscal_period.isin(['FY2024','FY2025'])].iterrows():rows.append([r.company,stages[r.company],r.fiscal_period.replace('FY',''),f'{100*r.gross_margin:.1f}%','n/a',f'{r.operating_cash_flow/1e9:.2f}',f'{r.capex_ppe/1e9:.2f}',r.currency,'Group; PPE cash'])
for c,mar,st in [('Trina','4.6%','Integrated PV'),('JA Solar','−2.1%','Cells/modules'),('Tongwei','−1.12%','Silicon/cells + feed')]:
 def v(m):return float(a[(a.company==c)&(a.metric==m)&(a.period=='FY2025')].value.iloc[0])/1000
 rows.append([c,st,'2025',mar,f'{v("net_profit_attributable"):.2f}',f'{v("operating_cash_flow"):.2f}',f'{v("capex_cash"):.2f}','CNY','Segment margin; LLA cash*'])
rows += [['LONGi','Modules/cells','2024','6.27%','n/a','n/a','n/a','CNY','Segment only'],['LONGi','Wafers/ingots','2024','−14.31%','n/a','n/a','n/a','CNY','Segment only']]
panel='''## 4.2 Company financial panel: margins and cash flows answer different questions

**Table 4-2. Company financial observations; cash amounts in billions of the stated currency.**
'''+tab(['Company','Stage','FY','Gross margin','Net result','OCF','Asset cash','Currency','Basis'],rows)+'''Sources: company annual filings and XBRL [S02, R-D, R-F]. Net result is profit attributable to shareholders where available; n/a means unavailable in the extracted comparable panel, not zero. OCF means operating cash flow. PPE cash is cash paid for property, plant and equipment. LLA cash is cash paid for fixed, intangible and other long-lived assets; *the consolidated-versus-parent statement scope for these three extracted amounts has not been separately confirmed. The A-share gross margins are segment measures: PV for Trina and Tongwei, new energy for JA. Tongwei's group cash flows include feed/food activities. LONGi's rows show segment margins only. Currencies are not converted, so cash levels are not a cross-company ranking.

Daqo's two margins both round to −20.7%, but are different observations: FY2024 gross loss of $212.932m on $1,029.080m revenue, versus FY2025 gross loss of $137.851m on $665.415m revenue. The underlying annual XBRL entries confirm that the apparent duplication is rounding, not a repeated input. [R-D]

'''
i=t.index('## 4.2 ');j=t.index('## 4.3 ',i);t=t[:i]+panel+t[j:]
# Remove now redundant smaller gross-margin table, preserve its narrative.
i=t.index('**Table 4-2.**',t.index('## 4.5 ')) if '**Table 4-2.**' in t[t.index('## 4.5 '):t.index('## 4.6 ')] else -1
if i>=0:
 j=t.index('\n\n',t.index('|---',i));t=t[:i]+t[j+2:]
insert('## 4.1 ', 'Several reported businesses combine losses or weak margins with reduced long-lived-asset spending. The panel below distinguishes segment profitability, group cash generation and investment cash outlays: these measures identify commercial pressure without assigning a common cause or ranking manufacturers across different businesses and currencies.')
# Targeted Daqo comparison against retained SEC facts, no source retrieval or broader re-audit.
P=D.parents[1];src=P/'Data/raw/2026-10-08_Deep-Report-Supplement/D_Global-Manufacturing/D1x-facts-1477641__EDGAR_companyfacts_1477641.json';facts=json.loads(src.read_text())['facts']['us-gaap'];long=pd.read_csv(D/'data/supplement/D/D_company_xbrl_long.csv');checks=[]
for _,r in long[(long.company=='Daqo New Energy')&long.fiscal_period.isin(['FY2024','FY2025'])&long.metric.isin(['gross_profit','revenue'])].iterrows():
 us=facts[r.xbrl_tag]['units'][r.currency];matches=[x for x in us if x.get('end')==r.period_end and x.get('accn')==r.accession and x.get('val')==r.value and x.get('start','').endswith('01-01')];assert matches
 checks.append({'year':r.fiscal_period,'metric':r.metric,'value':r.value,'tag':r.xbrl_tag,'accession':r.accession,'matches':len(matches)})
(D/'support/Daqo-Targeted-Source-Check.json').write_text(json.dumps({'source':str(src),'checks':checks},indent=2))
# LMDI main exhibit uses exactly the existing table component medians, not a new decomposition.
f=pd.read_csv(D/'data/empirical/A_decomposition_summary_strict_nodes.csv');comps=['volume_lmdi','price_level_lmdi','match_lmdi','rule_effect'];print('components',f.component.unique())
# Discover exact frozen rule key.
rule=[x for x in f.component.unique() if 'rule' in x][0];comps[-1]=rule
fig,ax=plt.subplots(figsize=(9,3.6));colors=['#163A52','#27858B','#D18A3B','#80949F'];pairs=[(2023,2024),(2023,2025),(2024,2025)]
for k,c in enumerate(comps):
 vals=[float(f[(f.from_year==a)&(f.to_year==b)&(f.component==c)].npv_median.iloc[0])/1e6 for a,b in pairs];ax.bar([i+(k-1.5)*.18 for i in range(3)],vals,.18,label=['Volume','Overall price','Timing match','Export rule'][k],color=colors[k])
ax.set_xticks(range(3),['2023 → 2024','2023 → 2025','2024 → 2025']);ax.set_ylabel('Median NPV component, $ million');ax.axhline(0,color='#80949F',lw=.8);ax.spines[['top','right']].set_visible(False);ax.legend(ncol=4,loc='lower center',bbox_to_anchor=(.5,1.01),frameon=False);fig.tight_layout();fig.savefig(D/'figures/Client_LMDI_decomposition.png',dpi=250);fig.savefig(D/'figures/Client_LMDI_decomposition.pdf');plt.close(fig)
# Keep other allocation and original mixed chart in technical appendix with explicit distinction.
orig=(D/'support/Original-Decomposition-Section.md').read_text();s=orig.index('The two-factor Shapley');e=orig.index('A separate log-mean');sha=orig[s:e].replace('**Table 11-2.**','**Table B-1. Weather and price contributions: Shapley allocation.**')
insert('# Appendix C.', '## B.3 Alternative weather/price accounting\n\n'+sha+'\nThe original mixed exhibit below retains pure effects plus interaction in its left panel. Its left bars are not the Shapley allocations in Table B-1. It is preserved as a technical diagnostic and must not be compared as if the numbers were identical.\n\n![Figure B-1. Original pure-effect and price-volume diagnostics](figures/empirical/F3_npv_change_decomposition.png)\n')
# Build full source module index from already retained catalogs; no guessed publication URLs.
cats={}
for name in ['Commercial','Scenario','Supplement','R1']:
 p=D/'support'/f'{name}-Source-Catalog.csv'
 if p.exists():
  for r in csv.DictReader(p.open()):cats[r['source_id']]=r
for p in [D/'support/Source-Catalog-R2.csv',D/'data/empirical/tables/Source-Catalog-Empirical.csv']:
 for r in csv.DictReader(p.open()):cats[r['source_id']]=r
(D/'support/Combined-Source-Catalog.json').write_text(json.dumps(cats,indent=2))
# Stable official URLs exist in catalogs; list the core and all additionally cited catalog sources.
keys=list(cats)
def find(part):
 matches=[k for k in keys if part.lower() in k.lower() or part.lower() in cats[k].get('title','').lower()];return matches[0] if matches else None
modules={'S01':[find('MIIT-2024')],'S02':[find('LONGI-2024')],'S03':[find('IRENA-2026')],'S04':[find('LBNL-2025-UPDATE')],'S05':[find('ERCOT-LOAD'),find('ERCOT-SOLAR')],'S06':['EM03'],'S07':['EM13-2025'],'S08':['EM14','EM15'],'S09':[find('NLR-2025-ATB')],'S10':['EM15'],'R-A':['A01','A03','A04','A05'],'R-B':['EM01','EM02','EM03','EM04'],'R-C':['C02','C03','C04'],'R-D':[find('D01'),find('D02'),find('D10'),find('D11'),find('D12'),find('D13')],'R-T (formerly R2-A)':[find('census_i'),find('census_q')],'R-F (formerly R2-D)':['D20','D21','D22'],'E-S':['EM01','EM02','EM03','EM04'],'E-A':['EM13-2023','EM13-2024','EM13-2025','EM14','EM15'],'E-B':['EM05','EM06','EM07','EM08','EM09','EM10','EM11'],'E-C':['EM01','EM02','EM03','EM15'],'P01':['FR-2026-16400'],'P02':['IRS-N-2025-42'],'P03':['IRS-N-2026-15'],'P04':['A01']}
entries=[]
for mod,ids in modules.items():
 for key in dict.fromkeys(x for x in ids if x):
  if key not in cats:continue
  r=cats[key];url=r.get('official_url','');title=r.get('title') or key;date=r.get('publication_date') or r.get('statistical_period') or r.get('period','');entries.append([mod,key,title,date,url,r.get('file_path') or r.get('project_relative_path','')])
assert all(any(x[0]==m for x in entries) for m in modules),[m for m in modules if not any(x[0]==m for x in entries)]
pd.DataFrame(entries,columns=['report_id','catalog_id','title','date_or_period','official_url','project_source_file']).to_csv(D/'data/Client-Source-Index.csv',index=False)
app='''# Appendix A. Sources, Data, and Evidence Locations

Bracketed identifiers identify source families, not additional independent studies. Research results [S08, S10, E-A, E-B, E-C] are calculations on the listed official inputs; their computation files have no official publication URL. Dates below are publication dates or statistical periods as recorded in the source catalog. The accompanying Client-Source-Index table preserves the full URL, original file location and catalog identifier; source catalogs contain acquisition details and hashes.

'''
for mod in modules:
 group=[x for x in entries if x[0]==mod];app+=f'**{mod}.** '+'; '.join(f'{x[2]} ({x[3]}): [official source]({x[4]})' for x in group)+'\n\n'
app+='''**Table A-1. Local analysis files associated with report claims.**
'''+tab(['IDs','Data files'],[['S01','data/miit_2024_observations.csv; data/miit_pdf_verification.json'],['S02–S05','data/longi_product_margins.csv; data/irena_pv.csv; data/lbnl_2030_scenarios.csv; data/hourly_profile.csv'],['S06–S09','data/scenario_metrics.csv; data/scenario_annual_cash_flows.csv; data/scenario_input_register.csv; data/breakevens.json'],['R-A–R-D','data/supplement/A–D/ (component, load, node and financial tables)'],['R-T; R-F','data/r2/A/; data/r2/D/'],['E-S–E-C','data/empirical/ (sample, regression, decomposition and tail tables)'],['New client examples','data/Client-Illustrative-Calculations.json; data/2023-Benchmark-Price-Context.csv']])
i=t.index('# Appendix A.');j=t.index('# Appendix B.',i);t=t[:i]+app+'\n'+t[j:]
# Glossary (scope-sensitive expansions, not conjectures).
gloss=[('ERCOT','Electric Reliability Council of Texas; grid and wholesale-market operator for most of Texas.'),('MIIT / IRENA','Ministry of Industry and Information Technology (China) / International Renewable Energy Agency.'),('DOE / NLR','U.S. Department of Energy / National Laboratory of the Rockies; older source documents use NREL, National Renewable Energy Laboratory.'),('ATB / PVSCM','Annual Technology Baseline / Photovoltaic System Cost Model; national reference models, not project quotes.'),('OCC / GCC / FOM','Overnight capital cost / grid-connection cost / fixed operations and maintenance.'),('NSRDB / PVWatts / PySAM','National Solar Radiation Database / photovoltaic output model / Python interface to the System Advisor Model.'),('Settlement point / resource node','Pricing location; RN denotes the official resource-node type used to filter this report’s sample.'),('Hub / load zone','Aggregated market-price reference locations; not substitutes for the asset’s settlement node.'),('HB_BUSAVG','System benchmark identifier used in the hourly analysis; its formal name is not disclosed in this edition.'),('NP6-905-CD','ERCOT’s 15-minute real-time settlement-point price report, not day-ahead prices.'),('Basis','Node price minus the specified benchmark price.'),('Time-/generation-weighted price','Average across equal-duration intervals / price averaged with simulated output as weights.'),('Capture ratio','Generation-weighted price divided by time-weighted price; denominator and export rule must be stated.'),('LCOE / NPV / IRR','Levelized cost of energy / net present value / internal rate of return; definitions in Table 2-1.'),('TAC','Technical Advisory Committee (ERCOT).'),('Batch Zero','One-time transitional reliability study for eligible large-load interconnections under PGRR145; September deck, p.5 [R-C].'),('WLPUN / BYOG','Withdrawal Limited Private Use Network / Bring Your Own Generation; September deck p.8 and April study deck p.1 [R-C].'),('Noncoincident peak','Individual peak observations may occur at different times; their aggregate is not a simultaneous system load.'),('HS / HTS / IEEPA','Harmonized System / U.S. Harmonized Tariff Schedule / International Emergency Economic Powers Act.'),('ITC / PTC','Investment tax credit / production tax credit; the cash-credit illustration is not an eligibility calculation.'),('P50 / P90','Output exceeded with 50% / 90% probability over a defined horizon; three weather years do not establish these probabilities.'),('Shapley / LMDI','Allocation of interacting changes by averaging orders / log-mean Divisia index accounting decomposition.'),('HAC / block bootstrap','Heteroskedasticity and autocorrelation consistent uncertainty estimates / resampling consecutive time blocks.'),('RMSE','Root mean squared error; a prediction-error measure.'),('DC/AC / bifaciality / GCR','Module-to-inverter nameplate ratio / rear-to-front conversion efficiency ratio / ground-coverage ratio.')]
g='''# Appendix D. Glossary\n\n'''+tab(['Term','Meaning in this report'],gloss)
i=t.index('# Appendix D.');j=t.index('# Appendix E.',i);t=t[:i]+g+'\n'+t[j:]
# Concrete decision matrix column.
s=t.index('| Reader decision |');e=t.index('\n\n',s);block=t[s:e];lines=block.splitlines();lines[0]+=' What this report shows |';lines[1]+='---|';show=['8.9% CAPEX example closes 14.9% of reference NPV gap','2025 reference capture ratio about 48%, before export response','238.6 GW requested versus about 5.8 GW observed energized; different measures','Self-supply power capacity: about 83% gas, 11% solar','About $66/MWh flat nominal, or $577/kWac on the nodal route']
for i,v in enumerate(show,2):lines[i]+=' '+v+' |'
t=t[:s]+'\n'.join(lines)+t[e:]
# Clean legacy mechanical substitutions and visibly incomplete limits boxes.
t=t.replace('original original project model', 'original project model').replace("MIIT's the material", "MIIT's publication").replace('The the extract','The cost extract').replace('The the evidence','The evidence').replace("Berkeley Lab's the utility-scale", "Berkeley Lab's utility-scale")
t=t.replace("None of the empirical findings releases the original project model's unreleased outputs or constitutes an actual asset recommendation.", 'The empirical findings support conditional screening, with the asset-level boundaries in Box 1.')
t=t.replace('.. (3) ', '. (3) The additional evidence required is listed in Appendix C.').replace('..', '.')
t=t.replace('low/base/high costs follow the ATB Conservative/Moderate/Advanced technology cases, respectively in downside/base/upside order','downside/base/upside costs follow the ATB Conservative/Moderate/Advanced technology cases, respectively')
# Explicitly identify real-time at first product explanation.
t=t.replace('reports 15-minute settlement-point prices.', 'reports 15-minute real-time settlement-point prices.')
(D/'stages/P1.md').write_text(t);(D/'Integrated-Market-Research-Report-EN_Client-Readable.md').write_text(t)
print('P1 complete',len(t.split()))
