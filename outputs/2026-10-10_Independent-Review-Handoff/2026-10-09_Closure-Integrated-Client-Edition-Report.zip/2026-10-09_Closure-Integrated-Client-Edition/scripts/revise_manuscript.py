"""Apply documented editorial changes to the frozen client manuscript; no estimation."""
from pathlib import Path
import re,json,csv
D=Path(__file__).resolve().parents[1]
s=(D/'support/Baseline-Client-Readable.md').read_text()
original=s
def section(start,end,text):
 global s
 a=s.index(start); b=s.index(end,a); s=s[:a]+text.strip()+'\n\n'+s[b:]
def replace(a,b):
 global s
 assert a in s,a[:100]
 s=s.replace(a,b)
replace('Research edition | October 2026','Panel-revised research edition | 9 October 2026')
section('## 1.1 Key findings','## 1.2 Key numbers', '''## 1.1 Key findings

**Lower equipment prices help, but the tested 2024–2025 revenue patterns leave a large capital-recovery gap. The positive 2023 comparison depends heavily on scarce high-price intervals. These results support contract and procurement screening, rather than an investment recommendation.**

1. The hypothetical 2025 reference system earns $26.4/MWh on delivered electricity against a delivered-energy LCOE of $48.9/MWh. Its pre-tax, unlevered NPV is −$86.0m at 4.27% real discounting. Neither base revenue route recovers its defined lifetime costs. [S08]
2. Payment terms matter. A flat nominal contract breaks even near $66/MWh with the severe assumed 15.24% unpaid-energy deduction; paying for all potential generation lowers the threshold to $55.9/MWh. Neither number is an observed contract offer. [S08; panel calculations]
3. A hypothetical 10% reduction in the **U.S. module input**, transmitted through the component model to PV overnight cost while grid-connection cost stays fixed, saves $3.76m. Even a zero-priced module input leaves the reference NPV around −$48.3m. This cross-benchmark sensitivity estimates no actual China-to-U.S. price transmission. [R-A; panel calculations]
4. Repeating 2023 conditions yields positive NPV at all 485 rule-screened nodes, versus 13 in 2024 and two in 2025. The top 1% of 2023 price intervals contribute 54.7% of median modeled receipts; removing those receipts leaves 482 nodes negative. These sample shares are historical scenario outcomes, not profitability probabilities. [E-A, E-C]
5. The reference node's 2025 average price is $46.37/MWh, but its potential-generation-weighted price is $22.13/MWh. The corresponding West hub value is $21.46/MWh on the common calendar. A hub contract therefore needs its own settlement calculation; switching benchmarks is not automatically an improvement. [S06, S07; panel comparisons]
6. Load growth and manufacturing scale require separate commercial qualification. ERCOT's March process table records 238.6 GW in the 2030 request column against approximately 5.8 GW observed energized on a different, historical noncoincident basis. Selected manufacturers report losses even as deployment expands. Neither observation determines the economics of a particular supplier contract or solar asset. [R-C, R-F]

The fiscal sensitivity in Chapter 10 assumes, without establishing eligibility, a nominal cash receipt equal to 30% of construction-year nominal CAPEX. Its present value is $40.33m; the reference case remains negative at −$45.64m. Contract, tax and financing research priorities are marked **FIN-01–FIN-11** where they affect the analysis.''')
replace('| Hypothetical CAPEX / NPV improvement | 8.9% / $12.8m | Cross-benchmark example; 5.5 |','| U.S. module input falls 10% | $3.76m CAPEX / NPV improvement | PV overnight cost only; connection unchanged; 5.6 |')
replace('Its selection rationale is **not disclosed in this edition**.','The historical reference selection is documented in Section 8.1.')
replace('(1) The headline case uses one historical reference node; its selection rationale and actual project settlement relationship are not disclosed in this edition.','(1) The headline case uses one historical price reference without a verified asset settlement relationship.')
replace("MIIT's annual price changes are reported observations.","MIIT's two reported annual price changes concern polysilicon and modules; no wafer or cell price change is inferred.")
replace("Policy sections require verification against the final publication cutoff. The historical pages establish the material available at their acquisition dates; they do not by themselves certify the current application of a rule.","Policy context is dated to 9 October 2026. Official provisions identify diligence requirements; project applicability still depends on product, ownership, timing and contractual facts.")
# Manufacturing: preserve values, clarify consolidation and periods.
replace('## 4.1 The 2024 manufacturing evidence','## 4.1 Manufacturing evidence: 2024 annual cutoff')
replace("MIIT's publication reports Chinese polysilicon", "The retained MIIT annual bulletin, published 27 February 2025, covers 2024. This edition does not treat it as a 2026 run-rate measure. A comparable later manufacturing bulletin is not incorporated. MIIT reports Chinese polysilicon")
replace('*Source: the supplied MIIT PDF and the official republication used for reconciliation. Underlying table: the corresponding source table. The chart shows annual changes, not a continuous transaction-price series.*','*Source: MIIT, 2024 national photovoltaic manufacturing bulletin, supplied original PDF; official Fujian republication [S01]. Two annual price changes, not a continuous transaction-price series.*')
replace('LLA cash*','LLA cash')
replace('*the consolidated-versus-parent statement scope for these three extracted amounts has not been separately confirmed.','The Trina, JA Solar and Tongwei asset-cash lines are from consolidated cash-flow statements: physical PDF pp.151–152, 145–146 and 104–105, respectively.')
replace("Daqo's two margins", "JA Solar's FY2025 attributable loss is CNY4.608bn, compared with CNY4.656bn in FY2024; these are distinct annual columns (annual report, physical p.8). Consolidated revenue of CNY49.129bn implies a −9.38% attributable net margin. The analogous FY2025 ratios are −10.50% for Trina and −11.36% for Tongwei; these group net margins should be read alongside the segment gross margins above, not substituted for them. [R-F]\n\nDaqo's two margins")
replace('## 4.4 Competitive analysis requiring further evidence','## 4.4 Policy, market access and ownership')
needle='A matched competitive panel would align product technology, segment boundaries, currency, fiscal period, utilization denominator and the treatment of incentives.'
replace(needle,'''China's January 2025 renewable electricity pricing reform moves wind and solar generation toward market-based pricing with differentiated arrangements for existing and new projects. It changes the setting for domestic demand; no installation response is estimated here. From 1 April 2026, the listed photovoltaic products lose their export VAT rebate under the January 2026 notice. This affects export economics without proving an equal increase in the U.S. delivered price. [P07, P08]

For overseas supply, four links require separate evidence: factory location, material origin, customs treatment and producer ownership/control. An overseas plant is not by itself proof of access to a particular duty treatment or tax-credit-compliant supply chain. Announced capacity is distinct from operational output; this edition has no harmonized 2026 overseas capacity or ownership panel. A matched competitive panel would align product technology, segment boundaries, currency, fiscal period, utilization denominator and the treatment of incentives.''')
replace('## 4.5 Common-period company evidence shows heterogeneous financial outcomes','## 4.5 Common-period company evidence shows heterogeneous financial outcomes')
# Add procurement liquidity research without inferred default claims.
idx=s.index('# 5. Cost Transmission')
s=s[:idx]+'''> **Supplier-finance research pending — FIN-09.** Reconcile cash balances, restricted cash, working-capital movements, debt maturities, covenant headroom, warranty provisions and manufacturing incentives before drawing conclusions about delivery resilience. Positive operating cash flow alongside an accounting loss does not establish sustainable free cash generation. First Solar's different technology, geography, contracts and manufacturing-credit exposure require a separate reconciliation before any efficiency comparison.

'''+s[idx:]
section("Applying MIIT's reported 29.7% module-price decline",'## 5.6 Policy changes', '''The preferred sensitivity varies the **U.S. module input** directly. A 10%, 20% or 30% module-input reduction lowers PV-only modeled cost by approximately 2.99%, 5.97% or 8.96%, respectively. The result follows from the 26.111% module share multiplied by the 1.144 marginal cost factor. The module price is the changed input; specifications, logistics and other component inputs remain fixed.

![Figure 5-2. Hypothetical U.S. module-input changes and PV-only modeled cost](figures/S04_passthrough.png)

*Source: DOE/NLR PVSCM component calculation [R-A]. Percentage changes apply to the PV-only modeled cost boundary, not separately to grid connection or a delivered procurement quote.*

## 5.6 From component savings to project value

The hypothetical financial case contains $126.04m of PV overnight cost and $17.63m of grid-connection cost. Applying the component percentage to the former while holding the latter fixed gives the following controlled comparison. It combines two national benchmarks and is therefore an illustrative cost mapping, not a measured project procurement relationship.

**Table 5-1. U.S. module-input sensitivities; real 2025 dollars.**

| Module-input reduction | Initial cost saving / pre-credit NPV gain, $m | Reference-node NPV, $m | Fixed-base NPV, $m |
|---|---:|---:|---:|
| 10% | 3.76 | −82.20 | −69.98 |
| 20% | 7.53 | −78.44 | −66.21 |
| 30% | 11.29 | −74.67 | −62.45 |
| 100%: module input set to zero | 37.65 | −48.32 | −36.09 |

*Source: existing component share and cost factor, scenario cost register and frozen base cash flows; panel calculations. Connection cost is unchanged. Zero module price is a mathematical boundary, not a feasible commercial quotation.*

Even eliminating the module input fails to close the tested shortfall. If the illustrative credit in Section 10.8 applies and eligible basis falls with cost, a 10% module reduction improves NPV by $2.71m rather than $3.76m because the assumed credit receipt also falls. This is a conditional interaction, not evidence of actual eligibility. MIIT's −29.7% remains a China manufacturing observation and is not used as a forecast of U.S. savings.

> **Procurement research pending — FIN-05.** Obtain specification-matched U.S. delivered module and EPC quotations, reconcile PV overnight versus interconnection scope, and document which savings change eligible tax basis. Dollar-per-watt comparisons need a common DC denominator and consistent delivery, duty and incentive treatment.''')
replace('## 5.6 Policy changes','## 5.7 Policy changes')
replace('## 5.7 Import value','## 5.8 Import value')
replace('The additional trade register is the as an evidence map, not a certified all-in tariff calculator.','The accompanying trade evidence identifies applicable diligence questions; it is not an all-in tariff calculator.')
replace('the Census analysis covers','The Census analysis covers')
replace('The headline price is not a universal delivered-project quotation.','This Section 232 measure contains documentation and pre-existing-contract provisions; the headline price is not a universal delivered-project quotation.')
replace('(1) The 8.9% cost bridge is illustrative and combines two national benchmarks.','(1) The component-to-overnight-cost bridge is illustrative and combines two national benchmarks.')
# Add net load exhibit, preserving original system plots and units.
anchor='## 7.3 Regional screening'
i=s.index(anchor)
s=s[:i]+'''![Figure 7-3. Load, wind, solar and residual load across the day, 2025](figures/Panel_Net_Load.png)

*Source: existing ERCOT hourly system panel [E-B]; arithmetic hourly means on the America/Chicago civil clock, all 2025 dates. Residual load equals load less wind and solar, before other generation, storage, imports and operational constraints; it is not a shortage measure.*

The residual-load curve identifies the hours that still require other supply after wind and solar. It is a system timing comparison, with no inference about an individual plant's dispatch or achievable selling price.

'''+s[i:]
section('TAYGETE2_ALL is a historical price reference.','The result demonstrates', '''TAYGETE2_ALL is the historical price reference inherited by this study. A documented selection rationale and a settlement relationship to the hypothetical Pecos location are **not disclosed in this edition**; neither geographic nor commercial mapping is assumed. The 2025 series provides 35,038 of 35,040 expected intervals. Its time-weighted price is $46.37/MWh and potential-generation-weighted price $22.13/MWh, before the negative-price response. [S06, S07]

**Table 8-1. Reference node and hub comparisons, same output profile and common calendar.**

| Price year | Reference-node weighted price, $/MWh | West hub weighted price, $/MWh | ERCOT Bus Average hub weighted price, $/MWh |
|---|---:|---:|---:|
| 2023 | 64.89 | 64.94 | 67.70 |
| 2024 | 20.85 | 20.60 | 23.40 |
| 2025 | 22.13 | 21.46 | 24.94 |

*Source: frozen weather-price comparison tables [E-A], arithmetic selection of TAYGETE2_ALL, HB_WEST and HB_BUSAVG. Potential-output weighting, before the shutdown rule; each year uses that year's simulated profile. Different years retain historical numerical price levels without CPI harmonization (Section 10.9).*

The West hub does not improve this particular 2025 weighted-price comparison. ERCOT Bus Average (HB_BUSAVG) is the 345-kV bus-average hub introduced under NPRR817, excluding Panhandle buses; it is a system reference rather than a four-hub simple average. [P09] Neither benchmark verifies the asset's settlement node or supplies the cash flows of a hub-settled contract.

> **Location research pending — FIN-06.** Document the reference choice, map a genuinely comparable plant to its official settlement point and ownership, and retain historical node identity and price-version evidence. Hub prices remain comparison benchmarks.''')
replace('The main comparison contains 485 officially classified resource nodes with complete prices on the shared published grid in 2023–2025.','The main comparison contains 485 resource nodes selected by explicit coverage and identity rules, rather than a random sample. All are RN-type points on the 10 September 2026 official list with complete prices on the shared published grid in 2023–2025. The current list does not establish each historical identity or commissioning date. The separate 641-node population requires complete coverage in 2025 only; excluded points are not automatically newly commissioned plants.')
replace(' The commercial settlement relationship and reason for choosing this reference node are **not disclosed in this edition**.',' The choice and mapping limitation is stated in Section 8.1.')
section('## 8.6 Conditional associations','## 8.8 Node basis', '''## 8.6 What the statistical comparisons indicate

Across the pooled hourly data, higher system solar output is associated with lower benchmark prices after accounting for the included load, wind, gas, temperature and calendar measures. The simpler pooled estimates are approximately −$2.7 to −$3.8/MWh per additional GW; the association is stronger in 2023 and weaker when extreme-price influence is reduced. These are conditional relationships, not the price effect of building an additional GW. Actual solar generation can also respond to price and dispatch, while missing outages, imports and constraints leave important common drivers unmeasured. [E-B]

## 8.7 What the statistical comparisons can be used for

The analysis does not yield a stable relationship between solar output and the probability of a negative hourly price across model choices. A negative hourly mean is also a different outcome from a negative 15-minute interval. The 2025 prediction test performs worse than simple historical averages: approximately $66/MWh prediction error versus $45 for an hour-of-week average and $39 for a constant benchmark. The regressions are useful for examining a mechanism; they should not supply future project prices or receipts. Both changing market price levels and extreme-hour errors matter to this prediction failure. Coefficients, uncertainty methods and nonlinear-model qualifications are in Appendix B. [E-B]

![Figure 8-4. Observed price patterns and negative-hour incidence](figures/empirical/F6_price_vs_solar_and_negative_hours.png)

*Source: frozen hourly benchmark and system-solar data [E-B]. Binned patterns are descriptive; hourly aggregation and other changing conditions limit their interpretation.*''')
replace('![Figure 8-6.','![Figure 8-5.')
replace('original exhibit F7 (reproduced here as Figure 8-6) and basis tables','node-basis tables')
# Generation validation.
i=s.index('# 10. Financial Scenarios')
s=s[:i]+'''> **Performance research pending — FIN-02.** Compare the simulated 33.4% potential-output capacity factor with same-year net generation at genuinely comparable operating plants using EIA-860 design/COD data and EIA-923 generation. Reconcile AC capacity, partial years, clipping, availability, losses, curtailment and settlement delivery. No observed capacity-factor calibration or validated P50/P90 is available. A proportional 10% increase in the existing reference export profile adds approximately $10.14m to NPV with costs unchanged; this is a shape-preserving sensitivity, not a new simulation or a prediction.

'''+s[i:]
replace('Site-specific land, tax, insurance, network-upgrade, and market-service costs have not been separately established.','ATB fixed O&M includes broad system, property and administration expenses, including insurance and component-failure allowances. Its published categories do not establish this site’s actual land, property-tax or insurance payments. A project-specific crosswalk is required before adding costs, so included benchmark categories are not counted twice. Network and market-service obligations also require documented scope.')
replace('In both base cases, revenue exceeds modeled FOM in every operating year. Coverage of omitted operating costs remains unverified.','In both base cases, revenue exceeds modeled FOM in every operating year. The difference between the reference allowance and actual operating obligations remains unverified.')
section('The fixed-price route has no observed contract.','**Table 10-0.', '''The fixed-price route is a simplified node-level paid-volume arrangement, not an observed PPA and not a hub-settled virtual PPA. It holds $40/MWh constant in nominal terms for the full 30-year life and deducts 15.24% of potential energy from payment. That deduction is borrowed from the negative-price energy share solely as a stress assumption. Its downside value, 30.48%, doubles the stress rather than describing an empirical contract clause. Inflation reduces the real value of the flat nominal price.

The 2025 price averaged over negative-price energy is only about −$1.79/MWh. For a buyer who pays the fixed price through those intervals, physical negative prices do not automatically erase contract receipts. Actual economic shutdown instead depends on energy settlement, contract rights, production incentives and delivery obligations together. Removing the unpaid-energy assumption lowers the fixed-route break-even price from $65.97 to $55.91/MWh, holding other assumptions fixed.

For a simplified hub-settled financial contract, interval receipts would be **node energy receipts + contracted quantity × (strike price − hub price)**, before fees, deviations and other clauses. If contracted quantity equals generated output, node-to-hub basis remains an exposure. Different volume shapes, negative-price provisions, payment suspensions and credit terms can change the result.

> **Contract research pending — FIN-03.** Obtain comparable public node/hub PPAs and model actual payment, volume and negative-price provisions. Add 10- and 15-year contract cases with explicitly sourced merchant tails and counterparty terms. No observed contract tenor, strike or terminal price is assigned here.''')
replace('**Table 10-0.','**Table 10-1.')
replace('**Table 10-1. Six scenarios','**Table 10-2. Six scenarios')
replace('**Table 10-2. Same-year','**Table 10-3. Same-year')
replace('*Source: the corresponding source table. Amounts reflect the declared scenario scope. Upside and downside cases are parameter combinations, not probability bounds.*','*Source: six-scenario cash-flow outputs [S08, S10]. Values retain the original estimates; upside/downside bundles have no probabilities assigned.*')
replace('## 10.7 Benchmark scope and tax context remain separate from project cash flows','## 10.7 Benchmark scope and project cost reconciliation')
section('IRS Notice 2025-42 addresses','## 10.8 Historical price-year', '''> **Cost research pending — FIN-05.** Reconcile EPC, owner costs, development and financing costs, land, tax, insurance, network obligations, reserves, component replacement and end-of-life costs. Verify the ERCOT interconnection agreement and cost allocation rather than importing assumptions from another market. The FOM allowance and explicit year-16 replacement must be checked for overlap.

## 10.8 Tax timing: a cash sensitivity, not an entitlement

The baseline six scenarios remain pre-tax, without credits. For a separate illustration, assume the full $143.67m real-2025 CAPEX is eligible and paid at the end of 2026. At 2.5% inflation, its nominal 2026 value is used to set a 30% nominal credit receipt of $44.18m, paid unchanged at the end of 2027. Deflating the receipt to 2025 dollars and discounting one year at 4.27% yields a present value of **$40.33m**. Reference-node NPV becomes **−$45.64m**, fixed-base NPV **−$33.41m**, and the original fixed-route break-even price **$51.77/MWh**. No benefit enters the baseline rows.

The earlier $41.34m example treated the receipt as 30% of real CAPEX paid a year later. The nominal-payment convention above is a distinct, explicit timing assumption; neither illustration establishes the legally eligible basis or actual cash proceeds. A later cash receipt, lower basis or transfer discount would reduce the benefit.

**Table 10-4. Dates that must be established before assigning a solar credit.**

| Diligence branch | Official timing context | Financial treatment in this edition |
|---|---|---|
| Construction begins before 5 July 2026 | Construction-start and continuity requirements remain relevant | No construction evidence supplied; no assigned entitlement |
| Construction begins after 4 July 2026; placed in service by 31 December 2027 | End-of-2027 placed-in-service cutoff is relevant | Schedule and other eligibility facts unverified |
| Construction begins after 4 July 2026; placed in service after 31 December 2027 | Termination provision applies to relevant wind/solar credits | Zero-credit baseline; no assumed rescue by an incentive |

*Source: IRS Notice 2025-42, opening statutory discussion and construction/continuity provisions [P02]. These are timing branches, not a complete eligibility test.*

IRS Notice 2026-15 adds prohibited-foreign-entity and material-assistance requirements, including supply-chain cost-ratio tests and taxpayer ownership/control considerations. Its material-assistance restriction concerns facilities beginning construction after 31 December 2025. Foreign production location alone does not determine qualification. The specific qualified-interconnection-cost provision applies to facilities no larger than 5 MWac, so the illustration's treatment of this 100 MWac system's entire CAPEX as eligible needs particular scrutiny. [P03]

> **Tax research pending — FIN-04.** Establish construction and service dates, eligible basis, equipment and ownership/control chains, wage/apprenticeship compliance, credit rate, monetization timing/discount, basis reduction, depreciation, recapture and transaction costs. Compare ITC and PTC on consistent after-tax cash flows only when supported. The 30% value is an analytical assumption, not an available statutory entitlement for this system.''')
replace('## 10.8 Historical price-year','## 10.9 Historical price-year')
replace('10.8 |','10.9 |')
replace('Section 10.8','Section 10.9')
# Historical price vintage and rates.
insert='Positive cases are therefore not exclusive to 2023.'
i=s.index(insert)
s=s[:i]+'''**Currency qualification.** The historical price files retain their original nominal numerical levels. The financial experiment reuses each level as a constant-real-2025 scenario assumption; 2023 and 2024 prices were not CPI-converted before reuse. These are fixed-cost scenario contrasts, not fully inflation-harmonized historical investment returns. The original estimates are retained.

**Table 10-5. Discount-rate sensitivity of same-year median NPV; $m.**

| Real discount rate | 2023 setting | 2024 setting | 2025 setting |
|---|---:|---:|---:|
| 4.27% | +99.78 | −81.59 | −81.26 |
| 6% | +58.61 | −91.68 | −91.40 |
| 8% | +23.55 | −100.34 | −100.12 |

*Source: existing annual cash-flow cost stream and frozen same-year receipts [E-A]; panel arithmetic, 485-node common-calendar sample. No new price forecast or regression.*

> **Comparable-return and currency research pending — FIN-01 / FIN-07.** Match actual project return definitions, discount-rate inputs and cash-flow risk; produce a separately labeled CPI-harmonized price-year scenario. No observed comparable project IRR or appropriate investor hurdle is established in this edition.

'''+s[i:]
replace('(2) Taxes, credit eligibility, financing, land, insurance, network upgrades and several market-service costs remain unverified.','(2) Actual taxes, credit eligibility, financing and complete project costs remain unverified; benchmark expense coverage needs reconciliation.')
# Main decomposition: means add; methods in appendix.
section('## 11.7 Price levels','## 11.8 Tail dependence', '''## 11.7 The change comes mainly from the price setting

Changing price and weather together from 2023 to 2024 reduces mean NPV by $179.31m across the 485 nodes. An allocation that splits the interaction equally assigns −$174.68m to the price profile and −$4.63m to weather: about 97% and 3% of the net decline. This is model accounting, not an explanation of what caused market prices to change. [E-A]

The separate accounting table below asks how changes in total volume, average price, output-price timing and the negative-price operating rule combine. **Means are used so the displayed contributions add to the displayed total**, apart from rounding. This is a second allocation of the same change, rather than a breakdown of the price contribution above.

**Table 11-2. Mean contributions to the NPV change across 485 nodes; $m.**

| Transition | Volume | Average price | Output-price timing | Export-rule adjustment | Total |
|---|---:|---:|---:|---:|---:|
| 2023 to 2024 | +5.64 | −102.49 | −83.13 | +0.67 | −179.31 |
| 2023 to 2025 | +6.36 | −72.24 | −114.08 | +1.88 | −178.08 |
| 2024 to 2025 | +0.42 | +17.74 | −18.13 | +1.21 | +1.23 |

*Source: existing node-level component outputs [E-A], arithmetic means. Original estimates are unchanged; the summary statistic is changed from separate medians to additive means. Definitions and alternative accounting are in Appendix B.*

![Figure 11-4. Mean components and total NPV change](figures/Panel_Mean_Decomposition.png)

*Source: same component means as Table 11-2. Markers show totals; bars show accounting contributions, not causal effects.*

From 2024 to 2025, the average-price improvement is largely offset by less favorable output-price timing. This distinction matters commercially: a higher annual average price alone does not guarantee better solar receipts. Historical price currency treatment is stated in Section 10.9.

**Table 11-3. Financial effects in NPV dollars, with comparison boundaries.**

| Controlled comparison | Change in NPV, $m | Starting point and interpretation |
|---|---:|---|
| 2023 to 2024 same-year setting | −179.31 | Mean across 485 nodes; both weather and prices change |
| U.S. module input −10% | +3.76 | 2025 reference; PV overnight scope, connection unchanged |
| U.S. module input −30% | +11.29 | Same reference; hypothetical procurement sensitivity |
| Reference export profile +10% | +10.14 | Same reference; shape and unit prices unchanged |
| Illustrative nominal 30% credit | +40.33 | Same reference; assumed eligibility and end-2027 cash receipt |

*Source: existing components and frozen cash flows; panel calculations. Dollar units are shared, but baselines and perturbation sizes differ. Rows are neither equally likely nor an empirical ranking of investment drivers; combined effects may interact.*''')
# Tail: causal event contextual only; postRTC correct.
needle='The best-hours stress statistic gives a median of about 23 hours.'
i=s.index(needle)
s=s[:i]+'''A gentler cap at the 99.9th percentile leaves the 2023 median NPV at approximately +$98.25m, whereas the 99th-percentile cap gives −$10.61m. This difference identifies sensitivity to a broader upper tail rather than just the most extreme 0.1%. The scarcity-date stress replaces those dates' prices with the median-day price profile while retaining output and costs; it is not the deletion of whole operating days. Across nodes its median count is 34 flagged dates. [E-C]

ERCOT initiated an Energy Emergency Alert Level 2 on 6 September 2023, reporting a September peak of 82,705 MW. That official event provides context for the high-price environment; this study has not matched its individual revenue intervals to event or constraint records. ERCOT subsequently launched real-time co-optimization of energy and ancillary services with its battery enhancements on **5 December 2025**. Thus 2023–2024 predate the change and **2025 straddles it**; the whole three-year sample must not be described as pre-reform. No causal battery or reform effect is estimated. [P05, P06]

> **Market-regime research pending — FIN-08.** Obtain finalized post-launch prices, outages, available capacity, imports, constraints and battery dispatch; separate rule changes from weather and fleet changes before choosing future merchant scenarios. Three historical years supply no repeat probability for 2023 scarcity receipts.

'''+s[i:]
replace('excluding dates containing an interval at or above $1,000/MWh produces a median around -$82.5 million','replacing prices on dates containing an interval at or above $1,000/MWh with the median-day profile produces a median around −$82.5 million')
needle='An equal-weight average of each node\'s first-year receipts across the three years gives a median NPV of approximately -$21.4 million, with 12.2% of sampled nodes positive.'
replace(needle,needle+''' A separate break-even calculation mixes the 2023 receipts with the average of 2024–2025 receipts: the median node needs approximately **44.9%** of discounted revenue weight assigned to the 2023 setting; the reference needs **47.7%**. These are analytical mixture weights, not probabilities or an integer count of profitable years. The timing of high-price years matters because earlier receipts carry more present value.''')
replace('(2) Decomposition components are accounting contributions; component medians need not add.','(2) Main-table component means add to their mean total; accounting contributions are not causal effects.')
# Hypothesis strength, without generalizing company observations.
replace('## 12.3 Value-chain hypothesis — Mixed','## 12.3 Value-chain hypothesis — Supported for the observed businesses')
section('MIIT price observations, LONGi segment margins,','**What this means for you.** Assess company-specific', '''The existence claim is supported within the observed businesses: large manufacturing scale and falling upstream prices coexist with weak or negative reported profitability. The FY2025 Trina, JA Solar and Tongwei disclosures provide direct loss observations, alongside the other annual company evidence. This is stronger than merely being consistent with pressure, but it establishes neither industry-average profitability nor its cause. [S01, S02, R-D, R-F]

Product mix, technology, incentives, impairment charges, utilization and working-capital changes remain alternative explanations. Industry-wide or causal conclusions require matched segment production, prices, capacity, costs and inventory. The observations also do not measure the pass-through to a U.S. asset's delivered cost.''')
replace('| Mixed | Expanded company panel and model-based revenue decompositions show different outcomes across stages |','| Supported as an existence claim for the observed businesses | Annual losses and company-specific margins alongside large manufacturing scale |')
replace('GAP-08 still limits','the missing customer-level evidence still limits')
replace('GAP-09 remains the relevant research route.','Direct constraint and settlement evidence remains the relevant research route.')
# Remove governance appendix and external-facing file indexes, preserving all in internal attachment.
appendices=s[s.index('# Appendix A.'):]
(D/'internal/Baseline-Appendices-A-to-E.md').write_text(appendices)
oldb=s[s.index('# Appendix B.'):s.index('# Appendix C.')]
s=s[:s.index('# Appendix A.')]
sources=original[original.index('**S01.'):original.index('**Table A-1.')]
sources=sources.replace('**S01.** MIIT-2024-FUJIAN-REPUBLICATION (2024):','**S01.** Ministry of Industry and Information Technology, 2024 national photovoltaic manufacturing bulletin (published 27 February 2025); supplied original PDF and Fujian official republication:')
sources=sources.replace('**S02.** LONGI-2024-ANNUAL-REPORT (FY2024):','**S02.** LONGi Green Energy, Annual Report FY2024:')
sources=sources.replace('**S03.** IRENA-2026-CAPACITY-STATS (2016-2025):','**S03.** IRENA, Renewable Capacity Statistics 2026 (2016–2025 series):')
sources=sources.replace('**S04.** LBNL-2025-UPDATE-DOE (2030 modeled; publication June2026):','**S04.** Berkeley Lab / DOE, United States Data Center Energy Usage Report, 2025 update (published June 2026; modeled 2030):')
sources=sources.replace('Form 20-F for FY2025 (2026-04-29):','JinkoSolar Holding, Form 20-F FY2025 (29 April 2026):').replace('Form 20-F for FY2025 (2026-04-10):','Canadian Solar, Form 20-F FY2025 (10 April 2026):').replace('Form 20-F for FY2025 (2026-04-20):','Daqo New Energy, Form 20-F FY2025 (20 April 2026):').replace('Form 10-K for FY2025 (2026-02-24):','First Solar, Form 10-K FY2025 (24 February 2026):')
sources+= '''**P05.** ERCOT, Energy Emergency Alert Level 2, 6 September 2023: [official release](https://www.ercot.com/news/release/2023-09-06-ercot-has-initiated).

**P06.** ERCOT, real-time co-optimization and battery-enhancement launch, 5 December 2025: [official release](https://www.ercot.com/news/release/12052025-ercot-goes-live).

**P07.** National Development and Reform Commission, explanation of renewable market-pricing reform, 9 February 2025: [official explanation](https://www.ndrc.gov.cn/xxgk/jd/jd/202502/t20250209_1396070.html).

**P08.** Ministry of Finance / State Taxation Administration, 2026 announcement no.2, export VAT rebate adjustment: [official announcement](https://szs.mof.gov.cn/zhengcefabu/202601/t20260109_3981637.htm).

**P09.** ERCOT, implementation of the Bus Average 345-kV Hub under NPRR817, 2019 market notice: [official notice](https://www.ercot.com/services/comm/mkt_notices/archives/4100).

**P10.** NLR, Utility-Scale PV, ATB 2025, including fixed O&M definition: [official technology documentation](https://atb.nlr.gov/electricity/2025/utility-scale_pv).

**Panel calculations.** Arithmetic sensitivities and summary tables derived from the existing scenario and empirical outputs. No regression, physical simulation, decomposition estimation or resampling is rerun for this edition. Inputs and reproducible transformations accompany the research files.
'''
s+='# Appendix A. Source Bibliography\n\nBracketed identifiers refer to source families. Official observations and research calculations remain distinct; repeated use of one source is not independent corroboration. Annual periods, publication dates and projection years are stated separately.\n\n'+sources
s+='''
# Appendix B. Methods and Interpretation

## B.1 Market data and node selection

ERCOT NP6-905-CD supplies 15-minute real-time settlement-point prices. Delivery date, hour, interval and DST flag determine UTC timestamps. The local-year grid has 35,040 intervals, or 35,136 in leap-year 2024. Shared unpublished intervals are excluded from all points, with no interpolation or zero fill: three intervals in 2023, one in 2024 and two in 2025. The daytime 2023 gaps coincide with about 47.6 MWh of simulated energy. Hubs and load zones remain distinct benchmark types.

The 641-node cross-section requires RN type, membership in the 10 September 2026 official list and coverage in 2025. The 485-node panel adds three-year common coverage. The earlier 757-point mixed-type count is excluded from resource-node conclusions. Coverage rules favor continuously observed points and need not represent future entrants; commissioning dates have not been reconciled. Sample fractions describe the screened population and are not investment probabilities.

The weather-price matrix uses a fixed UTC−6 calendar key, drops 29 February and intersects valid intervals across years. Full-year reference NPV is approximately +$97.76m, −$91.84m and −$85.97m for 2023–2025; common-calendar values are +$97.76m, −$92.15m and −$85.97m. The 2024 difference is mostly the leap-day exclusion. Common-calendar results are labeled throughout the comparison tables.

The original 2025 system intraday exhibit uses 363 non-DST dates and 8,712 hours; the seasonal exhibit retains 365 dates. The added residual-load exhibit instead uses all 2025 hourly observations grouped by America/Chicago civil hour. Fuel-mix average MW is consistent with hourly load MW; residual load subtracts wind and solar only. It is not net of all supply or storage.

## B.2 Output and financial conventions

The hypothetical system is 100 MWac / 132 MWdc in one Pecos County NSRDB location (identifier 1142134), simulated with PVWatts v8 through PySAM 7.1.1. Design, losses and degradation remain as stated in Chapter 9. It is neither an operating-plant measurement nor a county average. Leap-day output uses a neighboring-day approximation; comparing two such approximations changes annual energy by about 0.002%, which is not a bound on actual leap-day error.

End-2026 CAPEX and 30 operating years from 2027 are valued in real 2025 dollars at a 2026 valuation point. For the unchanged base price shape, NPV = 15.471935 × first-year real receipts − $187.321206m. The intercept includes CAPEX and discounted FOM, replacement and decommissioning. Different price trends or fixed nominal receipts need their own cash-flow evaluation.

Historical price files are not CPI-harmonized before the multi-year financial experiment; each original numerical level becomes a constant-real scenario input. This convention preserves the existing estimates but differs from a same-purchasing-power historical comparison. The base ATB cost conversion uses CPI-U from 2023 to 2025; the conversion alone does not harmonize those historical prices.

The original single-IRR field stays null for multiple-root and uncertified-root cases. Node base has numerical roots near −96.52% and −2.53%; node downside −24.85% and −8.60%; fixed base −48.21% and −2.60%; fixed upside −86.48% and +1.41%. Node upside has a unique reported root near −0.42%; fixed downside has no numerical root with completeness certified. Selecting the root nearest zero would not establish a unique investment return. NPV is the primary comparison.

ATB FOM includes system, property and administration allowances. Insurance and component-failure costs are among the published categories. The exact project budget, replacement overlap and any unrepresented costs remain open. Baseline returns exclude income tax, credits and financing; the separate nominal credit example is not an after-tax valuation.

## B.3 Conditional regressions and inference

Hourly benchmark-price regressions include solar, load, wind, Henry Hub daily gas prices, daily temperature summaries and calendar controls. Variants include nonlinear terms, date fixed effects, interactions, tail restrictions and a median regression. The solar-level coefficient in an interaction or nonlinear specification is not a constant marginal association. Actual solar output may respond to prices, and missing available capacity, outages, imports and constraints leave simultaneity and omitted-variable concerns unresolved.

The principal hourly uncertainty estimates use heteroskedasticity- and autocorrelation-consistent errors with a 168-hour lag, with 24- and 336-hour alternatives. Block checks preserve contiguous observations; details and successful/failed fits remain in the accompanying technical outputs. Negative-price models use hourly means rather than interval-level events; failed or nonconvergent models are not treated as null findings. Three years provide limited regime variation. No instrument, natural experiment or other causal design is used.

![Figure B-1. Conditional solar-price coefficients across model choices](figures/empirical/F5_solar_price_association_forest.png)

*Source: unchanged coefficient and block-uncertainty tables [E-B]. Coefficients are conditional associations. The held-out prediction comparison is weaker than simple averages and does not justify future price forecasts.*

## B.4 Accounting contributions and tail stresses

Weather/price Shapley allocation divides their interaction equally. Log-mean Divisia index (LMDI) accounting instead splits the change into volume, average price and output-price matching, with the export-rule change recorded separately. These are alternative identities, not a nested causal model. Means in Table 11-2 add to the mean total; medians of separate components generally do not add. Original component estimates remain unchanged.

The top-price deletion holds costs fixed while removing receipts in selected intervals; percentile caps replace prices above the cap. The scarcity-date variant replaces prices on dates reaching $1,000/MWh with a median-day profile. The best-hours statistic accumulates the highest-receipt 15-minute intervals until the positive NPV buffer is exhausted. Each asks a different stress question. None is a correction to actual prices.

Within-year paired weather/price day-block resampling uses 2,000 draws and alternative block lengths. It conditions on that year's empirical regime; it is not season-stratified long-run uncertainty. Equal three-year receipt weights are chosen assumptions. The additional break-even mixture uses a discounted receipt weight for 2023 versus the average of the other two years; it does not estimate a frequency or an optimal sequence of years.

# Appendix C. Research Agenda and Unresolved Evidence

The report supports procurement screening, contract comparison and tests of capital-recovery conditions. A verified asset valuation still requires independently documented location, generation, settlement, contract, all-in costs, tax eligibility and financing. Scenario results do not close those requirements.

| ID | Evidence still required | Result or decision it could change |
|---|---|---|
| FIN-01 | Definition-matched actual project/deal returns and discount-rate inputs | Whether return comparisons and hurdle rates are meaningful |
| FIN-02 | EIA-matched actual plant output, design, availability and curtailment | Generation calibration and uncertainty |
| FIN-03 | Node/hub PPA volume, price, tenor, negative-price and tail terms | Paid revenue, basis exposure and contract break-even |
| FIN-04 | Tax dates, basis, ownership/material origin, monetization and depreciation | Credit cash proceeds and after-tax returns |
| FIN-05 | Delivered quotes and complete cost/expense/interconnection crosswalk | Capital and operating cost coverage without double counting |
| FIN-06 | Historical node identity and verified plant-to-node mapping | Commercial applicability of location comparisons |
| FIN-07 | CPI-consistent historical prices and matched risk definitions | Purchasing-power-consistent historical scenarios |
| FIN-08 | Finalized post-December-2025 prices, outages, constraints and battery dispatch | Merchant scenario relevance after market changes |
| FIN-09 | Supplier liquidity, debt maturities, warranties, ownership and incentives | Procurement resilience and comparable producer economics |
| FIN-10 | Debt sizing, terms, reserves, covenants and tax-equity waterfall | Equity IRR, debt-service coverage and distributable cash |
| FIN-11 | Final-price versions, fees, RECs, losses and imbalance settlement | Net cash receipts and price-data finality |

Broader research remains open for a current manufacturing panel, comparable capacity/utilization/inventory, operational overseas factories and ownership, HTS-specific trade stacking, later like-for-like load statuses, local gas and identified congestion effects. Storage requires its own design, dispatch, degradation, incremental cost and contract case; it remains deferred. Three weather/price years provide neither validated P50/P90 nor a long-run regime probability.

> **Financing research pending — FIN-10 / FIN-11.** No debt-funded equity return is estimated. Comparable project IRRs must identify whether they are levered/unlevered, pre-/post-tax, target/realized and acquisition/development returns. Net market receipts also require fees, losses, imbalance and any renewable-certificate treatment. These missing inputs are not zero-cost assumptions.

# Appendix D. Glossary

| Term | Meaning |
|---|---|
| ERCOT | Electric Reliability Council of Texas; system and wholesale-market operator |
| MIIT / IRENA | China's Ministry of Industry and Information Technology / International Renewable Energy Agency |
| ATB / PVSCM | Annual Technology Baseline / Photovoltaic System Cost Model; national references |
| OCC / GCC / FOM | Overnight capital cost / grid-connection cost / fixed operating and maintenance expense |
| MWdc / MWac | Module DC capacity / rated AC capacity; cost denominators must match |
| NSRDB / PVWatts / PySAM | Solar resource database / generation model / Python interface to the System Advisor Model |
| Capture price / ratio | Output-weighted price / output-weighted price divided by time-weighted price |
| Basis / HB_BUSAVG | Node minus benchmark price / ERCOT Bus Average 345-kV Hub |
| PPA / VPPA | Power purchase agreement / financial contract settled against a price reference |
| LCOE / NPV / IRR | Levelized energy cost / discounted net cash value / zero-NPV discount rate |
| WACC / DSCR | Weighted average cost of capital / debt-service coverage ratio |
| ITC / PTC / PFE | Investment tax credit / production tax credit / prohibited foreign entity |
| P50 / P90 | Output exceeded with specified probability over a stated horizon; not established here |
| HS / HTS / IEEPA | Harmonized trade classifications / U.S. tariff schedule / emergency economic powers statute |
| OCF / PPE / LLA | Operating cash flow / property, plant and equipment / long-lived assets |
| RMSE / HAC | Prediction-error measure / serial-correlation-robust uncertainty method |
| Batch Zero / WLPUN | Transitional large-load process / withdrawal-limited private-use network |
'''
# Replace repetitive placeholder captions without discarding nearby qualifications.
s=s.replace('the corresponding source table','the accompanying scenario and source tables [S08]')
s=s.replace('energy_gwh is potential simulated energy; tw is the time-weighted price; gw is the generation-weighted price; gw_curt is the delivered-energy-weighted price after the assumed negative-price shutdown.','Potential generation, time-weighted price, potential-output-weighted price and delivered-energy-weighted price after shutdown are shown separately.')
s=s.replace('original exhibit F2 (reproduced here as Figure 11-3) and 3×3 tables','weather-price comparison tables')
s=s.replace('original exhibit F4 (reproduced here as Figure 11-5) and tail tables','tail-stress tables')
s=s.replace('original exhibit F8 (reproduced here as Figure 11-6)','within-year resampling and mixture tables')
s=s.replace('weather cell','weather location')
s=s.replace('Sections 8.5–8.8, 10.8','Sections 8.5–8.8, 10.9')
# Editorial reconciliation after reviewing the underlying stress implementation.
s=s.replace('replacing prices on dates containing an interval at or above $1,000/MWh with the median-day profile produces a median around −$82.5 million','removing receipts on dates containing an interval at or above $1,000/MWh produces a median around −$82.5 million')
s=s.replace("The scarcity-date stress replaces those dates' prices with the median-day price profile while retaining output and costs; it is not the deletion of whole operating days.","The quoted scarcity-date stress removes those dates' energy receipts while retaining costs. A separate retained variant replaces daily receipts with the median receipts of nonflagged dates; it does not replace an interval price profile.")
s=s.replace('The scarcity-date variant replaces prices on dates reaching $1,000/MWh with a median-day profile.','The quoted scarcity-date variant deletes daily receipts on dates reaching $1,000/MWh; a separate variant replaces each flagged daily receipt with the median nonflagged daily receipt.')
s=s.replace('The earlier $41.34m example treated the receipt as 30% of real CAPEX paid a year later. The nominal-payment convention above is a distinct, explicit timing assumption; neither illustration establishes the legally eligible basis or actual cash proceeds.','This nominal-payment convention fixes the construction-year nominal credit amount until its receipt a year later. It establishes neither the legally eligible basis nor actual cash proceeds.')
s=s.replace('For the component-price example, an 8.9% capital saving closes about 14.9% of the reference gap.','For the component-price example, a 10% U.S. module-input reduction saves $3.76m and leaves reference NPV at −$82.20m.')
s=s.replace('8.9% CAPEX example closes 14.9% of reference NPV gap','10% module-input reduction improves reference NPV by $3.76m')
s=s.replace('the IRENA tables place','The IRENA tables place')
s=s.replace('Underlying table: the accompanying scenario and source tables [S08]. China',"Capacity series [S03]. China")
s=s.replace('Underlying table: the accompanying scenario and source tables [S08]. Coverage is all U.S.', 'Demand-scenario table [S04]. Coverage is all U.S.')
s=s.replace('Underlying table: the accompanying scenario and source tables [S08]. The sample covers 363','System hourly profile [S05]. The sample covers 363')
s=s.replace('*Underlying table: the accompanying scenario and source tables [S08]. All 365','*Source: ERCOT system seasonal aggregation [S05]. All 365')
s=s.replace('*Underlying table: the accompanying scenario and source tables [S08]. Potential generation','*Source: monthly generation and price pairing [S07, S08]. Potential generation')
s=s.replace('Cash flows are recomputed for each grid cell.','Each plotted cell is an existing cost/price combination.')
s=s.replace('The input register identifies workbook rows 52–68.','ATB workbook financial assumptions are the reference inputs.')
s=s.replace('S3_scenario_outcomes.png','Panel_Scenario_NPV.png').replace('Scenario economics and controlled IRR reporting','Scenario NPV under three real discount rates')
s=s.replace('figures/S04_passthrough.png','figures/Panel_Module_Transmission.png')
s=s.replace('*Underlying table: the accompanying scenario and source tables [S08]. Initial capital expenditure, operating flows, replacement, and decommissioning are separately recognized.*','*Source: original annual cash flows [S08]. Initial capital expenditure, operating flows, replacement and decommissioning are separately recognized. Bars are clipped at ±$20m; the initial capital bar extends beyond the axis range.*')
s=s.replace('one current classification snapshot.*','one current classification snapshot. The right panel displays basis volatility only up to $200/MWh; some nodes exceed this range.*')
s=s.replace('**R-T (formerly R2-A).**','**R-T.**').replace('**R-F (formerly R2-D).**','**R-F.**')
s=s.replace('**Table 10-4. Dates','**Table 10-3. Dates').replace('**Table 10-3. Same-year','**Table 10-4. Same-year')
s=s.replace('![Figure 4-2. Within-company','![Figure 4-3. Within-company')
s=s.replace('The earlier 757-point mixed-type count is excluded from resource-node conclusions. ','')
s=s.replace('sampled nodes','screened nodes')
s=s.replace('A verified common nameplate-Wdc denominator and product/origin/exception match are **not disclosed in this edition**.','A common nameplate-Wdc denominator and product/origin/exception match have not been established.')
pos=s.index('**Table 11-1. Break-even conditions under base assumptions.**');end=s.index('\n\n*Source:',pos)
s=s[:end]+'\n| Flat nominal contract, no unpaid energy; 4.27% only | $55.91/MWh | — | — |'+s[end:]
pos=s.index('| Test whether a lower module quote is material |');end=s.index('\n',pos)
s=s[:end]+'\n| Qualify supplier and equipment eligibility | Official timing and ownership/material-assistance provisions | Establish project eligibility, eligible basis and supply-chain documents | Illustrative $40.33m credit benefit is conditional, not an entitlement |'+s[end:]
s=s.replace('The simpler pooled estimates are approximately','The pooled linear specifications (excluding the nonlinear/interaction model) are approximately')
s=s.replace('Alternative explanations include changes in technology, non-module scope, trade treatment, and delivery terms.','Alternative explanations include changes in technology, non-module scope, delivery terms, trade duties and tax-credit eligibility tied to equipment origin and supplier ownership.')
s=s.replace('## 14.2 Conditional market developments\n','## 14.2 Conditional market developments\n\nOn the supply side, a sustained reduction in manufacturing output relative to sales could firm equipment prices and reduce the module savings tested in Chapter 5. Continued price competition could lower factory prices further, while delivered U.S. savings would still depend on product access, duties, logistics and tax eligibility. These are conditional paths; no success probability is assigned to industry consolidation or production restraint.\n')
s=s.replace('| Manufacturing supply | Comparable output, effective capacity, inventory, specification-consistent prices | Competitive conditions and procurement interpretation |','| Manufacturing supply | Stage-specific output, shipments, inventory days, utilization with matched capacity denominators, product-specific prices | Whether production restraint is followed by sustained price/margin recovery |\n| Trade and tax policy | Product/origin/date-specific customs rules; equipment and ownership eligibility; construction/service milestones | Delivered cost and credit eligibility |')
for ident,label in [('node_downside','Node downside'),('node_upside','Node upside'),('node_base','Node base'),('fixed_downside','Fixed downside'),('fixed_upside','Fixed upside'),('fixed_base','Fixed base')]:
 s=s.replace(ident,label)
# Existing output data permit a screened-versus-excluded comparison without new estimation.
co=list(csv.DictReader((D/'data/panel/Coverage-Cohort-Comparison-2025.csv').open()))
text='\n**Table B-1. Coverage-screen comparison using the original 2025 cross-section.**\n\n| Coverage cohort | Nodes | Median output-weighted price, $/MWh | Mean output-weighted price, $/MWh |\n|---|---:|---:|---:|\n'
for r in co:text+=f"| {r['cohort']} | {r['n']} | {float(r['median_capture_price']):.2f} | {float(r['mean_capture_price']):.2f} |\n"
text+='\n*Source: original 2025 eligible-node screen, same reference output weights; three-year cohort membership from the existing matrix. The 156 points outside the common panel are not labeled new plants; their commissioning histories are unverified. Different coverage cohorts are not a randomized comparison.*\n\n'
where='## B.2 Output and financial conventions';i=s.index(where);s=s[:i]+text+s[i:]
z=list(csv.DictReader((D/'data/panel/Positive-Node-Zones.csv').open()))
zs='; '.join(f"{r['zone'].replace('LZ_','').title()} {r['positive_nodes']}" for r in z if r['price_year']=='2024')
s=s.replace('Positive cases are therefore not exclusive to 2023.',f'The 13 positive 2024 nodes are distributed across the mapped load zones as follows: {zs}. The mapping is descriptive and does not identify an actual asset portfolio.\n\nPositive cases are therefore not exclusive to 2023.')
where='## B.3 Conditional regressions';i=s.index(where)
s=s[:i]+'''**Contract risk allocation: structural comparison, subject to the actual agreement.**

| Exposure | Merchant node sale | Simplified node PPA | Hub-settled financial PPA |
|---|---|---|---|
| Output and availability | Seller | Seller unless contracted otherwise | Seller; contracted quantity may differ from output |
| Timing/shape | Seller | Depends on paid volume and delivery obligation | Generation-versus-contract shape and hedge reference matter |
| Node-to-hub basis | Embedded in node price | No separate hub leg in this simplified route | Seller retains node-minus-hub exposure if quantities match |
| Negative prices | Dispatch and incentive decision | Payment suspension and delivery clauses determine exposure | Physical node receipts and financial hub settlement both matter |
| Policy and counterparty | Owner's tax and market exposure | Allocation, change-in-law and credit terms required | Same, plus collateral and financial-settlement obligations |

'''+s[i:]
where='The principal hourly uncertainty estimates use';i=s.index(where)
s=s[:i]+'''The out-of-sample exercise fits 2023–2024 and predicts 2025. Unseen year-month fixed-effect columns are set to the training base, so level shifts are not supplied as known future effects. The hour-of-week comparator is the training-sample mean for each weekday/hour; the constant comparator is the training mean. The error comparison tests this forecast construction rather than a model supplied with realized 2025 fixed effects.

'''+s[i:]
where='## 4.5 Common-period'
i=s.index(where)
s=s[:i]+'''![Figure 4-2. Evidence links from manufacturing to U.S. procurement](figures/Panel_Supply_Route.png)

*Source: analytical framework based on the manufacturing, trade and tax evidence [S01, R-T, P01–P03, P07–P08]. Boxes describe evidence requirements, not measured trade routes, capacity or eligibility.*

'''+s[i:]
s=re.sub(r'\bretained\s+', '', s, flags=re.I)
s=s.replace('The spending measure is the under its filing definition','The spending measure follows each filing’s definition')
s=s.replace('FY2025 A-share annual reports and a consistent multi-company capacity panel remain necessary before drawing broader cycle or utilization conclusions.','The A-share FY2025 filings are incorporated in Section 4.7; a consistent multi-company capacity and utilization panel remains necessary before broader cycle conclusions.')
s=s.replace("LONGi's FY2024 disclosures provide reported utilization and production measures for its own operations. Those company-defined measures can support a within-company discussion when the production boundary and effective-capacity denominator are used. They describe LONGi, not industry-average utilization.","A comparable utilization measure requires a period-average effective-capacity denominator and a matched production boundary. No harmonized industry utilization rate is supplied here.")
s=s.replace('Tongwei includes feed-related activities,','Tongwei reports approximately CNY54.14bn of PV-segment revenue, distinct from its CNY84.13bn group revenue including feed-related activities,')
s=s.replace('Currencies are not converted, so cash levels are not a cross-company ranking.','Currencies are not converted, so cash levels are not a cross-company ranking. The panel covers reporting listed businesses and excludes exits and smaller unlisted producers; the direction of industry-wide selection bias is unestimated. U.S.-listed parents and any Chinese-listed subsidiaries have different consolidation boundaries.')
s=s.replace('## 12.5 Storage hypothesis — Not testable','## 12.5 Storage hypothesis — Not yet tested')
s=s.replace('| Not testable; deferred | Negative-price exposure','| Not yet tested; deferred | Negative-price exposure')
s=s.replace('Median lifetime NPV, $m','Median NPV if the setting repeats for 30 years, $m')
s=s.replace('the block includes 58 Pecos County cells','The block includes 58 Pecos County weather locations').replace('same cell','same weather location').replace('other sampled cells','other sampled weather locations').replace('the sampled spatial sample','the sampled locations').replace('reference cell','reference weather location')
s=s.replace('Variables include irradiance, temperature, wind speed and surface albedo; data-quality flags are documented in Appendix B.','Variables include irradiance, temperature, wind speed and surface albedo; source quality flags remain part of the generation-input qualifications.')
s=s.replace('Fill flags, leap-day approximation, time mapping and performance uncertainties are detailed in Appendix B.','Weather-quality flags and performance uncertainties remain open; leap-day approximation and time mapping are described in Appendix B.')
start=s.index('The best-hours stress statistic gives a median of about 23 hours.');end=s.index('## 11.9',start)
s=s[:start]+'''The best-hours statistic has a median of about 23 accumulated hours, with node-level values from 1 to 198.25 hours among positive 2023 cases. It sorts 15-minute intervals by modeled receipts and removes them until the NPV surplus is exhausted. The intervals need not be consecutive or identifiable in advance. This measures the narrow revenue buffer, not a schedule of hours a developer can guarantee. [E-C]

'''+s[end:]
s=s.replace('![Figure 11-5. Revenue concentration and tail stresses]','![Figure 11-5. Revenue concentration and tail stresses: reference node only]')
s=s.replace('![Figure 11-6. Within-year resampling and a three-year mixture setting]','![Figure 11-6. Reference-node resampling and the screened-node mixture distribution]')
s=s.replace('Calendar mapping and common exclusions are held fixed, using the fixed UTC-6 calendar key and disclosed DST correspondence described in Section 8.4.','Calendar mapping and common exclusions are held fixed, using the fixed UTC−6 calendar key described in Appendix B.1.')
s=s.replace('non-DST dates','dates excluding the two DST transition days')
s=s.replace('the non-DST-day sample','The sample excluding the two DST transition days')
s=s.replace('illustrative credit in Section 10.9','illustrative credit in Section 10.8')
s=s.replace('| Currency | Basis |','| CCY | Basis |')
s=s.replace('LLA cash is cash paid for fixed, intangible and other long-lived assets; The','LLA cash is cash paid for fixed, intangible and other long-lived assets. The')
s=s.replace('Cash flows are recomputed for each weather location.','Each plotted cell is an existing cost/price combination.')
s=s.replace('approximately NPV = 15.47 × receipts − $187.3 million.','approximately NPV = 15.47 × receipts − $187.3 million for the constant-real nodal route. Each extra $1m of first-year real receipts adds approximately $15.47m to NPV under this convention; the identity does not apply directly to the flat nominal contract.')
where='## 13.2 Developers';i=s.index(where)
s=s[:i]+'''**Questions for a U.S. procurement contract.**

| Question | Evidence required before signing |
|---|---|
| Who pays if trade treatment changes after signing? | Change-in-law, price adjustment and termination provisions |
| Who is responsible for customs entry and duties? | Importer-of-record identity and delivery terms |
| Can materials and their origins be traced? | Documented upstream sourcing and customs-compliance evidence |
| Can ownership and equipment eligibility be substantiated? | Ownership/control records and applicable tax eligibility documents |
| What happens if equipment is late or underperforms? | Delivery milestones, damages, acceptance and warranty remedies |
| What does the quoted price include? | Common specifications, DC basis, freight, taxes, insurance and warranty scope |

An equipment-only supplier should demonstrate the delivered product and service obligations. An integrated equipment/development business also needs to explain asset risk, ownership and financing; a component quotation does not establish those project economics.

'''+s[i:]
# Heading numbering already contiguous after removing 5.5a/10.7a; remove governance traces.
assert '# Appendix E.' not in s
assert '5.5a' not in s and '10.7a' not in s
out=D/'Integrated-Market-Research-Report-EN_Panel-Revised.md'
s=s.replace('The historical reference selection is documented in Section 8.1.', 'The reference choice and mapping limitation are discussed in Section 8.1.')
s=s.replace('Fixed-price thresholds retain the base unpaid-energy reduction, nominal-price convention, costs, and degradation.', 'Fixed-price thresholds retain the nominal-price convention, costs and degradation. The $55.91/MWh row pays for all potential generation; other fixed-price rows retain the base unpaid-energy deduction.')
out.write_text(s)
print(out,len(s.split()),'words')
