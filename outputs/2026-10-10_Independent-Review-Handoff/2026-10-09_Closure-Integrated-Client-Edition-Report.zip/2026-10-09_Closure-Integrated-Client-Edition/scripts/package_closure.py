from pathlib import Path,PurePosixPath
import zipfile,hashlib,csv,json,tempfile,subprocess,sys,shutil
D=Path(__file__).resolve().parents[1]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in D.rglob('__pycache__'):
 if p.is_dir():shutil.rmtree(p)
exclude={'File-Manifest.csv','SHA256SUMS.txt','Manifest.sha256'}
files=sorted(p for p in D.rglob('*') if p.is_file() and p.name not in ('.DS_Store',) and p.relative_to(D).as_posix() not in exclude)
part=lambda p:'supplement-sources' if p.relative_to(D).as_posix().startswith('closure-evidence/sources/') else 'report'
rows=[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':h(p),'package_part':part(p)} for p in files]
with (D/'File-Manifest.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['path','bytes','sha256','package_part']);w.writeheader();w.writerows(rows)
(D/'SHA256SUMS.txt').write_text(''.join(f"{r['sha256']}  {r['path']}\n" for r in rows))
(D/'Manifest.sha256').write_text(h(D/'File-Manifest.csv')+'  File-Manifest.csv\n')
files += [D/f for f in exclude]
zips=[];results={'archives':[]}
T=Path(tempfile.mkdtemp(prefix='solar-closure-handoff-'))
for category,suffix in [('report','Report'),('supplement-sources','Supplement-Sources')]:
 zpath=D.parent/(D.name+'-'+suffix+'.zip')
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files:
   if part(p)==category:z.write(p,D.name+'/'+p.relative_to(D).as_posix())
 assert zpath.stat().st_size<30_000_000,(zpath,zpath.stat().st_size)
 zpath.with_suffix('.zip.sha256').write_text(h(zpath)+'  '+zpath.name+'\n')
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  for n in z.namelist():assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
  z.extractall(T)
  results['archives'].append({'file':zpath.name,'bytes':zpath.stat().st_size,'sha256':h(zpath),'members':len(z.namelist()),'crc':'pass','safe_paths':'pass'})
E=T/D.name
errors=[r['path'] for r in rows if not (E/r['path']).exists() or h(E/r['path'])!=r['sha256']]
assert not errors
results['extracted_payload_hashes']={'files':len(rows),'mismatches':errors}
O=T/'fresh-output'
r=subprocess.run([sys.executable,'-P',str(E/'scripts/rebuild_closure.py'),'--output-dir',str(O)],capture_output=True,text=True)
results['handoff_rebuild']={'command':[sys.executable,'-P',str(E/'scripts/rebuild_closure.py'),'--output-dir',str(O)],'exit_status':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
assert r.returncode==0,r.stderr
results['handoff_output_comparison']={name:h(O/name)==h(D/name) for name in ['Integrated-Market-Research-Report-EN_Closure-Integrated.md','Integrated-Market-Research-Report-EN_Closure-Integrated.pdf']}
assert all(results['handoff_output_comparison'].values()),results['handoff_output_comparison']
results['extracted_directory']=str(E)
# The number checker requires the source companion and writes only its new support record.
r=subprocess.run([sys.executable,'-P',str(E/'scripts/check_integrated_numbers.py')],capture_output=True,text=True)
results['handoff_number_checks']={'exit_status':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
assert r.returncode==0,r.stdout+r.stderr
p=D.parent/(D.name+'-Package-Verification.json');p.write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
