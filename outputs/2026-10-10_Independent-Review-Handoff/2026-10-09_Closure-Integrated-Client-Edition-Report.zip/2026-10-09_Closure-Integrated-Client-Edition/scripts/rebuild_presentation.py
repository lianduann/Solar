"""Portable clean rebuild: arithmetic tables, charts and PDF, never regressions."""
import argparse,subprocess,json,shutil,os
from pathlib import Path
D=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out).resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Output must be empty')
out.mkdir(parents=True,exist_ok=True)
shutil.copytree(D/'scripts',out/'scripts',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
shutil.copytree(D/'data',out/'data',ignore=shutil.ignore_patterns('panel','finance'),dirs_exist_ok=True)
shutil.copytree(D/'finance-supplement',out/'finance-supplement',ignore=shutil.ignore_patterns('__pycache__','.mplcache'),dirs_exist_ok=True)
shutil.copytree(D/'sources',out/'sources',dirs_exist_ok=True)
(out/'support').mkdir(exist_ok=True);(out/'internal').mkdir(exist_ok=True)
for f in ['Baseline-Client-Readable.md','Baseline-Data-Hashes.json']:shutil.copy2(D/'support'/f,out/'support'/f)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(out/'.mplcache'));runs=[]
for script,args in [('derive_panel_tables.py',[]),('revise_manuscript.py',[]),('render_all_figures.py',[]),('verify_figure_fidelity.py',[]),('render_panel_figures.py',[]),('verify_panel_revision.py',[]),('integrate_finance.py',[]),('verify_finance_integration.py',[]),('build_pdf.py',['--src','Integrated-Market-Research-Report-EN_Finance-Integrated.md','--out','Integrated-Market-Research-Report-EN_Finance-Integrated.pdf'])]:
 cmd=[os.sys.executable,str(out/'scripts'/script),*args];r=subprocess.run(cmd,cwd=out,env=env,text=True,capture_output=True);runs.append(dict(command=cmd,exit_status=r.returncode,stdout=r.stdout,stderr=r.stderr));print(script,r.returncode,flush=True)
 if r.returncode:break
(out/'support/Clean-Rebuild-Receipt.json').write_text(json.dumps(runs,indent=2))
raise SystemExit(any(x['exit_status'] for x in runs))
