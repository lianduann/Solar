from pathlib import Path
import re,json
D=Path(__file__).resolve().parents[1];t=(D/'stages/P2.md').read_text()
t=re.sub(r'\bthe the\b','the',t,flags=re.I)
# Fill bare section headers with useful evidence requirements, not placeholders.
for marker,para in [
('## 4.4 Competitive analysis requiring further evidence','A matched competitive panel would align product technology, segment boundaries, currency, fiscal period, utilization denominator and the treatment of incentives. Until those definitions are comparable, Table 4-2 is a financial observation panel rather than an efficiency league table.'),
('## 5.4 Evidence required for an empirical transmission analysis','An empirical delivered-cost bridge needs matched module specifications, dates, origin, logistics, duties and procurement terms. The next section quantifies the conditional engineering-cost channel using national model inputs; it does not measure transaction-price transmission.'),
('## 6.4 Regional realization and procurement evidence','The regional process records below separate requests, approvals and observed energized load. Commercial qualification additionally needs a customer, connection date and specified procurement product; these are distinct from the national energy-demand scenarios.')]:t=t.replace(marker,marker+'\n\n'+para)
# Restore section 11.5 with a concise substantive question; detailed uncertainties are in B/C.
t=t.replace('## 11.6 Crossed','## 11.5 Remaining robustness questions\n\nThe central robustness question is whether capital recovery survives a different price year, removal of the highest-price intervals and alternative output-price pairing. Sections 11.6–11.9 answer these as historical stress tests, with no probability assigned to their recurrence.\n\n## 11.6 Crossed')
# Updates moved intact to internal governance appendix.
i=t.index('## 14.5 ');j=t.index('> **Limits of this chapter.**',i);update=t[i:j].replace('## 14.5 ','## E.1 ');t=t[:i]+t[j:];t+='\n\n'+update
# Visible source names and no bogus official URL for local research code.
t=t.replace('Scenario input register (finance parameters) (2026-10-07): [official source](n/a)','Scenario input register (finance parameters, 2026-10-07; local method, no official publication URL)')
t=t.replace('Scenario finance model code (unmodified) (2026-10-07): [official source](n/a)','Scenario finance model code (unmodified, 2026-10-07; local method, no official publication URL)')
t=t.replace('天合光能 2025年年度报告(全文)','Trina Solar, 2025 Annual Report').replace('晶澳科技 2025年年度报告(全文)','JA Solar, 2025 Annual Report').replace('通威股份 2025年年度报告(全文)','Tongwei, 2025 Annual Report')
# Replace any remaining Chinese catalog titles with English issuer titles, preserving the exact official URL.
a=t.index('**R-F (formerly');b=t.index('**E-S.',a);seg=t[a:b];seg=re.sub(r'[^\x00-\x7F]+[^:;]*?(?=\(FY2025)', '',seg) if False else seg
for company in ['Trina Solar','JA Solar','Tongwei']:
 m=re.search(r'[^;\n]*[\u4e00-\u9fff][^;\n]*',seg)
 if m:
  old=m[0];url=re.search(r'\[official source\]\(([^)]+)\)',old)
  if url:seg=seg.replace(old,f' {company}, 2025 Annual Report (calendar FY2025; FY2024 comparative): [official source]({url[1]})',1)
t=t[:a]+seg+t[b:]
# Financial basis: Canadian Solar source tag covers productive assets.
t=t.replace('| USD | Group; PPE cash |','| USD | Group; PPE cash |')
lines=t.splitlines();lines=[l.replace('Group; PPE cash','Group; productive-asset cash') if l.startswith('| Canadian Solar |') else l for l in lines];t='\n'.join(lines)+'\n';t=t.replace('PPE cash is cash paid for property, plant and equipment.','PPE cash is cash paid for property, plant and equipment; Canadian Solar’s extracted productive-asset cash line has a broader reported scope.')
# Remove obsolete above-table Shapley pointer after relocating the allocation.
t=t.replace('not subcomponents of the Shapley price contribution above','not subcomponents of the Shapley price contribution in Appendix B')
# Param cost case note, explicit clear ordering.
t=t.replace('The low/base/high costs follow the ATB Conservative/Moderate/Advanced technology cases, respectively in downside/base/upside order','Downside/base/upside costs follow ATB Conservative/Moderate/Advanced technology cases, respectively')
# Visible limitations register, disambiguate legacy duplicate GAP-13 without changing archival text.
gaps=re.findall(r'> \*\*\[(GAP-\d+)\s*\|[^\]]*\]\*\*\s*([^\n]+)',(D/'support/Original-Limits-and-Gaps.md').read_text());seen={};g=[]
for k,v in gaps:
 seen[k]=seen.get(k,0)+1;label=k if k!='GAP-13' else k+('a' if seen[k]==1 else 'b');g.append((label,v))
insert='\n\n**Research-limit index (legacy identifiers).** GAP-13a denotes sensitivity coverage; GAP-13b denotes the resampling/mixture limitation. The archival original is preserved with its original labels. No evidence gap is closed by editorial renaming.\n\n'
for k,v in g:insert+=f'**{k}.** {v}\n\n'
# Keep governance wording out of client C: archive raw status but use customer-friendly labels in gap index.
insert=insert.replace('original Version 1.0 acceptance remain unestablished','asset-specific validation remain unestablished').replace('Criterion 6','project-specific validation').replace('original fact-model','actual-asset model')
t=t.replace('# Appendix D. Glossary',insert+'# Appendix D. Glossary',1)
# Technical source fields move out of client output sections and remain in Appendix B.
t=t.replace('Generation is simulated with PVWatts v8 through PySAM 7.1.1.post1.','Generation is simulated with PVWatts; the software version is recorded in Appendix B.')
t=t.replace('2025 NSRDB GOES CONUS v4.0.0 extracts','2025 NSRDB weather extracts').replace('Variables include irradiance, temperature, wind speed, surface albedo, and fill flags.','Variables include irradiance, temperature, wind speed and surface albedo; data-quality flags are documented in Appendix B.')
t=t.replace('with the 49 unique identifiers. ','')
(D/'stages/P2.md').write_text(t);(D/'Integrated-Market-Research-Report-EN_Client-Readable.md').write_text(t)
print('Final editorial fixes; gap entries',len(g))
# Renderer supports the new regional subheadings.
p=D/'scripts/build_pdf.py';s=p.read_text();marker='    if line.startswith("## "): story.append';idx=s.index(marker);s=s[:idx]+'    if line.startswith("### "): story.append(Paragraph(inline(line[4:]), S["H2R"])); i += 1; continue\n'+s[idx:];p.write_text(s)
