"""Rebuild this edition from retained manuscript inputs, without executing models."""
from pathlib import Path
import argparse,subprocess,sys,json,tempfile,os,shutil
D=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path);a=p.parse_args()
O=(a.output_dir or D).resolve();O.mkdir(parents=True,exist_ok=True)
log=[]
env=dict(os.environ);env['MPLCONFIGDIR']=tempfile.mkdtemp(prefix='solar-mpl-')
for name,args in [('integrate',['integrate_closure.py']),('pdf',['build_pdf.py','--out',str(O/'Integrated-Market-Research-Report-EN_Closure-Integrated.pdf')])]:
 cmd=[sys.executable,'-P',str(D/'scripts'/args[0]),*args[1:]]
 r=subprocess.run(cmd,env=env,capture_output=True,text=True);print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
 log.append({'step':name,'command':cmd,'exit_status':r.returncode})
 if r.returncode:raise SystemExit(r.returncode)
if O!=D:shutil.copy2(D/'Integrated-Market-Research-Report-EN_Closure-Integrated.md',O)
(O/'rebuild-command-results.json').write_text(json.dumps(log,indent=2))
shutil.rmtree(env['MPLCONFIGDIR'])
