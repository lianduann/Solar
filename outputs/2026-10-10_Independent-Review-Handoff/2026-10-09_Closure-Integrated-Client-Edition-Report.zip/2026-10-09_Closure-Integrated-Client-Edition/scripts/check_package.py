"""Verify retained payload hashes; does not validate sources or research conclusions."""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parents[1];checks=[]
for line in (D/'SHA256SUMS.txt').read_text().splitlines():
 expected,name=line.split('  ',1);p=D/name
 if p.is_absolute() and not p.resolve().is_relative_to(D):raise SystemExit('Unsafe hash path')
 ok=p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected;checks.append((name,ok))
print(json.dumps({'checked':len(checks),'failed':[p for p,ok in checks if not ok]},indent=2))
raise SystemExit(any(not ok for _,ok in checks))
