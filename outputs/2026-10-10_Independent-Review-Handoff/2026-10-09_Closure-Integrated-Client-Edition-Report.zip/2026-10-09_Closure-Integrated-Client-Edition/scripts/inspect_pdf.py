from pathlib import Path
import argparse,json,fitz
from PIL import Image,ImageDraw
D=Path(__file__).resolve().parents[1];a=argparse.ArgumentParser();a.add_argument('file');a.add_argument('--all',action='store_true');x=a.parse_args();p=D/x.file;doc=fitz.open(p);out=D/'support/visual'/p.stem;out.mkdir(parents=True,exist_ok=True)
needles=['Key findings','Key numbers','Scenario settings','Six scenarios priced','11.7','Glossary','Appendix E.']
pages=list(range(len(doc))) if x.all else sorted(set([0,1,len(doc)-1]+[i for i,page in enumerate(doc) if any(s in page.get_text() for s in needles)]))
for start in range(0,len(pages),4):
 nums=pages[start:start+4]; sheet=Image.new('RGB',(1360,1820),'#dddddd');draw=ImageDraw.Draw(sheet)
 for j,i in enumerate(nums):
  pix=doc[i].get_pixmap(matrix=fitz.Matrix(1.07,1.07),alpha=False);im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);xx=j%2*680;yy=j//2*910;sheet.paste(im,(xx,yy+20));draw.text((xx+5,yy+3),f'{p.stem} page {i+1}',fill='black')
 sheet.save(out/f'sheet-{start//4+1:02d}.jpg',quality=90)
meta={'pdf':str(p),'pages':len(doc),'rendered_pages':[i+1 for i in pages],'sheets':(len(pages)+3)//4,'metadata':doc.metadata,'toc_entries':len(doc.get_toc())}
(out/'Render-Record.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
