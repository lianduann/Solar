"""New illustrative calculations from frozen cash flows/outputs only; no regression."""
from pathlib import Path
import json,csv,hashlib
import numpy as np,pandas as pd
D=Path(__file__).resolve().parents[1];data=D/'data'
m=pd.read_csv(data/'scenario_metrics.csv').set_index('scenario_id');cf=pd.read_csv(data/'scenario_annual_cash_flows.csv');be=json.loads((data/'breakevens.json').read_text());checks=json.loads((data/'price_pairing_checks.json').read_text())
reg={r['param_id']:r for r in csv.DictReader((data/'scenario_input_register.csv').open())};r=.0427
rows=[]
for route in ['node_base','fixed_base']:
 b=m.loc[route];c=cf[cf.scenario_id==route];v=c.net_cash_flow_real.to_numpy();t=c.t.to_numpy();df=(1+r)**(-t)
 # Evaluate existing Model.run cash-flow identity on already retained annual inputs.
 baseline=float(v@df);assert abs(baseline-b.npv_real_selected)<.01
 capex=float(b.capex_total_real);cut=.089;changed=v.copy();changed[t==0]+=capex*cut
 new=float(changed@df)
 rows.append(dict(scenario=route,case='8.9% CAPEX reduction',baseline_npv=baseline,new_npv=new,delta_npv=new-baseline,gap_closed_pct=(new-baseline)/abs(baseline)*100))
 # Pure hypothetical credit cash receipt at end of first operating year, no tax/accounting assumptions inferred.
 cash=.30*capex;credit=v.copy();credit[t==1]+=cash
 credited=float(credit@df)
 rows.append(dict(scenario=route,case='Illustrative 30% of total CAPEX cash credit in year 1',baseline_npv=baseline,new_npv=credited,delta_npv=credited-baseline,gap_closed_pct=(credited-baseline)/abs(baseline)*100))
creditpv=.30*m.loc['fixed_base','capex_total_real']/(1+r)
fixedc=cf[cf.scenario_id=='fixed_base'];fixedslope=float((fixedc.revenue_real/40/(1+r)**fixedc.t).sum())
pricecredit=be['fixed_breakeven_price_nominal_flat_at_0.0427']-creditpv/fixedslope
sens=pd.read_csv(data/'sensitivity_one_way.csv');off=sens[(sens.route=='node')&(sens.parameter=='curtail_node')].iloc[0]
# Existing as-available price and energy gives first-year receipts; NPV is copied from existing sensitivity output.
asavail=checks['generation_weighted_avg_price_as_available']*m.loc['node_base','sim_ac_mwh_yr1']
positive=pd.read_csv(data/'empirical/A_3x3_cells_by_node.csv');print('cell columns',list(positive.columns))
out={'cashflow_cases':rows,'credit_assumed_fraction_of_total_capex':.30,'credit_assumed_payment_t':1,'credit_breakeven_flat_nominal_price':pricecredit,'fixed_price_npv_slope':fixedslope,'as_available_receipts':asavail,'as_available_npv':float(off.npv_real_selected),'as_available_lcoe':float(off.lcoe_real_selected),'inflation_pct':float(reg['inflation']['base']),'fixed_base_nominal_year1':float(m.loc['fixed_base','delivered_mwh_yr1']*40),'fixed_base_real_year1_check':float(m.loc['fixed_base','delivered_mwh_yr1']*40/1.025**2),'discount_formula_real_pct':((.065*.7457+.08*(1-.7457))/1.025+1/1.025-1)*100,'source_scope':'Existing frozen annual cash-flow equation; initial CAPEX-only change and hypothetical first-year cash receipt. No eligibility or financing model.'}
(data/'Client-Illustrative-Calculations.json').write_text(json.dumps(out,indent=2)+'\n')
pd.DataFrame(rows).to_csv(data/'Client-Illustrative-Calculations.csv',index=False)
print(json.dumps(out,indent=2))
