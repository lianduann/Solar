from pathlib import Path
import json,re,hashlib,csv
import pandas as pd,numpy as np,fitz
D=Path(__file__).resolve().parents[1];O=D.parent/'2026-10-08_Integrated-Research-Release-Candidate-v0.5';src=D/'Integrated-Market-Research-Report-EN_Client-Readable.md';s=src.read_text();old=(D/'support/Baseline-v0.5.md').read_text()
def body(x):return x[x.index('# 1.'):x.index('# Appendix A.')]
b=body(s);terms=['retained','candidate','R2','first-round','second-round','fact-based model','fact-model','prohibited','acceptance','Criterion','editorial integration','.csv','.json'];counts={x:len(re.findall(re.escape(x),b,re.I)) for x in terms};assert not any(counts.values())
pat='does not establish|do not establish|cannot';negative={k:{'chapters_1_14':len(re.findall(pat,body(x),re.I)),'whole_manuscript_including_appendices':len(re.findall(pat,x,re.I))} for k,x in [('before',old),('after',s)]};assert negative['after']['whole_manuscript_including_appendices']<=25
chapters=re.split(r'(?m)^# (?=\d+\.)',b)[1:];assert len(chapters)==14 and all(c.count('Limits of this chapter')==1 for c in chapters)
# Exactly same propositions in introduction, individual discussion and table.
props=re.findall(r'\*\*Working hypothesis:\*\* ([^\n]+)',s);assert len(props)==5 and all(s.count(p)==3 for p in props)
# Preserve every inherited local data file byte for byte and original main manuscript.
unchanged=[]
for p in (O/'data').rglob('*'):
 if p.is_file():
  q=D/p.relative_to(O);assert q.exists() and p.read_bytes()==q.read_bytes(),p;unchanged.append(str(p.relative_to(O)))
assert (O/'Integrated-Market-Research-Report-EN.md').read_bytes()==(D/'support/Baseline-v0.5.md').read_bytes()
# All linked local files resolve. Network URLs inventoried, not fetched or recertified.
links=re.findall(r'\]\(([^)]+)\)',s);missing=[x for x in links if not x.startswith(('http','mailto','#')) and not (D/x).exists()];assert not missing,missing
m=pd.read_csv(D/'data/scenario_metrics.csv').set_index('scenario_id');ex=json.loads((D/'data/Client-Illustrative-Calculations.json').read_text());cf=pd.read_csv(D/'data/scenario_annual_cash_flows.csv');checks=[]
def ck(name,ok,source):assert ok,name;checks.append({'check':name,'passed':bool(ok),'source':source})
for case in ex['cashflow_cases']:
 r=m.loc[case['scenario']];ck(case['scenario']+' baseline',abs(case['baseline_npv']-r.npv_real_selected)<.01,'scenario_metrics.csv; annual cash flows')
 expected=r.capex_total_real*(.089 if case['case'].startswith('8.9') else .30/1.0427);ck(case['scenario']+' '+case['case'],abs(case['delta_npv']-expected)<.01,'initial CAPEX at t0; illustrative credit at t1')
ck('fixed price first year nominal to real',abs(ex['fixed_base_real_year1_check']-m.loc['fixed_base','revenue_real_yr1'])<.01,'scenario_metrics.csv; input inflation 2.5%')
cells=pd.read_csv(D/'data/empirical/A_3x3_cells_by_node.csv');z=cells[(cells.tier=='strict')&(cells.weather_year==cells.price_year)]
for yr,n in [(2023,485),(2024,13),(2025,2)]:ck(str(yr)+' positive node count',sum((z.price_year==yr)&(z.npv_4p27>0))==n,'A_3x3_cells_by_node.csv; strict same-year cells')
f=pd.read_csv(D/'data/empirical/A_decomposition_summary_strict_nodes.csv');ck('LMDI plot component set',set(['volume_lmdi','price_level_lmdi','match_lmdi','rule_effect']).issubset(set(f.component)),'A_decomposition_summary_strict_nodes.csv')
# PDF structure, page footer, outlines and finance table on one page.
pdf=fitz.open(D/'Integrated-Market-Research-Report-EN_Client-Readable.pdf');texts=[p.get_text() for p in pdf];finance=[i+1 for i,x in enumerate(texts) if 'Six scenarios priced at reference node' in x];assert len(finance)==1;page=texts[finance[0]-1];assert all(k in page for k in m.index)
# Main figures/tables uniquely and consecutively numbered within each chapter, excluding Table10-0 special setting.
figs=re.findall(r'^!\[Figure (\d+)-(\d+)\.',b,re.M);assert len(figs)==len(set(figs))
for ch in set(x[0] for x in figs):
 ns=sorted(int(y) for x,y in figs if x==ch);assert ns==list(range(1,max(ns)+1)),(ch,ns)
tabs=re.findall(r'^\*\*Table (\d+)-(\d+)\.',b,re.M);assert len(tabs)==len(set(tabs))
assert pdf.metadata['creationDate'].startswith('D:20261008')
result={'internal_term_counts_chapters_1_14':counts,'negative_phrase_counts':negative,'limits_boxes':14,'identical_working_hypotheses':5,'unchanged_inherited_data_files':len(unchanged),'unchanged_original_source':True,'local_link_count':sum(not x.startswith(('http','mailto','#')) for x in links),'missing_local_links':missing,'http_link_count':sum(x.startswith('http') for x in links),'http_retrieval':'not repeated; URLs drawn from retained source catalogs','new_numeric_checks':checks,'main_figures':len(figs),'unique_main_tables':len(tabs),'pages':len(pdf),'financial_table_page':finance[0],'outline_entries':len(pdf.get_toc()),'pdf_tagging':'not supported by the current renderer; not claimed','scope':'editorial and newly disclosed examples only; no regressions, simulation or research acceptance rerun'}
(D/'support/Client-Edition-Verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='new_numeric_checks'},indent=2));pdf.close()
