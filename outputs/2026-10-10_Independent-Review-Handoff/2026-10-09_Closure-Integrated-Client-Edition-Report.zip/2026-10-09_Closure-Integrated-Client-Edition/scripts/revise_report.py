"""Stage-wise editorial revision. Existing outputs are read, never overwritten."""
from pathlib import Path
import re,json,csv,argparse
import pandas as pd
D=Path(__file__).resolve().parents[1]; stage=argparse.ArgumentParser();stage.add_argument('--stage',choices=['P0','P1','P2'],required=True);a=stage.parse_args()
base=(D/'support/Baseline-v0.5.md').read_text(); x=json.loads((D/'data/Client-Illustrative-Calculations.json').read_text()); metrics=pd.read_csv(D/'data/scenario_metrics.csv').set_index('scenario_id')
t=base if a.stage=='P0' else (D/'stages'/('P0.md' if a.stage=='P1' else 'P1.md')).read_text()
def replace_section(start,end,new):
 global t
 i=t.index(start);j=t.index(end,i+len(start));t=t[:i]+new.strip()+'\n\n'+t[j:]
def before(marker,new):
 global t
 t=t.replace(marker,new.strip()+'\n\n'+marker,1)
def table(headers,rows):return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)
def simpleclean(s):
 # Preserve meaning while removing internal workflow labels from customer-facing prose.
 for old,new in [('empirical candidate','multi-year analysis'),('first-round','2025 cross-section'),('second-round','extended'),('second research round','extended analysis'),('R2-A','R-T'),('R2-D','R-F'),('R2','extended analysis'),('retained ','the '),('Retained ','The '),('supplemental','additional'),('supplement','analysis'),('candidate','research edition')]:s=s.replace(old,new)
 s=re.sub(r'\[([^\]]+)\]\(([^)]+\.(?:csv|json))\)',lambda m:'the corresponding source table',s)
 s=re.sub(r'\b[A-Za-z0-9_./-]+\.(?:csv|json)\b','source table',s)
 return s
limits={
1:'The headline case uses one historical reference node; its selection rationale and actual project settlement relationship are not disclosed in this edition. Returns exclude taxes, credit eligibility and debt. Historical-year repetition is a stress setting.',
2:'Source observations, accounting identities, conditional associations and hypothetical returns answer different questions. Prices, costs and demand are dated separately. See Box 1 and the technical notes for model boundaries.',
3:'Net capacity additions differ from shipments and manufacturing output. Country demand is not equipment origin. Inventory and effective capacity remain unmeasured on a comparable basis.',
4:'Consolidated and segment accounts differ; currencies and business mixes remain separate. Losses and lower capital spending indicate pressure but do not identify an industry-wide cause or rank producers.',
5:'The 8.9% cost bridge is illustrative and combines two national benchmarks. Delivered quotes, product specifications and full trade applicability remain missing. Only DC-basis benchmark component values are used.',
6:'Process requests and observed noncoincident peaks are different quantities. March and September snapshots are not additive. The 11-project self-supply mix is power capacity, not energy or a census of data-center procurement.',
7:'The prices are real-time settlement references. Site settlement rights, losses, fees and price finality require project evidence. Pipeline status and persistent price differences are screening information, with causes unassigned.',
8:'One simulated site profile is priced at different nodes; these are not different asset valuations. Output weighting precedes the negative-price response unless labeled otherwise. Regressions describe associations; forecast performance is weak and network causality is unresolved.',
9:'Output is simulated for a reference cell and assumed design. Three weather years do not establish P50/P90 output. Fill flags, leap-day approximation, time mapping and performance uncertainties are detailed in Appendix B.',
10:'Returns are pre-tax and unlevered. Taxes, credit eligibility, financing, land, insurance, network upgrades and several market-service costs remain unverified. Flat nominal contracts lose real value over time. Multiple cash-flow sign changes make a single IRR ambiguous.',
11:'Perturbation ranges are analyst-selected, with some correlated inputs. Decomposition components are accounting contributions; component medians need not add. Tail deletions, resampling and equal-year mixtures are stresses, not event probabilities or price forecasts.',
12:'Controlled conclusions apply only to their stated evidence. Comparative driver rankings, causal demand or congestion claims and storage economics remain untested.',
13:'The screening thresholds are conditional and provide questions for diligence. Actual orders, settlement terms, buyer credit, all-in budgets and contracting rights are still needed before an investment or procurement decision.',
14:'The outlook uses qualitative conditional paths without assigned probabilities. Faster load growth may support prices yet worsen access and delivery risks; the net project effect depends on location, competing supply and contract terms.'}
if a.stage=='P0':
 gov=[]
 for start,end in [('## 2.4 Separation','# 3.'),('## 14.5 Updates','# Appendix A.')]:
  i=base.index(start);j=base.index(end,i);gov.append(base[i:j])
 gov.append(base[base.index('# Appendix B.'):])
 # Preserve workflow/governance text and source-specific qualifications separately, without internal prose in the body.
 appendixB=(D.parent/'2026-10-08_Integrated-Research-Release-Candidate-v0.5/Methods-Data-and-Model-Status-Appendix.md').read_text()
 (D/'support/Original-Governance-and-Technical-Notes.md').write_text('\n\n'.join(gov)+'\n\n'+appendixB)
 (D/'support/Original-Limits-and-Gaps.md').write_text('\n\n'.join(p for p in base.split('\n\n') if p.startswith('>') or re.search(r'does not establish|do not establish|cannot',p,re.I)))
 replace_section('## 1.1','# 2. Analytical Framework', '''## 1.1 Key findings

**At the reference node, the hypothetical solar system fails to recover capital under 2024–2025 price conditions. Lower module prices improve that result, but do not close the gap in the stated cost-transmission example.**

1. In the 2025 reference case, delivered electricity costs about $48.9/MWh while modeled sales earn $26.4/MWh. NPV is -$86.0 million. Even cumulative undiscounted cash flow remains negative in both base revenue routes. [S08]
2. Capital recovery requires about $66/MWh under a flat nominal contract, or capital cost near $577/kWac under the historical nodal-price route, compared with the base $1,437/kWac. These are different revenue mechanisms, evaluated at 4.27% real discounting. [S08]
3. Applying the benchmark-derived 8.9% capital-cost reduction improves reference NPV by $12.8 million, closing about 14.9% of the shortfall. This is a hypothetical cross-benchmark calculation, not observed U.S. delivery-price transmission. [R-A]
4. The 2023 price year produces positive NPV at all 485 sampled nodes; the 2024 and 2025 same-year cases leave only 13 and 2 positive. In 2023, the top 1% of price intervals account for 54.7% of the median node's receipts; deleting those receipts makes 482 nodes negative. [E-A, E-C]
5. Timing materially changes the value of output. The 2025 reference-node average price is $46.37/MWh, versus $22.13/MWh weighted by potential solar production. Negative prices occupy 6.2% of intervals but coincide with 15.2% of potential generation. [S06, S07]
6. Large-load requests are a prospect pool, not contracted solar sales. ERCOT's March process table shows 238.6 GW in the 2030 column against about 5.8 GW observed energized; the latter is a historical noncoincident-peak measure. In a separate 11-project self-supply sample, gas represents about 83% of generation-related power capacity and solar about 11%. [R-C]

## 1.2 Key numbers

**Table 1-1. Economics of the 2025 reference scenario and comparison settings.**

| Measure | Value | Basis / section |
|---|---|---|
| Capital cost | $1,437/kWac; $143.7m | National reference assumptions; 10.2 |
| Delivered-energy LCOE | $48.9/MWh | Real 2025 dollars; 4.27%; 10.6 |
| Realized sales price | $26.4/MWh | Reference node, stop exports below zero; 8.2 |
| Reference NPV | -$86.0m / -$95.3m / -$103.3m | 4.27% / 6% / 8% real; 10.4 |
| Flat nominal break-even contract price | $66.0/MWh | Fixed-price route; 11.3 |
| Nodal break-even capital cost | $577/kWac | About 40% of base cost; 11.3 |
| Receipts needed for zero NPV | $12.1m in year 1 | Constant-real price-profile case; 10.8 |
| Module share of PV-only cost benchmark | 26.1% | National component model; 5.5 |
| Hypothetical CAPEX / NPV improvement | 8.9% / $12.8m | Cross-benchmark example; 5.5 |
| Same-year positive nodes, 2023 / 2024 / 2025 | 485 / 13 / 2 out of 485 | Common calendar, identical financial assumptions; 10.8 |

*Sources: scenario results [S08], component model [R-A], multi-year analysis [E-A]. Model assumptions are summarized in Box 1. Cost, output and revenue figures refer to a hypothetical system.*

## 1.3 How to interpret and use the findings

The 2025 system produces 292.4 GWh of potential AC electricity; stopping exports during negative-price intervals leaves about 247.8 GWh delivered. The gap between an average market price and the price paid for solar output is therefore commercially material. A factory-price reduction affects only part of investment cost, while a contract determines which output is paid and when.

TAYGETE2_ALL is a reference price location, not an established settlement relationship for the simulated site. Its selection rationale is **not disclosed in this edition**. Its absolute production-weighted price is near the 37th percentile in the separate 2025 cross-section, while its ratio to its own average price is near the third percentile. Those percentiles measure different properties. The three-year panel's 2025 median NPV is -$81.3 million, also negative; the historical reference case is not a complete account of the market. [R-B, E-A]

Each historical price shape is repeated for 30 operating years in real terms in the same-year comparison. A positive 2023 result consequently asks what happens if that market pattern persists; it is not an expected return. The strong price-year effect and concentration of receipts make contract structure and exposure to scarce high-price hours central diligence questions.

Manufacturers can use Chapters 4–5 to frame a complete procurement proposition. Developers can use Chapters 8–11 to assess the receipts and cost combination needed for capital recovery. Power sellers targeting large loads should qualify the buyer's required delivery profile, connection progress and ability to pay for reliable supply. The report supports these screening decisions while actual procurement, taxes and financing remain project-specific.
''')
 replace_section('## 2.4 Separation','# 3. Global Solar Demand','''## 2.4 How to read scenario results

> **Box 1. How to read the numbers in this report.** The system is hypothetical: 100 MWac / 132 MWdc in Pecos County. Returns are pre-tax, unlevered and exclude tax credits, financing and unverified project costs. Nodal scenarios repeat a historical price shape for 30 years, with disclosed degradation and selected price trends; fixed-price scenarios hold a nominal price constant and deflate it by 2.5% annually. The 4.27% real discount rate is an analytical benchmark, with 6% and 8% alternatives. Statistical estimates describe conditional associations, not causal effects. Upside/downside bundles, tail stresses and three-year mixtures have no forecast probabilities attached.

The scenario results are conditional on stated assumptions and are not a verified valuation of an actual asset.
''')
 # Governance is preserved, not discarded.
 oldA=t[t.index('# Appendix A.'):t.index('# Appendix B.')]
 t=t[:t.index('# Appendix A.')] + oldA + '''# Appendix B. Methods and Technical Notes

Technical details accompany the cost and market comparisons: current versus historical node classifications, time-zone mapping, shared missing intervals, leap-day approximation, weather fill flags, cost denominator differences, and finance definitions. The full original methods text is preserved in the accompanying technical notes; these qualifications remain part of the interpretation of the results.

''' + appendixB[appendixB.index('# 4.'):appendixB.index('# 6.')].replace('# 4.', '## B.1').replace('# 5.', '## B.2') + '''\n# Appendix C. Research Limits

The remaining research gaps concern comparable industry output/capacity/inventory, delivered project quotes, product-specific trade applicability, customer procurement commitments, historical node identity and price finality, longer-run weather/price distributions, full project costs, taxes, financing and storage. Each limits box identifies the relevant commercial boundary. Gap identifiers GAP-01 through GAP-16 and the original detailed restrictions are preserved in the supporting research-limit record.

# Appendix D. Glossary and Sources Guide

The glossary and expanded source index are completed in the next editorial stage. Source identifiers distinguish official observations from research calculations.

# Appendix E. Project Governance Notes — internal

This customer-readable research edition is an editorial successor to v0.5; it is not the original project Version 1.0. The original ten acceptance criteria remain unchanged. Criterion 6 retains the project-specific resource, nodal-finality/commercial-mapping, cost, tax and financing gaps. The original 67-field register has 59 blocked, 5 not_yet_verified and 3 reference_assumption fields. Its 13 prohibited outputs remain null. Scenario results are kept separate from those interfaces.

The complete earlier governance and technical passages, gap records and update instructions are preserved without deletion in support/Original-Governance-and-Technical-Notes.md and support/Original-Limits-and-Gaps.md. Prior research verification keeps its original date and scope. This revision does not authorize publishing, sale, external sending, account access or changes to actual hours or work logs.
'''
 replace_section('## 8.4 Coverage','## 8.6 Conditional','''## 8.4 A common three-year sample

The main comparison contains 485 officially classified resource nodes with complete prices on the shared published grid in 2023–2025. Market-wide unpublished intervals are excluded uniformly; no price is interpolated or replaced with zero. One simulated output profile is valued against all nodes. The technical appendix documents the calendar and classification rules. [E-S]

## 8.5 Reference-node representativeness

In a separate 2025 cross-section, TAYGETE2_ALL lies near the 37th percentile of absolute production-weighted prices but near the third percentile of the ratio to its own time-weighted price. The low ratio indicates unfavorable timing relative to this node's own price level; it is not a ranking as the third-percentile absolute revenue location. The 2025 distribution below and the three-year panel use different samples. The commercial settlement relationship and reason for choosing this reference node are **not disclosed in this edition**. [R-B]

![Figure 8-4. 2025 production-weighted price distribution](figures/S07_node_prices.png)

*Source: 2025 one-year resource-node cross-section [R-B]. Potential-output weighting precedes the export response. Detailed sample counts and the sample-reconciliation exhibit are in Appendix B.*
''')
 # Move narrow engineering/metadata paragraphs to methods notes rather than retain editing history in customer prose.
 for pattern in [r'The supplemental table.s AC conversion metadata.*?(?=\n\n)',r'PVWatts leap-day treatment.*?(?=\n\n)']:
  match=re.search(pattern,t,re.S)
  if match:
   t=t[:match.start()]+('Only DC-basis benchmark values are used. See Appendix B for denominator qualifications.' if 'AC conversion' in match[0] else 'Calendar handling and leap-day approximation are documented in Appendix B.')+t[match.end():]
 t=re.sub(r'^>.*\[GAP-.*(?:\n(?!\n).*)?', '',t,flags=re.M)
 # Remove file paths and production identifiers only in chapters 1–14, keeping source IDs.
 i=t.index('# 1.');j=t.index('# Appendix A.');body=simpleclean(t[i:j])
 body=re.sub(r'\[[^\]]*source table[^\]]*\]', '',body)
 for old,new in [('Original fact-model evidence gates remain unchanged.',''),('original Version 1.0 acceptance remain unestablished','project-specific valuation remains incomplete'),('Existing regressions and pipelines were not rerun for this edition.',''),("LONGi's FY2024 investment cash flow must not be relabeled capital expenditure.","LONGi's FY2024 investing cash flow is broader than capital expenditure and is not used as that measure here.")]:body=body.replace(old,new)
 # Preserve the qualifications with one chapter-level limits block (three parallel points).
 chapters=re.split(r'(?=^# \d+\.)',body,flags=re.M);clean=[]
 for part in chapters:
  mat=re.match(r'# (\d+)\.',part)
  if mat:
   num=int(mat[1]);parts=limits[num].split('. ');a1='. '.join(parts[:1]);a2='. '.join(parts[1:2]);a3='. '.join(parts[2:])
   part=part.rstrip()+f'\n\n> **Limits of this chapter.** (1) {a1}. (2) {a2}. (3) {a3}\n\n'
  clean.append(part)
 body=''.join(clean)
 t=t[:i]+body+t[j:]
 # Customer front matter, with period scope; governance remains in Appendix E.
 t=t[:t.index('**Draft status.')]+'''**Draft status.** Research edition, October 2026. This report is for market screening and commercial diligence, not investment advice or a verified asset valuation. Manufacturing evidence covers 2024 and selected FY2025 disclosures; weather and nodal prices cover 2023–2025; regional load evidence uses March and September 2026 snapshots; national demand scenarios extend to 2030.

**Intended readership.** Solar manufacturers and exporters, utility-scale developers, electricity buyers, and research teams.

'''+t[t.index('# 1.'):]
 t=t.replace('Integrated Research Release Candidate v0.5 | October 8, 2026','Research edition | October 2026')
 # Settings directly from the frozen scenario metrics and register.
 settings=[]
 for sid,b in metrics.iterrows():
  fixed=b.route=='fixed';settings.append([sid,('$'+str(int(b.input_fixed_price))+'/MWh nominal flat') if fixed else ('2025 reference profile; '+f'{b.input_node_esc*100:+.1f}%/yr real'), f'{b.input_curtail_fixed*100:.2f}%' if fixed else 'Stop exports below $0',f'{b.capex_usd_per_kwac:,.1f}',f'{b.fom_usd_per_kwac_yr:.2f}', '18%' if 'downside' in sid else '10%' if 'upside' in sid else '14.0757%',f'{b.input_degradation*100:.1f}%', '2.5%'])
 before('## 10.4 Scenario results','''**Table 10-0. Scenario settings — price, cost and operating assumptions.**

'''+table(['Scenario','Price rule / level','Unpaid energy / response','CAPEX $/kWac','FOM $/kWac-year','Initial losses','Degradation /yr','Inflation /yr'],settings)+'''

*Sources: scenario input register and scenario outputs [S08, S09]. CAPEX and FOM are in real 2025 dollars. The low/base/high costs follow the ATB Conservative/Moderate/Advanced technology cases, respectively in downside/base/upside use; the labels describe bundled assumptions, not probabilities. Replacement is $35/kWac in operating year 16 and net decommissioning $30/kWac in year 30 across all cases. Nodal delivery responds to each interval price; its negative-price output share is endogenous. Fixed-route shares are imposed assumptions.*

The 2.5% inflation input follows the ATB workbook's financial-assumption row 52. For fixed_base, 247.8195 GWh × $40/MWh gives $9.9128 million nominal receipts in 2027; dividing by 1.025 squared gives $9.4351 million in 2025 dollars. The two-year deflation follows the model's stated calendar convention.
''')
 before('## 5.6 Policy changes','''## 5.5a From the component-cost example to project NPV

Applying the rounded 8.9% percentage to the ATB-based scenario CAPEX reduces the end-2026 cash outlay by approximately $12.79 million. Evaluating the existing annual cash-flow equation with that single changed payment improves node_base NPV from -$85.97 million to -$73.18 million, closing 14.87% of its gap; fixed_base improves from -$73.74 million to -$60.95 million, closing 17.34%. Other costs and receipts are held constant. This calculation is exact for the rounded 8.9% input and the model's cash-flow timing; the transmission percentage itself is illustrative. [R-A, S08]

This applies the PVSCM-derived percentage to the ATB-based scenario cost; it is not observed U.S. price pass-through. It shows that this component-price example alone leaves a substantial capital-recovery gap under the reference 2025 conditions. It supplies no general ranking of other return drivers.
''')
 # Route assumptions make the reader's first reference explicit.
 t=t.replace('The 2025 TAYGETE2_ALL series contains', 'TAYGETE2_ALL is a historical price reference. Its selection rationale, location-to-site mapping and settlement relationship are not disclosed in this edition. The 2025 TAYGETE2_ALL series contains',1)
 # Internal reference IDs are renamed only in customer chapters, with mapping preserved later.
elif a.stage=='P1':
 replace_section('## 10.6 LCOE and IRR','## 10.7 Benchmark scope','''## 10.6 LCOE, contract duration and IRR

Base LCOE is $48.85/MWh using delivered energy and 4.27% real discounting. Using potential generation instead gives $41.41/MWh because the denominator includes energy not sold. Both measures use the same real cost stream; a flat nominal contract needs a separate inflation adjustment. [S08]

In fixed_upside, first-year realized price is $45.69/MWh and real LCOE is $43.69/MWh, yet NPV is -$33.45 million. The contract price stays flat in nominal terms, so its real value falls with 2.5% annual inflation. A first-year price above a constant-real levelized cost therefore does not ensure lifetime capital recovery.

All six scenarios have negative NPV at the modeled positive discount rates. A single IRR is not a reliable comparison for cases with multiple roots: node_base has two negative numerical roots, approximately -96.52% and -2.53%; fixed_upside has roots near -86.48% and +1.41%. Neither case is summarized by selecting one preferred root. The node_upside case has a certified unique numerical IRR of about -0.42%; the fixed_downside case has no certified unique rate. NPV and cash flows provide the decision measure. Technical root qualifications are in Appendix B. [S10]
''')
 t=t.replace('null: multiple roots','Not a single rate: multiple roots').replace('null: uniqueness not certified','Single rate not certified')
 # Drop false investor-return wording from proposed task text; estimates stay unchanged.
 before('## 10.2 Cost coverage','''The 4.27% analytical real rate is obtained from ATB reference nominal debt cost 6.5%, equity return 8.0% and debt fraction 0.7457, without a tax shield: [(0.065 × 0.7457 + 0.080 × 0.2543) + 1] / 1.025 - 1 ≈ 4.27%. The input register identifies workbook rows 52–68. It is a scenario discount convention, not a verified project WACC or investor hurdle. The 6% and 8% comparisons remain visible. [S09]
''')
 before('## 10.8 Historical','''## 10.7a Illustrative credit sensitivity

A simplified cash-credit example assumes a receipt equal to 30% of total scenario CAPEX at the end of the first operating year. At 4.27%, its present value is $41.34 million. Holding the pre-tax operating cash flows constant, node_base NPV becomes -$44.63 million and fixed_base NPV -$32.40 million; the flat nominal fixed-route break-even price falls from $65.97/MWh to about $51.41/MWh. [S08]

This is **illustrative only; no eligibility determination**. It is a cash-receipt sensitivity, not an ITC/PTC tax model: total scenario CAPEX is assumed to be the qualifying base solely for this example. Payment timing, eligible basis, tax capacity, transfer discounts, recapture, basis adjustments, depreciation and tax-equity costs are excluded. The 30% assumption is not a statement of the statutory rate available to this system. No credit benefit is added to the six original scenarios.
''')
 before('## 8.3 Monthly outcomes',f'''For comparison, exporting through negative prices gives modeled first-year receipts of $6.471 million and NPV of -$87.20 million in the existing rule-off sensitivity, versus $6.551 million and -$85.97 million when negative-price exports stop. This small difference is specific to the zero-incentive, pre-tax merchant case; contracts or production-linked benefits can change the preferred behavior. Receipts are obtained from the frozen generation-weighted price and output, and NPV from the existing sensitivity row. [S08]
''')
 t=t.replace('The fixed-price route assumes', 'The fixed-price route has no observed contract. Its 15.24% unpaid-energy deduction is an analytical allocation of payment risk, not a documented clause. A negative-price exclusion clause could create unpaid output, but no such agreement is assumed to have been obtained. The fixed-price route assumes',1)
 # Explicit scope of policy comparison, no invented current-law certification.
 before('## 5.7 Import value','''The cost benchmark's module line is about $0.29/Wdc, whereas the cited proclamation records a $0.38/W import-price floor for covered entries from December 4, 2026. These belong to different cost boundaries and dates: the benchmark uses a U.S.-assembled module input including its stated subsidy treatment, while the rule applies to covered imported products. A verified common nameplate-Wdc denominator and product/origin/exception match are **not disclosed in this edition**. The nominal comparison signals a possible limit to factory-price transmission, rather than a quantified duty-inclusive procurement saving. [R-A, P01]
''')
 t=t.replace('The evidence is consistent with a commercial distinction between low-cost daytime energy and a broader power-service requirement.', 'The sample points to a supply-service distinction: gas is about 83% and solar about 11% of the reported power-capacity mix. A solar offer for a buyer requiring continuous supply may need firming, storage or coordination with dispatchable generation. The sample does not establish all data centers\' preferred procurement structure.')
 # Five hypotheses have identical statement strings in introduction, sections and conclusion table.
 hypotheses=[('Equipment price','Lower module prices improve project economics, but their effect may be smaller than financing, interconnection delay, curtailment or realized power prices.'),('Demand and value','Data-center load growth does not automatically raise an individual solar project\'s realized price or bankability.'),('Value chain','Manufacturing scale and lower upstream prices can coexist with weak value capture along the solar value chain.'),('Grid constraints','Grid constraints can affect the deliverable value of solar output.'),('Storage','Storage can improve solar economics by changing delivery timing, subject to its incremental costs and operating limits.')]
 before('# 3. Global Solar Demand','''## 2.5 Five working hypotheses

'''+ '\n\n'.join(f'**H{i} — {name}.** {statement}' for i,(name,statement) in enumerate(hypotheses,1)))
 # Replace section openers and table first column with the same controlled propositions, not opposite-direction shorthand.
 for i,(name,statement) in enumerate(hypotheses,1):
  marker=f'## 12.{i} ';start=t.index(marker);e=t.index('\n\n',start);t=t[:e]+f'\n\n**Working hypothesis:** {statement}'+t[e:]
  nxt=t.index(f'## 12.{i+1}',e) if i<5 else t.index('## 12.6',e)
  meaning=['Use component-specific delivered quotes before ranking cost savings against other risks.','Qualify the buyer, settlement location and payment shape; a load request alone is not a price uplift.','Assess company-specific cash generation and product economics alongside manufacturing volumes.','Investigate actual constraints and settlement exposure before attributing a node price difference to congestion.','Treat storage as a separate incremental investment case; a timing mismatch alone supplies no storage return.'][i-1]
  t=t[:nxt]+f'**What this means for you.** {meaning}\n\n'+t[nxt:]
 oldnames=['Lower equipment prices improve project economics','Data-center growth improves solar value','Manufacturing scale ensures value capture','Grid constraints determine project returns','Storage improves project economics']
 for old,(_,statement) in zip(oldnames,hypotheses):t=t.replace('| '+old+' |','| '+statement+' |')
 # Keep LMDI in main narrative, move Shapley and original mixed-panel chart to technical notes.
 s=t.index('## 11.7 Two distinct');e=t.index('## 11.8 Tail',s)
 original=t[s:e];(D/'support/Original-Decomposition-Section.md').write_text(original)
 lmdistart=original.index('A separate log-mean');lmdiend=original.index('![Figure 11-4.')
 new='''## 11.7 Price levels and output-price matching explain most of the change

The large post-2023 deterioration is predominantly associated with the price year, with a much smaller weather contribution. The separate price-and-volume accounting below shows substantial contributions from both lower overall prices and weaker output-price matching. These are two distinct accounting methods; the price/volume table is not a nested breakdown of the weather/price method. [E-A]

'''+original[lmdistart:lmdiend]+'''\n![Figure 11-4. Components of the year-to-year change](figures/Client_LMDI_decomposition.png)

*Source: existing component table [E-A]. LMDI separates volume, overall price, timing match and the export rule. Values are medians across nodes and need not add to the median total. The weather/price Shapley allocation and original exhibit are in Appendix B.*

Between 2024 and 2025, the overall-price component improves while output-price matching deteriorates. Capacity growth, load changes and congestion remain possible explanations, not identified causes.

'''
 t=t[:s]+new+t[e:]
 # Plain-language stress definition from original script's price-ranked cumulative receipts.
 t=t.replace('The candidate\'s best-hours stress statistic', 'The best-hours stress statistic').replace('The research edition\'s best-hours stress statistic', 'The best-hours stress statistic')
 before('## 11.9 Resampling','''The roughly 23-hour figure is an equivalent duration of the highest-revenue 15-minute intervals, sorted from highest modeled receipts downward. In the median positive 2023 node case, removing the modeled receipts from approximately that many accumulated intervals exhausts the NPV surplus. These intervals need not be consecutive, and the statistic is not a schedule of hours known in advance. [E-C]
''')
 # Observed price pattern from packaged hourly input only, no event attribution.
 h=pd.read_csv(D/'data/empirical/plot_inputs/F6_hourly_HB_BUSAVG_and_system_solar.csv');pcol='HB_BUSAVG_hourly_mean_usd_mwh';hr=h[h.year==2023].copy()
 (D/'support/2023-Price-Context-Columns.json').write_text(json.dumps(list(h.columns)))
 # Complete precise context in numeric provenance script, avoid guessed timestamps.
 before('## 11.8 Tail','''The 2023 context in these results is a high-price-tail environment, not simply a higher uniform electricity price: the top 1% of price intervals account for 54.7% of median node receipts, compared with 13.6% in 2024 and 4.9% in 2025. Calendar-month and time-of-day detail is tabulated in the accompanying 2023 price-context table. An externally sourced event attribution is **not disclosed in this edition**; no particular outage, heat event or binding constraint is assigned as the cause. [E-C]
''')
 # Reading navigation.
 before('# 1. Executive','''**Reading navigation.**

'''+table(['If you are…','Read first'],[['A manufacturer or exporter','1, 4, 5, 13.1'],['A developer or investor','1, 8, 10, 11.3, 13.2'],['Selling electricity to large loads','1, 6, 8.1–8.2, 13.4'],['A research or consulting team','2, 8.6–8.8, 11.6–11.9, Appendix B']]))
 # Specific commercial conclusions, without unsupported ranking.
 before('## 13.2 Developers','''For the component-price example, an 8.9% capital saving closes about 14.9% of the reference gap. A supplier should therefore show the delivered project saving, warranty and system consequences alongside the module quote. Covered import rules may limit transmission; the $0.38/W versus $0.29/Wdc comparison remains conditional on compatible product and denominator definitions. [R-A, P01]
''')
 before('## 13.3 Research','''Under the reference assumptions, the fixed route needs about $66/MWh flat nominal, while the nodal route requires CAPEX near $577/kWac or a price-profile multiplier near 1.85. These are alternative break-even tests. The -$81.3m 2025 median-node NPV indicates that switching to the median price reference alone leaves a sizeable modeled gap. [S08, E-A]
''')
 before('## 14.3 Indicators','''For solar receipts, the first path is ambiguous: scarcity can support market prices while connection delays and delivery restrictions impair realization. Coordinated load and network expansion can improve market access, but competing supply may absorb the demand increase. Slower load realization weakens the demand-side thesis, holding supply and other conditions constant. None of these paths has a quantified net price effect here.
''')
 # Restore full appendix assembly below in finalize support step.
elif a.stage=='P2':
 # Reorganize demand material in place, retaining facts and captions.
 i=t.index('## 3.3 Regional');j=t.index('## 3.4 Implications',i);t=t[:i]+t[j:]
 t=t.replace('## 3.4 Implications','## 3.3 Implications').replace('## 3.5 Country','## 3.4 Country').replace('## 3.6 The manufacturing','## 3.5 The manufacturing')
 t=t.replace("China's reported 2024 module manufacturing output", "For the 2024 comparison (distinct from the 2025 additions above), China's reported module manufacturing output")
 t=t.replace('The MIIT decline of 29.7% is therefore not applied to total CAPEX.', 'The MIIT decline of 29.7% is therefore not applied directly to total CAPEX. Section 5.5 shows an illustrative calculation using a benchmark component share.')
 t=t.replace('It is not a market valuation multiple.', 'The $187.3m intercept comprises initial CAPEX plus the present value of fixed operating costs, replacement and decommissioning. It is a cash-flow identity, not a market valuation multiple.')
 t=t.replace('equivalent to an AC capacity factor of 33.38%.', 'equivalent to an AC capacity factor of 33.38% under the assumed DC/AC ratio of 1.32, single-axis tracking and bifacial design. These design choices contribute to output per unit of inverter capacity; this is not an observed fleet benchmark.')
 t=t.replace('**Table 10-1.**','**Table 10-1. Six scenarios priced at reference node TAYGETE2_ALL or the fixed contract setting.**').replace('**Table 10-2.**','**Table 10-2. Same-year comparison: median across 485 resource nodes.**')
 titles={'2-1':'Definitions used in the report','4-1':'Manufacturing-stage observations, 2024','4-2':'Selected consolidated gross margins','9-1':'Hypothetical system design','11-1':'Break-even conditions under base assumptions','11-2':'Weather and price contributions to NPV change','11-3':'Volume, price and timing contributions to NPV change','12-1':'Controlled conclusions and revision evidence','13-1':'Commercial decisions and evidence requirements','14-1':'Indicators that would change the assessment','A-1':'Core sources and evidence locations'}
 for k,v in titles.items():t=t.replace(f'**Table {k}.**',f'**Table {k}. {v}.**')
 t=t.replace('The thresholds translate', 'The nodal break-even capital cost of $577/kWac is about 40% of the base $1,437/kWac, a reduction of roughly 60%. The thresholds translate',1)
 t=t.replace('\u200b','').replace('\u00ad','')
# Scope check: no prohibited internal terms in chapters, including source keys/paths.
i=t.index('# 1.');j=t.index('# Appendix A.');body=t[i:j]
for old,new in [('retained','used'),('candidate','study'),('R2-A','R-T'),('R2-D','R-F'),('R2','extended analysis'),('first-round','one-year'),('second-round','extended'),('fact-based model','original project model'),('fact-model','original project model'),('prohibited','unreleased'),('acceptance','project completion'),('Criterion','condition'),('editorial integration','report preparation')]:body=body.replace(old,new).replace(old.capitalize(),new.capitalize())
body=re.sub(r'[A-Za-z0-9_./-]+\.(csv|json)\b','source table',body)
# Repeated negative formulations are converted to precise scope descriptions, not removed.
body=body.replace('does not establish','leaves unverified').replace('do not establish','leave unverified').replace('cannot','is insufficient to')
t=t[:i]+body+t[j:]
(D/'stages'/f'{a.stage}.md').write_text(t)
(D/'Integrated-Market-Research-Report-EN_Client-Readable.md').write_text(t)
print('Saved',a.stage,len(t.split()),'words')
