"""Integrate frozen closure text only; no estimation or model execution."""
from pathlib import Path
import re,json,hashlib
D=Path(__file__).resolve().parents[1]
source=D/'internal/Finance-Integrated-Input.md'
original=source.read_text()
text=original
fx=(D/'closure-evidence/Findings-and-Replacement-Text-EN.md').read_text()
sections={m[1]:m[2] for m in re.finditer(r'^## (FIN-\d+|B-\d+) .*?\n(.*?)(?=^## |\Z)',fx,re.M|re.S)}
changes=[]
def blocks(id):
    return ['\n'.join(line[2:] if line.startswith('> ') else '' for line in b.splitlines()) for b in re.findall(r'(?:^>.*(?:\n|$))+',sections[id],re.M)]
def change(old,new,id):
    global text
    assert text.count(old)==1,(id,'anchor count',text.count(old),old[:80])
    text=text.replace(old,new)
    changes.append({'id':id,'action':'replace','old':old,'new':new})
def paragraph(anchor,new,id):
    candidates=[p for p in text.split('\n\n') if anchor in p]
    assert len(candidates)==1,(id,anchor,len(candidates))
    change(candidates[0],new,id)
def cited(s,id):return s+f' [CL-{id}]'

paragraph('Performance research partly addressed',cited(blocks('FIN-02')[0],'FIN-02'),'FIN-02')
contract='\n\n'.join(blocks('FIN-03'))
contract=contract.replace('No comparable project in the public record discloses a strike, tenor, settlement hub, volume rule, negative-price clause, REC allocation or credit support.',
 'The reviewed records do not disclose an energy-contract strike, tenor, settlement hub, volume rule, negative-price clause or credit support. The separately disclosed environmental-attribute agreement is described below.')
contract=contract.replace('This is the only publicly reported tenor for the Taygete projects.', 'Within the reviewed evidence, this is the disclosed tenor of the environmental-attribute agreement, rather than the energy hedge.')
contract=contract.replace('Fees, RECs and imbalance are set to zero only because they are not disclosed; they are not assumed costless.', 'Fees, REC cash flows and imbalance charges are omitted from this calculation; their economic values are unknown, rather than established as zero.')
paragraph('Contract research partly addressed',cited(contract,'FIN-03'),'FIN-03')
paragraph('A lender release identifies a long-term J. Aron hedge',
 'A lender release identifies a long-term J. Aron hedge for part of Taygete I output and another rated purchaser. A developer release also identifies a separate environmental-attribute agreement, discussed below. No complete executed energy contract is available: its price, tenor, settlement point and negative-price clauses remain undisclosed. No indicative offer is treated as a comparable transaction. [F05; CL-FIN-03]','FIN-03-context')
tax=blocks('FIN-04')
paragraph('A retained District Court opinion dated',cited(tax[0],'FIN-04'),'FIN-04-status')
taxq=tax[1].replace('and the exclusion of interconnection property above 5 MWac', 'and the limitation of the special qualified-interconnection-property provision to facilities no larger than 5 MWac')
taxq=taxq.replace('and the 6% base rate $7.08m', 'and a 6% statutory credit-rate assumption (PWA conditions not met), $7.08m')
paragraph('Tax research partly addressed',cited(taxq,'FIN-04'),'FIN-04-basis')
paragraph('Procurement research pending',cited(blocks('FIN-05')[0],'FIN-05'),'FIN-05-procurement')
costtable=re.search(r'(\| Item \| In ATB OCC.*?)(?=\n\*\*Sources:)',sections['FIN-05'],re.S)[1].strip()
paragraph('Cost research partly addressed',cited(blocks('FIN-05')[1],'FIN-05')+'\n\n**Table 10-6. Cost-scope crosswalk; benchmark coverage and unresolved site costs.**\n\n'+costtable,'FIN-05-cost')
paragraph('Location research partly addressed',cited(blocks('FIN-06')[0],'FIN-06'),'FIN-06')
cpi=blocks('FIN-07')[0].replace('[Insert FIN-01 "Comparable returns" paragraph.]',blocks('FIN-01')[0])
cpi=cpi.replace('without changing any sign', 'without changing the signs of the reported comparisons')
cpi+='\n\nThe CPI file\'s 2024 median uses the full-year calendar; Tables 10-4 and 10-5 use the common-calendar sample. Those medians are not interchangeable. The reference-node 2024 comparison above is on the common-calendar basis.'
paragraph('Comparable-return and currency research partly addressed',cited(cpi,'FIN-07'),'FIN-07')
paragraph('**Currency qualification.',next(p for p in text.split('\n\n') if '**Currency qualification.' in p)+' A CPI-restated version is reported below.','FIN-07-currency')
regime=blocks('FIN-08')[0].replace('No 2026 generation series exists for the hypothetical site, so no 2026 capture price, revenue or NPV is reported.', 'No 2026 generation series exists for the hypothetical site, so no same-year 2026 capture price, project revenue or NPV is reported.')
regime=regime.replace('These figures describe the first months after real-time co-optimisation began', 'The weighted-price figure is a fixed-2025-output-profile price diagnostic, not a realised 2026 capture price. These figures describe the first months after real-time co-optimisation began')
regime=regime.replace('Data through 7 October had passed that time at retrieval,', 'Using a Monday–Friday business-day count without independently applying the ERCOT holiday calendar, data through 7 October were inferred to have passed that time at retrieval,')
paragraph('Market-regime research pending',cited(regime,'FIN-08'),'FIN-08')
liquidity=blocks('FIN-09')[0]
liquidity=liquidity.replace('Table 4-3 sets out','Tables 4-3A and 4-3B set out').replace('货币资金 ("cash and bank balances")','"cash and bank balances"')
rawtable=re.search(r'(\| Company \| CCY \| Cash & bank.*?)(?=\n\*Sources:)',sections['FIN-09'],re.S)[1].strip().splitlines()
rows=[[x.strip() for x in r.strip('|').split('|')] for r in rawtable]
def select(cols):return '\n'.join('| '+' | '.join(row[i] for i in cols)+' |' for row in rows)
tablea=select([0,1,2,3,7,8])
tableb=select([0,1,4,5,6])
foot=re.search(r'(\*Sources: FY2025 annual reports.*?)(?=\n\*\*Remaining fields:)',sections['FIN-09'],re.S)[1].strip()
foot=foot.replace('`tables/FIN-09_Supplier-Liquidity.csv`','[supplier-liquidity table](closure-evidence/tables/FIN-09_Supplier-Liquidity.csv)')
paragraph('Supplier-finance research pending',cited(liquidity,'FIN-09')+'\n\n**Table 4-3A. FY2025 year-end liquidity, warranties and working capital; billions of reporting currency.**\n\n'+tablea+'\n\n**Table 4-3B. FY2025 year-end borrowing observations; billions of reporting currency.**\n\n'+tableb+'\n\n'+foot,'FIN-09')
longi=blocks('B-01')[0]
paragraph("The expanded sample supports a more differentiated view of manufacturing economics.",
 'The expanded sample distinguishes consolidated loss, segment gross margin, cash generation and capital spending. '+cited(longi,'B-01'),'B-01-text')
row='| LONGi | Wafers/ingots | 2024 | −14.31% | n/a | n/a | n/a | CNY | Segment only |'
newrows=re.search(r'(\| LONGi \| Modules/cells \| 2025.*?)(?=\n\n)',sections['B-01'],re.S)[1]
change(row,row+'\n'+newrows,'B-01-table')
text=text.replace("LONGi's rows show segment margins only.","LONGi's rows distinguish segment margins from repeated group cash-flow and profit figures; the group amounts are not additive across segment rows.")
trade=blocks('B-02')
paragraph('Proclamation 11052, published August 11, 2026',cited(trade[0],'B-02'),'B-02')
paragraph('The accompanying trade evidence identifies',
 'The accompanying trade evidence identifies applicable diligence questions; it is not an all-in tariff calculator. IEEPA treatment and the complete interaction of duties remain outside the quantified cost bridge. No tariff benefit or incentive eligibility is assigned to the hypothetical project.\n\n'+cited(trade[1].replace('and none had been published in the Federal Register by 10 October 2026.', 'and none was located in the Federal Register search performed on 10 October 2026.'),'B-02'),'B-02-status')
paragraph('September 2026 Batch Zero materials classify',cited(blocks('B-03')[0],'B-03'),'B-03')
paragraph('Variables include irradiance, temperature',cited(blocks('B-04')[0],'B-04'),'B-04-flags')
change('(3) Weather-quality flags and performance uncertainties remain open; leap-day approximation and time mapping are described in Appendix B.',blocks('B-04')[2],'B-04-limits')
anchor='The hypothetical system is 100 MWac / 132 MWdc in one Pecos County NSRDB location'
paragraph(anchor,next(p for p in text.split('\n\n') if anchor in p)+'\n\n'+cited(blocks('B-04')[1],'B-04'),'B-04-method')
start=text.index('# Appendix C. Research Agenda and Unresolved Evidence')
end=text.index('# Appendix D.',start)
appendix=blocks('B-05')[0].replace('Table 4-3)', 'Tables 4-3A and 4-3B)')
appendix=appendix.replace('Strike, tenor, hub, volume rule, negative-price clause, RECs, credit support','Energy-contract strike, tenor, hub, volume rule, negative-price clause and credit support; full REC agreement terms')
appendix=appendix.replace('Structures only; hub-hedge version is hypothetical','Selected structures and environmental-attribute tenor disclosed; hub-hedge version hypothetical')
appendix=appendix.replace('no 2026 return', 'no same-year 2026 return')
financing='\n\n'.join(blocks('FIN-10'))
receipts=blocks('FIN-11')[0].replace('None of these is disclosed for the comparable plants, and none is assumed to be zero-cost.', 'Complete amounts and allocation terms are unavailable for the comparable plants. Selected environmental-attribute rights are disclosed, but their cash proceeds are not; omitted items are not established as zero-cost.')
appendix+='\n\n'+cited(financing,'FIN-10')+'\n\n'+cited(receipts,'FIN-11')+'\n\n'
change(text[start:end],appendix,'B-05-FIN-10-FIN-11')
# Place the existing source-ID catalog inside the report's reference apparatus.
ref='''\n## A.5 Closure-supplement evidence (CL references)\n\nCL references identify the corresponding FIN-01–FIN-11 or B-01–B-05 section in the [closure findings](closure-evidence/Findings-and-Replacement-Text-EN.md). The [closure source catalog](closure-evidence/Sources.csv) supplies original URLs, retained file paths, page locators and hashes; the [claim register](closure-evidence/Numbers-and-Claims.csv) records numerical and legal scope. Search leads are not used as evidence. Selected new inputs include FY2025 SEC and A-share annual filings, the full Federal Register proclamation and annexes, the public RECAP docket, the ERCOT Batch Zero deck and the 2025 IMM report. The Business Wire source is an owner-supplied screenshot of a developer release, not an independently downloaded executed contract. Source checks were completed on 10 October 2026 UTC (9 October US Eastern).\n\nThe separately versioned CPI, credit and VPPA calculations are retained in [scenario notes](scenario-versions/Scenario-Notes-EN.md) and their accompanying CSV files. They do not revise the original six baseline scenarios.\n\n'''
change('# Appendix B.',ref+'# Appendix B.','references')
text=text.replace('Finance-integrated research edition | 9 October 2026','Closure-integrated candidate edition | 9 October 2026')
text=text.replace('**Edition scope.** Research edition, October 2026.', '**Edition scope.** Candidate research edition, October 2026.')
text=text.replace('weather and nodal prices cover 2023–2025;', 'weather and nodal-price scenarios cover 2023–2025, with a separately qualified 2026 year-to-date price update;')
assert '[Insert FIN-01' not in text
for phrase in ['research pending — FIN','research partly addressed — FIN','That version is not implemented here',"LONGi's full FY2025 annual report remains unavailable"]:assert phrase not in text,phrase
# Final presentation edits retain all substantive qualifications.
text=text.replace('## A.5 Closure-supplement evidence', '## A.2 Closure-supplement evidence')
text=text.replace('with FY2024 LONGi reported separately.', 'with LONGi added separately in Table 4-2; Figure 4-3 retains the original four-company comparison.')
text=text.replace('**Comparable returns and currency basis.** **Comparable returns.**', '**Comparable returns and currency basis.**')
limit=next(p for p in text.split('\n\n') if p.startswith('> **Limits of this chapter.** (1) Consolidated'))
text=text.replace(limit+'\n\n','')
heading='# 5. Cost Transmission:'
text=text.replace(heading,limit+'\n\n'+heading)
text=text.replace('system ($10.88), property ($11.41) and administration ($2.38) expenses.', 'system ($10.88), property ($11.41) and administration ($2.38) expenses. The rounded components sum to $24.67; the published total is $24.66.')
text=text.replace(chr(92)+'"','"')
changes.append({'id':'editorial-consistency','action':'clarify','new':'Move Chapter 4 limits after liquidity; align four-company chart scope; disclose FOM rounding; correct appendix sequence; remove duplicate label.'})
out=D/'Integrated-Market-Research-Report-EN_Closure-Integrated.md'
out.write_text(text)
(D/'support/Closure-Integration-Actions.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
print('Integrated',len(changes),'anchored actions;',out)
