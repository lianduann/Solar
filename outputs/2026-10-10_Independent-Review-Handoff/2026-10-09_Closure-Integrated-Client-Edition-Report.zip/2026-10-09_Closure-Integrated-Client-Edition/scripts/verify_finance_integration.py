"""Verify incremental arithmetic, figure values, references and frozen input preservation."""
from pathlib import Path
import json,re,hashlib
import pandas as pd
import numpy as np
D=Path(__file__).resolve().parents[1];checks=[]
def check(name,ok,detail=None):
 checks.append(dict(check=name,passed=bool(ok),detail=detail))
m=pd.read_csv(D/'data/scenario_metrics.csv').set_index('scenario_id');cf=pd.read_csv(D/'data/scenario_annual_cash_flows.csv');z=json.loads((D/'data/finance/Finance-Integration-Calculations.json').read_text());p=json.loads((D/'data/panel/Panel-Calculations.json').read_text());r=.0427
check('OCC plus GCC equals CAPEX',abs(z['occ']+z['gcc']-z['capex'])<.01)
# Recompute credit directly from basis, inflation and payment dates, not prior result.
c=.30*z['occ']*1.025/(1.025**2)/(1+r)
check('OCC credit timing arithmetic',abs(c-z['occ_credit_pv'])<.001)
for case,key in [('node_base','node_with_occ_credit'),('fixed_base','fixed_with_occ_credit')]:
 g=cf[cf.scenario_id==case];npv=float((g.net_cash_flow_real/(1+r)**g.t).sum())
 check(case+' baseline independent cash-flow sum',abs(npv-m.loc[case,'npv_real_selected'])<.01)
 check(case+' credit variant',abs(npv+c-z[key])<.01)
 gain=-float(g.loc[g.t==16,'major_replacement_real'].iloc[0])/(1+r)**16
 check(case+' reserve-removal value',abs(gain-z['reserve_removal_pv'])<.01)
fc=cf[cf.scenario_id=='fixed_base'];cost=float(((fc.revenue_real-fc.net_cash_flow_real)/(1+r)**fc.t).sum());slope=float((fc.revenue_real/40/(1+r)**fc.t).sum())
check('OCC-credit break-even',abs((cost-c)/slope-z['break_even_with_occ_credit'])<.00001)
u=pd.read_csv(D/'data/finance/Unpaid-Energy-Stress.csv')
for i,q in u.iterrows():check('unpaid stress '+str(i),abs(q.flat_nominal_breakeven_usd_mwh*(1-q.unpaid_share)-p['no_unpaid_breakeven'])<1e-8)
a=pd.read_csv(D/'finance-supplement/data/EIA-Operating-Generation-Comparables.csv');b=a[(a.county=='Pecos')&(a['flags']=='clean full-year standalone PV')]
co=pd.read_csv(D/'data/finance/EIA-Cohort-Reconciliation.csv')
for i,q in co.iterrows():
 g=b[b.year==q.year]
 if q.cohort!='All tracking types':g=g[g.tracking=='Y']
 if 'excluded' in q.cohort:g=g[g.plant_id!=63233]
 check('cohort '+str(i),len(g)==q.n and abs(g.annual_capacity_factor_ac.median()-q['median'])<1e-12)
snap=json.loads((D/'support/Finance-Chart-Snapshots.json').read_text());g=pd.read_csv(D/'data/finance/EIA-2025-Tracking-Chart.csv');h=pd.read_csv(D/'data/finance/Qualified-Investment-Comparisons.csv').sort_values('result')
check('capacity-factor bars',np.allclose([v[2] for v in snap['Finance_Operating_CF'][0]['rects']],g.annual_capacity_factor_ac*100,atol=1e-5))
check('cost-comparison bars',np.allclose([v[2] for v in snap['Finance_Qualified_Investment'][0]['rects']],h.result/1000,atol=1e-5))
text=(D/'Integrated-Market-Research-Report-EN_Finance-Integrated.md').read_text()
for value in ['35.38','50.59','38.36','53.51','1.79','84.17','71.95','23.8%','25.0%','80.43','55.91','65.97']:
 check('display '+value,value in text)
for label in ['Figure','Table']:
 ids=re.findall(r'(?:!\[|\*\*)'+label+r' (\d+-\d+)',text);check(label+' labels unique',len(ids)==len(set(ids)),ids)
missing=[]
for url in re.findall(r'\]\(([^)]+)\)',text):
 if url.startswith(('http:','https:','#')):continue
 if not (D/url.split('#')[0]).exists():missing.append(url)
check('main manuscript local links',not missing,missing)
# Figure/table IDs and internal source keys have explicit definitions.
for k in range(1,10):check('finance bibliography F'+str(k),f'**[F{k:02d}]**' in text)
# The blocked interface is inherited byte-for-byte; no factual model outputs are assigned.
gate=json.loads((D/'data/blocked_interface.json').read_text())
check('blocked factual outputs remain null',all(v is None for v in gate['output_values'].values()))
original=json.loads((D/'support/Baseline-Data-Hashes.json').read_text())
check('frozen research inputs unchanged',all(hashlib.sha256((D/path).read_bytes()).hexdigest()==h for path,h in original.items()),len(original))
for kind,pat in [('table',r'^\*\*Table (\d+)-(\d+)\.'),('figure',r'^!\[Figure (\d+)-(\d+)\.')]:
 ids=re.findall(pat,text,re.M)
 check(kind+' numbering sequential',all([int(n) for c,n in ids if c==ch]==list(range(1,sum(c==ch for c,n in ids)+1)) for ch in set(c for c,n in ids)))
result=dict(scope='Incremental finance integration; no regression, generation simulation or upstream raw-source extraction rerun.',checks=checks,passed=sum(c['passed'] for c in checks),failed=sum(not c['passed'] for c in checks))
(D/'support/Finance-Verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(result['failed']>0)
