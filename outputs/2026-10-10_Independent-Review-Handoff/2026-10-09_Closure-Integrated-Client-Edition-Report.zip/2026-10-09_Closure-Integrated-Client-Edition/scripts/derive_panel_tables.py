"""Derive presentation tables and explicit financial sensitivities from frozen outputs.
No regression, weather simulation, decomposition estimation or bootstrap is run.
Usage: python3 scripts/derive_panel_tables.py [--out EMPTY_DIRECTORY]
"""
from pathlib import Path
import argparse,json,hashlib
import pandas as pd
import numpy as np
D=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--out');args=ap.parse_args()
out=Path(args.out) if args.out else D/'data/panel';out.mkdir(parents=True,exist_ok=True)
data=D/'data';m=pd.read_csv(data/'scenario_metrics.csv').set_index('scenario_id');cf=pd.read_csv(data/'scenario_annual_cash_flows.csv');reg=pd.read_csv(data/'scenario_input_register.csv').set_index('param_id');be=json.loads((data/'breakevens.json').read_text())
base=m.loc['node_base'];fixed=m.loc['fixed_base'];cap=float(base.capex_total_real);infl=.025;r=.0427
cpi=be['cpi_2023_to_2025_factor'];occ=float(reg.loc['occ_2023usd','base'])*cpi*100000;gcc=float(reg.loc['gcc_2023usd','base'])*cpi*100000
assert abs(occ+gcc-cap)<.01
fc=cf[cf.scenario_id=='fixed_base'];nc=cf[cf.scenario_id=='node_base'];t=nc.t.to_numpy();v=nc.net_cash_flow_real.to_numpy();disc=(1+r)**(-t)
assert abs(float(v@disc)-base.npv_real_selected)<.01
assert abs(float(fc.net_cash_flow_real@((1+r)**(-fc.t)))-fixed.npv_real_selected)<.01
anchor=be['negative_price_energy_anchor'];slope=float((fc.revenue_real/40/(1+r)**fc.t).sum());no_pay_be=be['fixed_breakeven_price_nominal_flat_at_0.0427']*(1-anchor)
credit_nominal=.3*cap*(1+infl) # 2026 nominal eligible-basis assumption, paid unchanged in 2027.
credit_real_2025=credit_nominal/(1+infl)**2;credit_pv=credit_real_2025/(1+r)
module_factor=.26111*1.144
module_rows=[]
for cut in [.1,.2,.297,.3,1.0]:
 delta=occ*module_factor*cut
 module_rows.append(dict(module_price_reduction=cut,cost_scope='PV overnight cost only; grid connection unchanged',delta_capex=delta,new_total_capex=cap-delta,new_capex_kwac=(cap-delta)/100000,new_node_npv=float(base.npv_real_selected)+delta,new_fixed_npv=float(fixed.npv_real_selected)+delta,delta_npv=delta,delta_npv_with_nominal_credit=delta*(1-.3/((1+infl)*(1+r)))))
pd.DataFrame(module_rows).to_csv(out/'Module-Cost-Sensitivities.csv',index=False)
neg=be['negative_price_energy_anchor'];rule=json.loads((data/'price_pairing_checks.json').read_text());raw_rev=rule['generation_weighted_avg_price_as_available']*base.sim_ac_mwh_yr1
negprice=(raw_rev-base.revenue_real_yr1)/base.curtailed_mwh_yr1
n=np.arange(1,31)
rates=[];a4=float(((1-.007)**(n-1)/(1+r)**n).sum());K4=float(cap+base.fom_usd_per_kwac_yr*100000*((1+r)**(-n)).sum()+35*100000/(1+r)**16+30*100000/(1+r)**30)
cells=pd.read_csv(data/'empirical/A_3x3_cells_by_node.csv');same=cells[(cells.tier=='strict')&(cells.price_year==cells.weather_year)].copy()
for rate in [.0427,.06,.08]:
 a=float(((1-.007)**(n-1)/(1+rate)**n).sum());K=float(cap+base.fom_usd_per_kwac_yr*100000*((1+rate)**(-n)).sum()+35*100000/(1+rate)**16+30*100000/(1+rate)**30)
 for Y,g in same.groupby('price_year'):
  nv=a*g.rev_stop_negative_usd-K
  if rate==r:assert np.max(np.abs(nv-g.npv_4p27))<.20
  rates.append(dict(price_year=int(Y),discount_real=rate,n=len(g),positive_nodes=int((nv>0).sum()),positive_share=float((nv>0).mean()),mean_npv=float(nv.mean()),median_npv=float(nv.median()),mean_receipts=float(g.rev_stop_negative_usd.mean()),median_receipts=float(g.rev_stop_negative_usd.median())))
pd.DataFrame(rates).to_csv(out/'Year-Rate-Comparisons.csv',index=False)
dec=pd.read_csv(data/'empirical/A_decomposition_by_node.csv');ds=dec[dec.tier=='strict'];means=ds.groupby(['from_year','to_year','component']).agg(mean_npv_change=('npv_change_usd','mean'),n=('node','count')).reset_index();means.to_csv(out/'Mean-Decomposition.csv',index=False)
checks=[]
for (y0,y1),g in ds.groupby(['from_year','to_year']):
 z=g.pivot(index='node',columns='component',values='npv_change_usd')
 # Frozen values are rounded; independently verify four components and two-factor sums.
 for keys in [['volume_lmdi','price_level_lmdi','match_lmdi','rule_effect'],['weather_shapley','price_shapley']]:
  resid=z[keys].sum(axis=1)-z.total_change;assert resid.abs().max()<.2
  checks.append(dict(check='component sum',transition=f'{y0}-{y1}',keys=keys,max_rounding_residual_usd=float(resid.abs().max())))
 q=same.groupby('price_year').npv_4p27.mean();assert abs(z.total_change.mean()-(q[y1]-q[y0]))<.08
tail=pd.read_csv(data/'empirical/C_tail_results_by_node_year.csv');tail=tail[tail.tier=='strict'];ts=tail.groupby(['year','top_pct']).agg(n=('node','count'),median_share=('share_of_Rcurt_top_by_price','median'),median_npv=('npv_drop_top_price_intervals','median'),positive_share=('npv_drop_top_price_intervals',lambda x:(x>0).mean()),median_days=('days_flagged','median'),median_hours=('hours_equivalent','median'),min_hours=('hours_equivalent','min'),max_hours=('hours_equivalent','max')).reset_index();ts.to_csv(out/'Tail-Stress-Summary.csv',index=False)
h=cells[(cells.node.isin(['TAYGETE2_ALL','HB_WEST','HB_BUSAVG']))&(cells.price_year==cells.weather_year)].copy();ref=h[h.node=='TAYGETE2_ALL'].set_index('price_year');hub=h[h.node=='HB_WEST'].set_index('price_year');h['generation_weighted_node_minus_west_basis']=h.price_year.map(ref.capture_price-hub.capture_price);h.to_csv(out/'Node-Hub-Comparisons.csv',index=False)
piv=same.pivot(index='node',columns='price_year',values='rev_stop_negative_usd');low=(piv[2024]+piv[2025])/2;w=(K4/a4-low)/(piv[2023]-low);pd.DataFrame({'node':piv.index,'required_2023_discount_weight_share':w,'low_year_receipts':low,'high_year_receipts':piv[2023]}).to_csv(out/'Required-High-Year-Share.csv',index=False)
panel=pd.read_csv(data/'empirical/system_panel_hourly_2023_2025.csv.gz');panel['hour']=pd.to_datetime(panel.utc,utc=True).dt.tz_convert('America/Chicago').dt.hour;z=panel[panel.year==2025].copy();z['net_load_mw']=z.load_mw-z.solar_mw-z.wind_mw;z.groupby('hour')[['load_mw','net_load_mw','solar_mw','wind_mw']].mean().to_csv(out/'Intraday-Net-Load-2025.csv')
screen=pd.read_csv(data/'supplement/B/B_all_resource_nodes_screen_2025.csv');eligible=screen[screen.screen=='eligible'].copy();eligible['cohort']=np.where(eligible.name.isin(same.node.unique()),'Three-year screened','2025-only eligible')
cohort=eligible.groupby('cohort').agg(n=('name','count'),median_capture_price=('gw_price_ref','median'),mean_capture_price=('gw_price_ref','mean'),median_capture_ratio=('capture_ratio','median')).reset_index();assert sorted(cohort.n)==[156,485];cohort.to_csv(out/'Coverage-Cohort-Comparison-2025.csv',index=False)
zones=pd.read_csv(data/'empirical/tables/B3_node_basis_stats.csv');positive=same[same.npv_4p27>0].merge(zones[['node','year','zone']],left_on=['node','price_year'],right_on=['node','year'],how='left');assert positive.zone.notna().all();positive.groupby(['price_year','zone']).size().rename('positive_nodes').reset_index().to_csv(out/'Positive-Node-Zones.csv',index=False)
roots=[]
for name,row in m.iterrows():
 rr=json.loads(row.irr_roots.replace("'",'"')) if isinstance(row.irr_roots,str) else []
 roots.append(dict(scenario=name,roots=rr,near_zero_numerical_root=max(rr) if rr else None,original_irr_status=row.irr_status))
ash=pd.read_csv(data/'r2/D/D_ashare_peers_FY2025.csv');ar=[]
for co,g in ash.groupby('company'):
 get=lambda metric,year:float(g[(g.metric==metric)&(g.period==year)].value.iloc[0])
 ar.append(dict(company=co,revenue_mn=get('revenue','FY2025'),attributable_net_income_mn=get('net_profit_attributable','FY2025'),attributable_net_margin_pct=get('net_profit_attributable','FY2025')/get('revenue','FY2025')*100))
pd.DataFrame(ar).to_csv(out/'Company-Net-Margins.csv',index=False)
result=dict(capex=cap,occ=occ,gcc=gcc,module_effective_share=module_factor,module_sensitivities=module_rows,credit_nominal_2027=credit_nominal,credit_real_2025=credit_real_2025,credit_pv=credit_pv,node_npv_with_credit=float(base.npv_real_selected)+credit_pv,fixed_npv_with_credit=float(fixed.npv_real_selected)+credit_pv,fixed_breakeven_with_credit=be['fixed_breakeven_price_nominal_flat_at_0.0427']-credit_pv/slope,no_unpaid_breakeven=no_pay_be,negative_price_energy_weighted_mean=negprice,negative_price_nominal_contract_receipts_2027=base.curtailed_mwh_yr1*40,a=a4,K=K4,output_10pct_npv_change=.1*base.revenue_real_yr1*a4,module_point10usd_npv=occ*.1*1.144/1.115,required_high_year_share_median=float(w.median()),required_high_year_share_reference=float(w.loc['TAYGETE2_ALL']),irr_root_display=roots,checks=checks,scope='Derived from frozen output tables; hypothetical sensitivities. Historical price numbers unadjusted for CPI. No new fitting, resampling or physical simulation.')
(out/'Panel-Calculations.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['occ','gcc','credit_pv','node_npv_with_credit','fixed_breakeven_with_credit','no_unpaid_breakeven','negative_price_energy_weighted_mean','required_high_year_share_median','required_high_year_share_reference']},indent=2));print('PASS: frozen cash-flow and additive identities')
