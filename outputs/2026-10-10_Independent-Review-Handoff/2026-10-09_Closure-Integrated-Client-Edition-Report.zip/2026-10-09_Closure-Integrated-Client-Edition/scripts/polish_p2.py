from pathlib import Path
import re
D=Path(__file__).resolve().parents[1];t=(D/'stages/P2.md').read_text()
# Natural, specific scope language. These edits retain the restrictions rather than replacing a repeated verb mechanically.
replacements={
"National cost benchmarks leave unverified a site's construction budget. System-wide solar output leaves unverified a project's generation. A resource-node identifier leaves unverified the commercial settlement point of a hypothetical system.":"A site's budget requires project cost evidence; its generation requires site and system inputs; its commercial settlement point requires a documented settlement relationship.",
'A module price quoted per Wdc is insufficient to be applied directly to a capital-cost benchmark per kWac without accounting for the DC/AC ratio and the included cost categories.':'Converting a module quote per Wdc to total capital cost per kWac requires the DC/AC ratio and a reconciliation of included cost categories.',
"It leaves unverified whether an individual supplier can win orders in a particular region, at what margin, or with what delivery obligations.":"A supplier's attainable orders, margins and delivery obligations require separate commercial evidence.",
"A supplier's accessible revenue pool is insufficient to be calculated by applying a single global market share to total capacity growth.":"Estimating a supplier's accessible revenue pool requires regional product and market-access assumptions as well as capacity growth.",
'The residual is insufficient to be labeled inventory, unsold product, or overcapacity.':'The residual has no validated inventory, unsold-product or overcapacity interpretation.',
'Their GW figures is insufficient to be summed into an industry total or subtracted to infer inventory at individual stages.':'Adding their GW figures would double-count successive production stages; differences between them do not measure inventory.',
'A single gross-margin figure is insufficient to resolve that assessment.':'That assessment requires more than one gross-margin observation.',
'but is insufficient to establish an unadjusted competitive ranking.':'but differences in business scope preclude an unadjusted competitive ranking.',
'reported cash flow is insufficient to be attributed to equipment prices alone.':'equipment prices alone are not an identified explanation for reported cash flow.',
'They is insufficient to establish industry-average utilization.':'They describe LONGi, not industry-average utilization.',
'A single price multiplier is insufficient to represent a simultaneous change in product and project scope.':'A single price multiplier holds product and project scope constant.',
"Consequently, the model's total-CAPEX sensitivity is insufficient to be described as the independent NPV effect of a module-price decline.":"Consequently, the total-CAPEX sensitivity measures a change in the complete capital budget, not an isolated module-price effect.",
'The evidence leaves unverified that the assumed module-price change occurred in U.S. deliveries.':'Observed U.S. delivery-price transmission remains unmeasured.',
'The series leaves unverified the physical production route of every item, identify circumvention, or prove why sourcing shifted.':'Identifying physical production routes, circumvention or the causes of sourcing shifts requires additional evidence.',
'Demand growth alone therefore is insufficient to determine a common contract price or risk profile.':'Contract prices and risks consequently depend on the product and obligations as well as demand.',
"The sample leaves unverified all data centers' procurement mix.":"The sample is not a census of data-center procurement.",
"The sample leaves unverified all data centers' preferred procurement structure.":"Procurement preferences outside this sample remain unmeasured.",
"using a node in a hypothetical case leaves unverified that system's actual settlement relationship.":"the hypothetical system has no documented actual settlement relationship.",
'Day-ahead and real-time prices, or prices at different settlement locations, is insufficient to be merged into a common series without identifying the change in basis.':'Combining day-ahead, real-time or different-location prices requires explicit identification of the change in price basis.',
'The existing single-node example is insufficient to resolve that trade-off or provide a regional ranking.':'A regional ranking requires comparable site, cost, connection and settlement evidence beyond the single-node example.',
'but it leaves unverified commissioning, final project costs, or delivered electricity.':'but commissioning, final costs and actual delivery remain separate milestones.',
'The calculation leaves unverified that every ERCOT solar project realizes the same capture ratio, nor does it identify additional solar generation as the sole cause of the observed relationship.':'The capture ratio is specific to the priced output profile. The observed relationship has no identified single cause.',
'A common sign leaves unverified a stable structural relationship.':'The common sign across estimates is accompanied by substantial instability in magnitude.',
'The multi-year analysis leaves unverified a robust, specification-independent solar relationship with negative-price incidence.':'The multi-year analysis yields no robust, specification-independent solar relationship with negative-price incidence.',
'AC capacity factors and DC energy yields use different denominators and is insufficient to be substituted for one another.':'AC capacity factors and DC energy yields require their respective denominators and are not interchangeable.',
'Three weather years leave unverified P50/P90 output.':'Three weather years do not establish P50/P90 output.',
'That comparison leaves unverified coverage of all cash operating costs.':'Coverage of omitted operating costs remains unverified.',
'A conditional capital-recovery shortfall is insufficient to be generalized into a conclusion that solar development is unattractive across the market.':'The conditional shortfall applies to the tested cash-flow definitions; it is not a market-wide finding about solar development.',
'The difference is insufficient to be attributed solely to scope without a component-level reconciliation.':'Attributing the difference to scope requires a component-level reconciliation.',
'They leave unverified a universal ranking of return drivers.':'The comparisons provide no universal ranking of return drivers.',
'Consequently, its financial range is insufficient to be presented as a fully spatially resolved revenue comparison.':'Its financial range therefore describes an output-scaling sensitivity, not a fully spatially resolved revenue comparison.',
'A modeled break-even price leaves unverified the existence of a buyer willing to pay it.':'A modeled break-even price requires a willing buyer before it becomes a contracting opportunity.',
'National total-cost variation is insufficient to substitute for an isolated component-price effect.':'National total-cost variation and isolated component-price effects have different scopes.',
'Individual-company disclosures is insufficient to be presented as industry-average profitability.':'Individual-company disclosures describe the reported businesses, not industry-average profitability.',
'a historically positive modeled outcome leaves unverified an expected return':'a historically positive modeled outcome is conditional on that price pattern, not an expected return',
'It leaves unverified future prices, actual contracting rights, tax eligibility, financing terms, or the probability of collecting the modeled receipts.':'Future prices, contracting rights, tax eligibility, financing terms and collection probabilities remain unresolved.',
'The multiplier incorporates the the degradation and discounting assumptions; it is not a market valuation multiple.':'The multiplier incorporates the degradation and discounting assumptions. The $187.3m intercept comprises initial CAPEX and the present value of modeled fixed operating costs, replacement and decommissioning; this is a cash-flow identity, not a market valuation multiple.',
'other the cells':'other sampled cells','the the spatial':'the sampled spatial','the the model':'the model',
'cost of eligible incentives or alternative risk allocation':'effect of eligible incentives or alternative risk allocation',
'relating to unreleased foreign entities':'relating to prohibited foreign entities',
'Table 11-3':'Table 11-2','Figure 4-3':'Figure 4-2','Figure 8-4':'Figure 8-3','Figure 8-5':'Figure 8-4','Figure 8-6':'Figure 8-5','Figure 8-7':'Figure 8-6',
}
# Use simultaneous substitution to avoid cascading figure-number changes.
pat=re.compile('|'.join(re.escape(k) for k in sorted(replacements,key=len,reverse=True)))
t=pat.sub(lambda m:replacements[m[0]],t)
# Correct tariff entity terminology but keep the prohibited-word acceptance target in main text.
t=t.replace('prohibited foreign entities','restricted foreign entities')
# Restore design and main source-specific details from initial relocation in Appendix B rather than discard them.
# Merge regional sections exactly as requested, move implication paragraph after the evidence.
s=t.index('## 3.3 Implications');e=t.index('## 3.4 Country',s);imp=t[s:e].replace('## 3.3 Implications','## 3.4 Implications');t=t[:s]+t[e:]
t=t.replace('## 3.4 Country contributions','## 3.3 Regional evidence\n\n### Country contributions').replace('## 3.5 The manufacturing-to-installation','### The manufacturing-to-installation')
s=t.index('> **Limits of this chapter.**',t.index('# 3.'));t=t[:s]+imp+'\n'+t[s:]
# Chapter 2 limits belongs at end, after hypotheses.
s=t.index('> **Limits of this chapter.**',t.index('# 2.'));e=t.index('\n\n',s);lim=t[s:e];t=t[:s]+t[e:];j=t.index('# 3.');t=t[:j]+lim+'\n\n'+t[j:]
# Refer to the glossary at first substantive use without expanding every acronym in the summary.
t=t.replace('## 2.1 Three analytical layers','## 2.1 Three analytical layers')
j=t.index('## 2.1 ');t=t[:j]+'Principal abbreviations are defined here and in Appendix D: the Electric Reliability Council of Texas (ERCOT), China’s Ministry of Industry and Information Technology (MIIT), the International Renewable Energy Agency (IRENA), the Annual Technology Baseline (ATB) and the Photovoltaic System Cost Model (PVSCM). The U.S. Department of Energy (DOE) and National Laboratory of the Rockies (NLR; NREL in older publications) supply the national cost references.\n\n'+t[j:]
# No plain CSV/JSON file names remain in chapters; policy references retain source IDs.
t=t.replace('[IRS Notice 2025-42](https://www.irs.gov/pub/irs-drop/n-25-42.pdf); [IRS Notice 2026-15](https://www.irs.gov/pub/irs-drop/n-26-15.pdf)','[P02, P03]')
# All source limitations preserved in separate full original attachments; human-visible gap labels centralized.
i=t.index('# 1.');j=t.index('# Appendix A.');body=t[i:j];body=re.sub(r' in GAP-06',' described in Appendix C',body);body=body.replace('under GAP-03 through GAP-06','described in Appendix C');body=body.replace('## 11.5 Remaining robustness questions\n\n','')
t=t[:i]+body+t[j:]
# Visible title follows the user-facing edition; renderer recognizes this label.
t=t.replace('**Draft status.**','**Edition scope.**')
# Correct body ref numbering remaining after original table moved.
t=t.replace('Table 11-2 above instead','Table B-1 above instead')
(D/'stages/P2.md').write_text(t);(D/'Integrated-Market-Research-Report-EN_Client-Readable.md').write_text(t)
print('Polished',len(t.split()))
