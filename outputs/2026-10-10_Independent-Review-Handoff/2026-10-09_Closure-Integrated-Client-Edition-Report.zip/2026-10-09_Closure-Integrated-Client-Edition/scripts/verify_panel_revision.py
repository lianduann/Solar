"""Check new report claims against existing output values; no statistical re-estimation."""
from pathlib import Path
import re,json,hashlib,math
import pandas as pd
D=Path(__file__).resolve().parents[1];s=(D/'Integrated-Market-Research-Report-EN_Panel-Revised.md').read_text();rows=[]
def check(name,ok,evidence):
 rows.append(dict(check=name,passed=bool(ok),evidence=evidence))
def value(name,v,d=2,sign=False):
 token=f'{abs(v):,.{d}f}';token=('−' if v<0 else '+' if sign else '')+token
 check(name,token in s.replace('$',''),dict(value=float(v),display=token))
j=json.loads((D/'data/panel/Panel-Calculations.json').read_text())
for key in ['credit_pv','node_npv_with_credit','fixed_npv_with_credit','output_10pct_npv_change']:value(key,j[key]/1e6)
for key in ['fixed_breakeven_with_credit','no_unpaid_breakeven']:value(key,j[key])
value('negative-price mean',j['negative_price_energy_weighted_mean'])
value('required high-year median',j['required_high_year_share_median']*100,1)
value('required high-year reference',j['required_high_year_share_reference']*100,1)
a=pd.read_csv(D/'data/panel/Module-Cost-Sensitivities.csv')
for _,r in a[a.module_price_reduction.isin([.1,.2,.3,1])].iterrows():
 for col in ['delta_capex','new_node_npv','new_fixed_npv']:value(f'module {r.module_price_reduction} {col}',r[col]/1e6)
a=pd.read_csv(D/'data/panel/Mean-Decomposition.csv')
for _,r in a[a.component.isin(['volume_lmdi','price_level_lmdi','match_lmdi','rule_effect','total_change'])].iterrows():value(f'{r.from_year}-{r.to_year} {r.component}',r.mean_npv_change/1e6,sign=True)
a=pd.read_csv(D/'data/panel/Year-Rate-Comparisons.csv')
for _,r in a.iterrows():value(f'year {r.price_year} rate {r.discount_real}',r.median_npv/1e6,sign=True)
a=pd.read_csv(D/'data/panel/Node-Hub-Comparisons.csv')
for _,r in a.iterrows():value(f'{r.node} {r.price_year} capture price',r.capture_price)
a=pd.read_csv(D/'data/panel/Coverage-Cohort-Comparison-2025.csv')
for _,r in a.iterrows():
 value(f'{r.cohort} median',r.median_capture_price);value(f'{r.cohort} mean',r.mean_capture_price)
a=pd.read_csv(D/'data/empirical/C_tail_results_by_node_year.csv');a=a[(a.tier=='strict')&(a.year==2023)]
for key in ['cap_p99.0','cap_p99.9']:value(key,a[a.top_pct==key].npv_drop_top_price_intervals.median()/1e6)
# Independent cash-flow calculation (separate from the derivation's affine formula).
cash=pd.read_csv(D/'data/scenario_annual_cash_flows.csv');m=pd.read_csv(D/'data/scenario_metrics.csv').set_index('scenario_id')
for name,g in cash.groupby('scenario_id'):
 for rate in [.0427,.06,.08]:
  got=(g.net_cash_flow_real/(1+rate)**g.t).sum();expected=m.loc[name,'npv_real_at_'+f'{rate:.4f}']
  check(f'cash-flow NPV {name} {rate}',abs(got-expected)<.01,dict(absolute_difference=float(abs(got-expected))))
fixed=cash[cash.scenario_id=='fixed_base'];base=m.loc['node_base'];cap=float(base.capex_total_real)
credit_nominal=cap*1.025*.3;pv=credit_nominal/1.025**2/1.0427
check('credit timing independent',abs(pv-j['credit_pv'])<1e-7,dict(formula='CAPEX * 1.025 * .30 / 1.025**2 / 1.0427'))
costs=(fixed.net_cash_flow_real-fixed.revenue_real);costpv=(costs/1.0427**fixed.t).sum();revpv=(fixed.revenue_real/1.0427**fixed.t).sum()
be40=-costpv/(revpv/40)*(1-base.curtailed_mwh_yr1/base.sim_ac_mwh_yr1)
check('no-unpaid break-even independently',abs(be40-j['no_unpaid_breakeven'])<1e-7,dict(value=float(be40)))
original=json.loads((D/'support/Baseline-Data-Hashes.json').read_text());diff=[]
for path,h in original.items():
 if hashlib.sha256((D/path).read_bytes()).hexdigest()!=h:diff.append(path)
check('baseline data unchanged',not diff,dict(files=len(original),differences=diff))
for kind,regex in [('figure',r'^!\[Figure ([A-Z0-9]+)-(\d+)\.'),('table',r'^\*\*Table ([A-Z0-9]+)-(\d+)\.')]:
 items=re.findall(regex,s,re.M);check(kind+' labels unique',len(items)==len(set(items)),items)
 for chapter in dict.fromkeys(a for a,b in items):
  nums=[int(b) for a,b in items if a==chapter];check(kind+' sequence '+chapter,nums==list(range(1,len(nums)+1)),nums)
imgs=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',s);check('all figures exist',all((D/x).is_file() for x in imgs),imgs)
check('all finance placeholders present',all(f'FIN-{x:02}' in s for x in range(1,12)),'FIN-01 through FIN-11')
body=s[:s.index('# Appendix A.')];check('no internal governance in client body',not re.search(r'59 blocked|13 prohibited|GAP-\d|Version 1\.0|Appendix E|Shapley|LMDI',body),'technical and governance separation')
old=(D/'support/Baseline-Client-Readable.md').read_text();terms=['retained','empirical candidate','first-round','second-round','R2','supplement','editorial integration','blocked','prohibited','Version 1.0','fact-model','evidence gates']
counts={x:{'before_main':len(re.findall(re.escape(x),old[:old.index('# Appendix A.')],re.I)),'after_main':len(re.findall(re.escape(x),body,re.I))} for x in terms}
pattern=r'does not establish|do not establish|cannot';counts['limiting_phrase_total']={k:len(re.findall(pattern,v,re.I)) for k,v in [('before_full',old),('after_full',s),('before_main',old[:old.index('# Appendix A.')]),('after_main',body)]}
(D/'support/Editorial-Search-Counts.json').write_text(json.dumps(counts,indent=2))
report=dict(checks=rows,total=len(rows),failed=sum(not r['passed'] for r in rows),scope='New displayed numeric claims, retained cash flows, inherited data hashes and manuscript structure. No raw-source or regression revalidation.')
(D/'support/Panel-Numeric-and-Structure-Checks.json').write_text(json.dumps(report,indent=2));print(report['total'],'checks,',report['failed'],'failed')
for r in rows:
 if not r['passed']:print(r)
raise SystemExit(bool(report['failed']))
