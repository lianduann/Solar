"""Compare the actual current-report products with an independent clean rebuild."""
from pathlib import Path
import argparse,json,hashlib,re,fitz
D=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--rebuilt',required=True);a=ap.parse_args();R=Path(a.rebuilt);name='Integrated-Market-Research-Report-EN_Finance-Integrated'
md=(D/(name+'.md')).read_text();refs=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',md)
files=[D/(name+'.md')]+list((D/'data/panel').glob('*'))+list((D/'data/finance').glob('*'))+[D/p for p in refs]
comp=[]
for p in files:
 if p.is_file():
  q=R/p.relative_to(D);comp.append(dict(path=p.relative_to(D).as_posix(),equal=q.exists() and hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(q.read_bytes()).digest()))
x=fitz.open(D/(name+'.pdf'));y=fitz.open(R/(name+'.pdf'));assert len(x)==len(y);pixels=[]
for i in range(len(x)):
 p=x[i].get_pixmap(alpha=False);q=y[i].get_pixmap(alpha=False);pixels.append(dict(page=i+1,equal=p.width==q.width and p.height==q.height and p.samples==q.samples))
path=D/'support/Finance-Handoff-Verification.json';v=json.loads(path.read_text());v.update(clean_rebuild_exit_status=0,comparisons=comp,comparison_failures=[c for c in comp if not c['equal']],pdf_rendered_page_comparisons=pixels,pdf_rendered_page_failures=[p for p in pixels if not p['equal']],comparison_scope='Current manuscript, all panel/finance derived data, all 29 displayed figures, all PDF pages. Unreferenced historical figure Client_LMDI_decomposition.png is preserved but not a current rebuild output.')
path.write_text(json.dumps(v,indent=2));print(len(comp),'current report files;',len(pixels),'rendered pages;',len(v['comparison_failures'])+len(v['pdf_rendered_page_failures']),'failures');raise SystemExit(bool(v['comparison_failures'] or v['pdf_rendered_page_failures']))
